ObjC.import('Cocoa');
ObjC.import('WebKit');

ObjC.registerSubclass({
  name: 'PAAppDelegate',
  protocols: ['NSApplicationDelegate'],
  methods: {
    'applicationShouldTerminateAfterLastWindowClosed:': {
      types: ['bool', ['id']],
      implementation: function (sender) { return true; }
    }
  }
});

function run(argv) {
  var htmlPath = argv[0];
  var iconPath = argv[1];

  var app = $.NSApplication.sharedApplication;
  app.setActivationPolicy($.NSApplicationActivationPolicyRegular);
  app.delegate = $.PAAppDelegate.alloc.init;

  try {
    var icon = $.NSImage.alloc.initWithContentsOfFile(iconPath);
    if (icon && !icon.isNull) app.applicationIconImage = icon;
  } catch (e) {}

  // Menus : indispensables pour Cmd+Q, Cmd+C, Cmd+V, Cmd+A…
  var mainMenu = $.NSMenu.alloc.init;
  function addMenu(title, items) {
    var top = $.NSMenuItem.alloc.initWithTitleActionKeyEquivalent(title, '', '');
    var sub = $.NSMenu.alloc.initWithTitle(title);
    items.forEach(function (it) {
      if (it === '-') { sub.addItem($.NSMenuItem.separatorItem); return; }
      sub.addItem($.NSMenuItem.alloc.initWithTitleActionKeyEquivalent(it[0], it[1], it[2]));
    });
    top.submenu = sub;
    mainMenu.addItem(top);
  }
  addMenu('Prompt Builder Image', [
    ['Masquer Prompt Builder Image', 'hide:', 'h'],
    '-',
    ['Quitter Prompt Builder Image', 'terminate:', 'q']
  ]);
  addMenu('Édition', [
    ['Annuler', 'undo:', 'z'],
    ['Rétablir', 'redo:', 'Z'],
    '-',
    ['Couper', 'cut:', 'x'],
    ['Copier', 'copy:', 'c'],
    ['Coller', 'paste:', 'v'],
    ['Tout sélectionner', 'selectAll:', 'a']
  ]);
  addMenu('Fenêtre', [
    ['Réduire', 'performMiniaturize:', 'm'],
    ['Zoom', 'performZoom:', '']
  ]);
  app.mainMenu = mainMenu;

  var style = $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable |
              $.NSWindowStyleMaskMiniaturizable | $.NSWindowStyleMaskResizable;
  var win = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(
    $.NSMakeRect(0, 0, 1360, 860), style, $.NSBackingStoreBuffered, false);
  win.title = 'Prompt Builder Image';
  win.minSize = $.NSMakeSize(900, 600);
  win.backgroundColor = $.NSColor.colorWithSRGBRedGreenBlueAlpha(0.145, 0.153, 0.169, 1);
  try { win.appearance = $.NSAppearance.appearanceNamed('NSAppearanceNameDarkAqua'); } catch (e) {}
  win.center;
  try { win.setFrameAutosaveName('PromptBuilderImageMainWindow'); } catch (e) {}

  var cfg = $.WKWebViewConfiguration.alloc.init;
  var web = $.WKWebView.alloc.initWithFrameConfiguration(win.contentView.bounds, cfg);
  web.autoresizingMask = $.NSViewWidthSizable | $.NSViewHeightSizable;
  win.contentView.addSubview(web);

  var fileURL = $.NSURL.fileURLWithPath(htmlPath);
  var dirURL = fileURL.URLByDeletingLastPathComponent;
  web.loadFileURLAllowingReadAccessToURL(fileURL, dirURL);

  win.makeKeyAndOrderFront(null);
  app.activateIgnoringOtherApps(true);
  app.run;
}
