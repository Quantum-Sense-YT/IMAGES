import SwiftUI
import VLCKit

/// Vue AppKit fournie par VLCKit, dans laquelle libVLC dessine la vidéo.
struct VLCVideoSurface: NSViewRepresentable {
    let player: VLCMediaPlayer
    var fill: Bool = false           // true = remplit la fenêtre en rognant l'image

    func makeNSView(context: Context) -> VLCVideoView {
        let view = VLCVideoView(frame: .zero)
        view.backColor = .black
        view.fillScreen = fill
        player.drawable = view
        return view
    }

    func updateNSView(_ nsView: VLCVideoView, context: Context) {
        nsView.fillScreen = fill
    }
}
