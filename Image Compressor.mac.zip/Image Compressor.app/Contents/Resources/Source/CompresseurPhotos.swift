// Compresseur de photos — interface unique, glisser-déposer.
// Moteur : ImageIO (intégré à macOS). Les photos originales ne sont jamais modifiées.

import SwiftUI
import AppKit
import ImageIO
import UniformTypeIdentifiers

let extensionsImages: Set<String> = ["jpg", "jpeg", "png", "heic", "heif", "tif", "tiff", "bmp", "gif"]
let nomDossierSortie = "Compressées"

// MARK: - Types

enum Dimension: Hashable {
    case origine
    case pourcent(Int)
    case cote(Int)
    case pourcentPerso
    case cotePerso
}

enum Cible {
    case aucune
    case pourcent(Int)
    case cote(Int)
}

enum FormatSortie: String, CaseIterable, Identifiable {
    case jpeg, heic, origine
    var id: String { rawValue }
    var titre: String {
        switch self {
        case .jpeg: return "JPEG"
        case .heic: return "HEIC"
        case .origine: return "Original"
        }
    }
    var aide: String {
        switch self {
        case .jpeg: return "Compatible partout."
        case .heic: return "Plus léger, format Apple moderne."
        case .origine: return "Garde le format de chaque photo (le PNG n’a pas de réglage de qualité : seul le redimensionnement s’applique)."
        }
    }
}

enum Destination {
    case cote
    case autre
}

enum Etat {
    case attente
    case enCours
    case termine(Int64)
    case erreur(String)
}

struct Photo: Identifiable {
    let id = UUID()
    let url: URL
    var taille: Int64
    var dimensions: String = ""
    var miniature: NSImage? = nil
    var etat: Etat = .attente
}

struct Reglages {
    var qualite: Double
    var cible: Cible
    var format: FormatSortie
    var dossierFixe: URL?
    var garderMeta: Bool
}

struct Bilan {
    var nbOk = 0
    var nbTotal = 0
    var avant: Int64 = 0
    var apres: Int64 = 0
    var nbPlusLourd = 0
    var nbEchecs = 0
    var sorties: [URL] = []
}

struct ErreurCompression: Error {
    let message: String
}

func formaterTaille(_ octets: Int64) -> String {
    return ByteCountFormatter.string(fromByteCount: octets, countStyle: .file)
}

let formateurEntier: NumberFormatter = {
    let f = NumberFormatter()
    f.numberStyle = .none
    f.allowsFloats = false
    f.minimum = 1
    f.maximum = 20000
    return f
}()

// MARK: - Moteur de compression

enum Compresseur {

    static func aTransparence(_ img: CGImage) -> Bool {
        switch img.alphaInfo {
        case .none, .noneSkipFirst, .noneSkipLast:
            return false
        default:
            return true
        }
    }

    // Aplatit sur fond blanc (le JPEG ne gère pas la transparence)
    static func aplatir(_ img: CGImage) -> CGImage? {
        var espaces: [CGColorSpace] = []
        if let c = img.colorSpace, c.model == .rgb { espaces.append(c) }
        if let s = CGColorSpace(name: CGColorSpace.sRGB) { espaces.append(s) }
        let rect = CGRect(x: 0, y: 0, width: img.width, height: img.height)
        for cs in espaces {
            let info = CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
            if let ctx = CGContext(data: nil, width: img.width, height: img.height, bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: info) {
                ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
                ctx.fill(rect)
                ctx.draw(img, in: rect)
                return ctx.makeImage()
            }
        }
        return nil
    }

    static func cheminUnique(dossier: URL, base: String, ext: String, verrou: NSLock) -> URL {
        verrou.lock()
        defer { verrou.unlock() }
        let fm = FileManager.default
        var candidat = dossier.appendingPathComponent(base).appendingPathExtension(ext)
        var i = 1
        while fm.fileExists(atPath: candidat.path) {
            candidat = dossier.appendingPathComponent("\(base)-\(i)").appendingPathExtension(ext)
            i += 1
        }
        fm.createFile(atPath: candidat.path, contents: nil)
        return candidat
    }

    static func traiter(_ source: URL, _ r: Reglages, verrou: NSLock) throws -> (URL, Int64) {
        guard let src = CGImageSourceCreateWithURL(source as CFURL, nil), CGImageSourceGetCount(src) > 0 else {
            throw ErreurCompression(message: "Fichier illisible")
        }
        let props = (CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any]) ?? [:]
        let w = (props[kCGImagePropertyPixelWidth] as? Int) ?? 0
        let h = (props[kCGImagePropertyPixelHeight] as? Int) ?? 0
        if w <= 0 || h <= 0 { throw ErreurCompression(message: "Dimensions inconnues") }

        // Redimensionnement (jamais d'agrandissement)
        let plusGrand = max(w, h)
        var cote = plusGrand
        switch r.cible {
        case .aucune:
            break
        case .pourcent(let p):
            cote = max(1, Int((Double(plusGrand) * Double(p) / 100.0).rounded()))
        case .cote(let c):
            cote = c
        }
        cote = min(cote, plusGrand)

        let optsMiniature: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: cote,
            kCGImageSourceShouldCacheImmediately: true
        ]
        guard var image = CGImageSourceCreateThumbnailAtIndex(src, 0, optsMiniature as CFDictionary) else {
            throw ErreurCompression(message: "Décodage impossible")
        }

        // Format de sortie
        let extSource = source.pathExtension.lowercased()
        var uti = "public.jpeg"
        var extSortie = "jpg"
        switch r.format {
        case .jpeg:
            break
        case .heic:
            uti = "public.heic"
            extSortie = "heic"
        case .origine:
            if extSource == "png" {
                uti = "public.png"
                extSortie = "png"
            } else if extSource == "heic" || extSource == "heif" {
                uti = "public.heic"
                extSortie = "heic"
            }
        }

        let typesPris = (CGImageDestinationCopyTypeIdentifiers() as? [String]) ?? []
        if !typesPris.contains(uti) {
            throw ErreurCompression(message: "Format non pris en charge")
        }

        if uti == "public.jpeg" && aTransparence(image) {
            if let plat = aplatir(image) { image = plat }
        }

        // Propriétés
        var dprops: [CFString: Any] = [:]
        if r.garderMeta {
            dprops = props
            dprops.removeValue(forKey: kCGImagePropertyPixelWidth)
            dprops.removeValue(forKey: kCGImagePropertyPixelHeight)
            dprops.removeValue(forKey: kCGImagePropertyDepth)
            dprops[kCGImagePropertyOrientation] = 1   // déjà appliquée
            if var tiff = dprops[kCGImagePropertyTIFFDictionary] as? [CFString: Any] {
                tiff[kCGImagePropertyTIFFOrientation] = 1
                dprops[kCGImagePropertyTIFFDictionary] = tiff
            }
            if var exif = dprops[kCGImagePropertyExifDictionary] as? [CFString: Any] {
                exif[kCGImagePropertyExifPixelXDimension] = image.width
                exif[kCGImagePropertyExifPixelYDimension] = image.height
                dprops[kCGImagePropertyExifDictionary] = exif
            }
        }
        if uti != "public.png" {
            dprops[kCGImageDestinationLossyCompressionQuality] = max(0.01, min(1.0, r.qualite / 100.0))
        }

        // Dossier et nom de sortie
        let fm = FileManager.default
        let dossier: URL
        if let fixe = r.dossierFixe {
            dossier = fixe
        } else {
            dossier = source.deletingLastPathComponent().appendingPathComponent(nomDossierSortie, isDirectory: true)
        }
        do {
            try fm.createDirectory(at: dossier, withIntermediateDirectories: true, attributes: nil)
        } catch {
            throw ErreurCompression(message: "Dossier inaccessible")
        }
        let base = source.deletingPathExtension().lastPathComponent
        let sortie = cheminUnique(dossier: dossier, base: base, ext: extSortie, verrou: verrou)

        guard let dest = CGImageDestinationCreateWithURL(sortie as CFURL, uti as CFString, 1, nil) else {
            try? fm.removeItem(at: sortie)
            throw ErreurCompression(message: "Écriture impossible")
        }
        CGImageDestinationAddImage(dest, image, dprops as CFDictionary)
        if !CGImageDestinationFinalize(dest) {
            try? fm.removeItem(at: sortie)
            throw ErreurCompression(message: "Échec de l’encodage")
        }

        let attrs = try? fm.attributesOfItem(atPath: sortie.path)
        let taille = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
        return (sortie, taille)
    }
}

// MARK: - Modèle

final class Modele: ObservableObject {
    static let partage = Modele()

    @Published var items: [Photo] = []
    @Published var qualite: Double = 80
    @Published var dimension: Dimension = .origine
    @Published var valeurPct: Int = 50
    @Published var valeurPx: Int = 1920
    @Published var format: FormatSortie = .jpeg
    @Published var destination: Destination = .cote
    @Published var dossierAutre: URL? = nil
    @Published var garderMeta: Bool = true
    @Published var enCours: Bool = false
    @Published var progres: Int = 0
    @Published var bilan: Bilan? = nil

    var aideQualite: String {
        let q = Int(qualite)
        if q >= 95 { return "Quasi identique" }
        if q >= 90 { return "Très haute qualité" }
        if q >= 80 { return "Recommandé" }
        if q >= 65 { return "Bon compromis" }
        if q > 40 { return "Allègement marqué" }
        if q > 20 { return "Fort allègement" }
        return "Très compressé"
    }

    var tailleTotale: Int64 {
        return items.reduce(Int64(0)) { $0 + $1.taille }
    }

    // MARK: Ajout de photos

    func choisir() {
        if enCours { return }
        let panneau = NSOpenPanel()
        panneau.title = "Choisir des photos ou un dossier"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = true
        panneau.canChooseDirectories = true
        panneau.allowsMultipleSelection = true
        panneau.allowedContentTypes = [UTType.image]
        if panneau.runModal() == .OK {
            ajouter(panneau.urls)
        }
    }

    func choisirDossierDestination() {
        let panneau = NSOpenPanel()
        panneau.title = "Dossier de destination"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = false
        panneau.canChooseDirectories = true
        panneau.canCreateDirectories = true
        panneau.allowsMultipleSelection = false
        if panneau.runModal() == .OK, let u = panneau.url {
            dossierAutre = u
            destination = .autre
        }
    }

    func selectionnerAutreDossier() {
        if dossierAutre == nil {
            choisirDossierDestination()
        } else {
            destination = .autre
        }
    }

    func deposer(_ providers: [NSItemProvider]) {
        let groupe = DispatchGroup()
        let verrou = NSLock()
        var urls: [URL] = []
        for p in providers {
            groupe.enter()
            p.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                var u: URL? = nil
                if let d = item as? Data {
                    u = URL(dataRepresentation: d, relativeTo: nil)
                } else if let x = item as? URL {
                    u = x
                }
                if let u = u {
                    verrou.lock()
                    urls.append(u)
                    verrou.unlock()
                }
                groupe.leave()
            }
        }
        groupe.notify(queue: .main) {
            self.ajouter(urls)
        }
    }

    func ajouter(_ urls: [URL]) {
        if enCours { return }
        DispatchQueue.global(qos: .userInitiated).async {
            var trouves: [URL] = []
            for u in urls {
                trouves.append(contentsOf: Modele.images(dans: u))
            }
            DispatchQueue.main.async {
                self.integrer(trouves)
            }
        }
    }

    static func images(dans url: URL) -> [URL] {
        let fm = FileManager.default
        var estDossier: ObjCBool = false
        guard fm.fileExists(atPath: url.path, isDirectory: &estDossier) else { return [] }
        if estDossier.boolValue {
            var res: [URL] = []
            guard let e = fm.enumerator(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { return [] }
            let exclu = nomDossierSortie.precomposedStringWithCanonicalMapping
            for case let f as URL in e {
                let estDir = (try? f.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
                if estDir {
                    if f.lastPathComponent.precomposedStringWithCanonicalMapping == exclu {
                        e.skipDescendants()
                    }
                    continue
                }
                if extensionsImages.contains(f.pathExtension.lowercased()) {
                    res.append(f)
                }
            }
            return res.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
        } else {
            return extensionsImages.contains(url.pathExtension.lowercased()) ? [url] : []
        }
    }

    func integrer(_ urls: [URL]) {
        if enCours { return }
        if bilan != nil {
            // Nouvelle série après une compression terminée
            items = []
            bilan = nil
        }
        var connus = Set(items.map { $0.url.path })
        var nouveaux: [Photo] = []
        for u in urls {
            if connus.contains(u.path) { continue }
            connus.insert(u.path)
            let attrs = try? FileManager.default.attributesOfItem(atPath: u.path)
            let t = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            nouveaux.append(Photo(url: u, taille: t))
        }
        items.append(contentsOf: nouveaux)
        for p in nouveaux {
            chargerApercu(p.id, p.url)
        }
    }

    func chargerApercu(_ id: UUID, _ url: URL) {
        DispatchQueue.global(qos: .utility).async {
            var miniature: NSImage? = nil
            var dims = ""
            if let src = CGImageSourceCreateWithURL(url as CFURL, nil) {
                if let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] {
                    let w = (props[kCGImagePropertyPixelWidth] as? Int) ?? 0
                    let h = (props[kCGImagePropertyPixelHeight] as? Int) ?? 0
                    if w > 0 && h > 0 { dims = "\(w) × \(h)" }
                }
                let opts: [CFString: Any] = [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceThumbnailMaxPixelSize: 132
                ]
                if let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) {
                    miniature = NSImage(cgImage: cg, size: NSSize(width: cg.width, height: cg.height))
                }
            }
            DispatchQueue.main.async {
                self.modifier(id) { photo in
                    photo.miniature = miniature
                    photo.dimensions = dims
                }
            }
        }
    }

    func modifier(_ id: UUID, _ f: (inout Photo) -> Void) {
        if let i = items.firstIndex(where: { $0.id == id }) {
            f(&items[i])
        }
    }

    func retirer(_ id: UUID) {
        if enCours { return }
        items.removeAll { $0.id == id }
        if items.isEmpty { bilan = nil }
    }

    func vider() {
        if enCours { return }
        items = []
        bilan = nil
    }

    func afficherDansFinder() {
        guard let b = bilan, !b.sorties.isEmpty else { return }
        NSWorkspace.shared.activateFileViewerSelecting(b.sorties)
    }

    // MARK: Compression

    func reglages() -> Reglages {
        let cible: Cible
        switch dimension {
        case .origine: cible = .aucune
        case .pourcent(let p): cible = .pourcent(p)
        case .cote(let c): cible = .cote(c)
        case .pourcentPerso: cible = .pourcent(min(99, max(1, valeurPct)))
        case .cotePerso: cible = .cote(min(20000, max(16, valeurPx)))
        }
        var dossier: URL? = nil
        if destination == .autre { dossier = dossierAutre }
        return Reglages(qualite: qualite, cible: cible, format: format, dossierFixe: dossier, garderMeta: garderMeta)
    }

    func compresser() {
        if enCours || items.isEmpty { return }
        let r = reglages()
        let liste: [(UUID, URL, Int64)] = items.map { ($0.id, $0.url, $0.taille) }
        enCours = true
        bilan = nil
        progres = 0
        for i in items.indices { items[i].etat = .attente }

        DispatchQueue.global(qos: .userInitiated).async {
            let verrouNoms = NSLock()
            let verrouRes = NSLock()
            var res = Bilan()
            res.nbTotal = liste.count
            var sortiesParIndex: [Int: URL] = [:]

            DispatchQueue.concurrentPerform(iterations: liste.count) { i in
                let id = liste[i].0
                let url = liste[i].1
                let tailleAvant = liste[i].2
                DispatchQueue.main.async {
                    self.modifier(id) { photo in photo.etat = .enCours }
                }
                do {
                    let resultat = try Compresseur.traiter(url, r, verrou: verrouNoms)
                    let sortie = resultat.0
                    let tailleApres = resultat.1
                    verrouRes.lock()
                    res.nbOk += 1
                    res.avant += tailleAvant
                    res.apres += tailleApres
                    if tailleApres > tailleAvant { res.nbPlusLourd += 1 }
                    sortiesParIndex[i] = sortie
                    verrouRes.unlock()
                    DispatchQueue.main.async {
                        self.modifier(id) { photo in photo.etat = .termine(tailleApres) }
                        self.progres += 1
                    }
                } catch {
                    let message = (error as? ErreurCompression)?.message ?? "Échec"
                    verrouRes.lock()
                    res.nbEchecs += 1
                    verrouRes.unlock()
                    DispatchQueue.main.async {
                        self.modifier(id) { photo in photo.etat = .erreur(message) }
                        self.progres += 1
                    }
                }
            }

            res.sorties = sortiesParIndex.keys.sorted().compactMap { sortiesParIndex[$0] }
            DispatchQueue.main.async {
                self.bilan = res
                self.enCours = false
            }
        }
    }
}

// MARK: - Vues

struct LigneView: View {
    let photo: Photo
    let peutRetirer: Bool
    let retirer: () -> Void

    func variationTexte(_ t: Int64) -> String {
        let avant = Double(max(photo.taille, 1))
        let delta = Int(((Double(t) - avant) / avant * 100.0).rounded())
        if delta <= 0 { return "−\(abs(delta)) %" }
        return "+\(delta) %"
    }

    func variationCouleur(_ t: Int64) -> Color {
        return t > photo.taille ? Color.orange : Color.green
    }

    var detail: String {
        var morceaux: [String] = []
        if !photo.dimensions.isEmpty { morceaux.append(photo.dimensions) }
        morceaux.append(formaterTaille(photo.taille))
        return morceaux.joined(separator: " · ")
    }

    @ViewBuilder var statut: some View {
        switch photo.etat {
        case .attente:
            EmptyView()
        case .enCours:
            ProgressView().controlSize(.small)
        case .termine(let t):
            VStack(alignment: .trailing, spacing: 2) {
                Text(formaterTaille(t)).font(.callout)
                Text(variationTexte(t)).font(.caption).foregroundColor(variationCouleur(t))
            }
        case .erreur(let message):
            Text(message).font(.caption).foregroundColor(.red).lineLimit(1)
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            Group {
                if let img = photo.miniature {
                    Image(nsImage: img).resizable().scaledToFill()
                } else {
                    Rectangle().fill(Color.secondary.opacity(0.15))
                }
            }
            .frame(width: 44, height: 44)
            .clipped()
            .cornerRadius(6)

            VStack(alignment: .leading, spacing: 2) {
                Text(photo.url.lastPathComponent).lineLimit(1).truncationMode(.middle)
                Text(detail).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            statut
            if peutRetirer {
                Button(action: retirer) {
                    Image(systemName: "xmark.circle.fill")
                }
                .buttonStyle(.plain)
                .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

struct ContentView: View {
    @ObservedObject var m = Modele.partage
    @State private var survol = false

    var body: some View {
        HStack(spacing: 0) {
            zoneGauche
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            Divider()
            panneau
                .frame(width: 320)
                .background(Color(NSColor.controlBackgroundColor))
        }
        .frame(minWidth: 840, idealWidth: 960, minHeight: 580, idealHeight: 640)
        .onDrop(of: [UTType.fileURL], isTargeted: $survol) { providers in
            m.deposer(providers)
            return true
        }
    }

    // MARK: Zone de gauche (dépôt + liste)

    var zoneGauche: some View {
        ZStack {
            if m.items.isEmpty {
                vide
            } else {
                liste
            }
            if survol {
                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(Color.accentColor.opacity(0.08))
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(Color.accentColor, style: StrokeStyle(lineWidth: 2, dash: [8, 6]))
                }
                .padding(14)
                .allowsHitTesting(false)
            }
        }
    }

    var vide: some View {
        VStack(spacing: 10) {
            Image(systemName: "photo.on.rectangle.angled")
                .font(.system(size: 54))
                .foregroundColor(.secondary)
            Text("Glissez des photos ou un dossier ici")
                .font(.title3)
            Text("ou cliquez sur « Choisir des photos… »")
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture { m.choisir() }
    }

    var titreListe: String {
        let n = m.items.count
        return "\(n) photo\(n > 1 ? "s" : "") · \(formaterTaille(m.tailleTotale))"
    }

    var liste: some View {
        VStack(spacing: 0) {
            HStack {
                Text(titreListe)
                    .font(.headline)
                Spacer()
                Button("Vider la liste") { m.vider() }
                    .disabled(m.enCours)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            Divider()
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(m.items) { p in
                        VStack(spacing: 0) {
                            LigneView(photo: p, peutRetirer: !m.enCours, retirer: { m.retirer(p.id) })
                            Divider().padding(.leading, 72)
                        }
                    }
                }
            }
        }
    }

    // MARK: Panneau de réglages

    func bloc<Contenu: View>(_ titre: String, _ valeur: String? = nil, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(titre).fontWeight(.medium)
                Spacer()
                if let v = valeur {
                    Text(v).foregroundColor(.secondary)
                }
            }
            contenu()
        }
    }

    func choixDestination(_ titre: String, actif: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 6) {
                Image(systemName: actif ? "largecircle.fill.circle" : "circle")
                    .foregroundColor(actif ? Color.accentColor : Color.secondary)
                Text(titre)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    var panneau: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Button(action: { m.choisir() }) {
                        Label("Choisir des photos…", systemImage: "photo")
                            .frame(maxWidth: .infinity)
                    }
                    .controlSize(.large)
                    .disabled(m.enCours)

                    Divider()

                    bloc("Qualité conservée", "\(Int(m.qualite)) %") {
                        Slider(value: $m.qualite, in: 1...100, step: 1)
                        Text("\(m.aideQualite) · plus le % est bas, plus le fichier est léger.")
                            .font(.caption).foregroundColor(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    bloc("Dimensions") {
                        Picker("", selection: $m.dimension) {
                            Text("Dimensions d’origine").tag(Dimension.origine)
                            Text("75 % des dimensions").tag(Dimension.pourcent(75))
                            Text("50 % des dimensions").tag(Dimension.pourcent(50))
                            Text("25 % des dimensions").tag(Dimension.pourcent(25))
                            Text("Plus grand côté : 3840 px (4K)").tag(Dimension.cote(3840))
                            Text("Plus grand côté : 2560 px").tag(Dimension.cote(2560))
                            Text("Plus grand côté : 1920 px (Full HD)").tag(Dimension.cote(1920))
                            Text("Plus grand côté : 1600 px").tag(Dimension.cote(1600))
                            Text("Plus grand côté : 1280 px").tag(Dimension.cote(1280))
                            Text("Plus grand côté : 1024 px").tag(Dimension.cote(1024))
                            Text("Plus grand côté : 800 px").tag(Dimension.cote(800))
                            Text("Pourcentage personnalisé…").tag(Dimension.pourcentPerso)
                            Text("Taille en pixels personnalisée…").tag(Dimension.cotePerso)
                        }
                        .labelsHidden()
                        .pickerStyle(.menu)

                        if m.dimension == .pourcentPerso {
                            HStack {
                                TextField("", value: $m.valeurPct, formatter: formateurEntier)
                                    .frame(width: 70)
                                Text("% des dimensions (1 à 99)")
                                    .font(.caption).foregroundColor(.secondary)
                            }
                        } else if m.dimension == .cotePerso {
                            HStack {
                                TextField("", value: $m.valeurPx, formatter: formateurEntier)
                                    .frame(width: 70)
                                Text("px, plus grand côté")
                                    .font(.caption).foregroundColor(.secondary)
                            }
                        }
                        Text("Les petites images ne sont jamais agrandies.")
                            .font(.caption).foregroundColor(.secondary)
                    }

                    bloc("Format") {
                        Picker("", selection: $m.format) {
                            ForEach(FormatSortie.allCases) { f in
                                Text(f.titre).tag(f)
                            }
                        }
                        .labelsHidden()
                        .pickerStyle(.segmented)
                        Text(m.format.aide)
                            .font(.caption).foregroundColor(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    bloc("Enregistrer dans") {
                        choixDestination("Dossier « Compressées » à côté des originales", actif: m.destination == .cote) {
                            m.destination = .cote
                        }
                        choixDestination("Un autre dossier", actif: m.destination == .autre) {
                            m.selectionnerAutreDossier()
                        }
                        if m.destination == .autre, let d = m.dossierAutre {
                            HStack {
                                Image(systemName: "folder").foregroundColor(.secondary)
                                Text(d.lastPathComponent).lineLimit(1).truncationMode(.middle)
                                Spacer()
                                Button("Changer…") { m.choisirDossierDestination() }
                            }
                            .font(.callout)
                            .padding(.leading, 20)
                        }
                        Text("Les originales ne sont jamais modifiées.")
                            .font(.caption).foregroundColor(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Toggle("Conserver les métadonnées", isOn: $m.garderMeta)
                        Text("Date, appareil, position GPS… Décochez pour les supprimer.")
                            .font(.caption).foregroundColor(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(20)
                .disabled(m.enCours)
            }

            Divider()
            pied
                .padding(20)
        }
    }

    // MARK: Pied : bouton, progression, bilan

    var texteBouton: String {
        let n = m.items.count
        if n == 0 { return "Compresser" }
        return "Compresser \(n) photo\(n > 1 ? "s" : "")"
    }

    var pied: some View {
        VStack(alignment: .leading, spacing: 10) {
            if m.enCours {
                ProgressView(value: Double(m.progres), total: Double(max(m.items.count, 1)))
                Text("Compression… \(m.progres) / \(m.items.count)")
                    .font(.caption).foregroundColor(.secondary)
            } else if let b = m.bilan {
                bilanVue(b)
            }

            Button(action: { m.compresser() }) {
                Text(texteBouton)
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .keyboardShortcut(.defaultAction)
            .disabled(m.items.isEmpty || m.enCours)
        }
    }

    func texteGain(_ b: Bilan) -> String {
        let gain = Int((100.0 * Double(b.avant - b.apres) / Double(max(b.avant, 1))).rounded())
        let signe = gain >= 0 ? "−" : "+"
        return "\(formaterTaille(b.avant)) → \(formaterTaille(b.apres))  (\(signe)\(abs(gain)) %)"
    }

    func bilanVue(_ b: Bilan) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Terminé : \(b.nbOk) photo\(b.nbOk > 1 ? "s" : "") sur \(b.nbTotal)")
                .fontWeight(.medium)
            if b.nbOk > 0 && b.avant > 0 {
                Text(texteGain(b))
                    .foregroundColor(.green)
            }
            if b.nbPlusLourd > 0 {
                Text("\(b.nbPlusLourd) photo(s) plus lourde(s) qu’avant (déjà très compressées) : gardez l’original.")
                    .font(.caption).foregroundColor(.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if b.nbEchecs > 0 {
                Text("\(b.nbEchecs) échec(s), voir la liste.")
                    .font(.caption).foregroundColor(.red)
            }
            if !b.sorties.isEmpty {
                Button("Afficher dans le Finder") { m.afficherDansFinder() }
                    .padding(.top, 2)
            }
        }
    }
}

// MARK: - Application

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationWillFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.activate(ignoringOtherApps: true)
    }

    // Glisser des photos / un dossier sur l'icône de l'app
    func application(_ sender: NSApplication, openFiles filenames: [String]) {
        Modele.partage.ajouter(filenames.map { URL(fileURLWithPath: $0) })
        sender.reply(toOpenOrPrint: .success)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}

@main
struct CompresseurApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate

    init() {
        NSWindow.allowsAutomaticWindowTabbing = false
    }

    var body: some Scene {
        WindowGroup("Compresseur de photos") {
            ContentView()
        }
        .handlesExternalEvents(matching: ["*"])
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Choisir des photos…") { Modele.partage.choisir() }
                    .keyboardShortcut("o")
            }
        }
    }
}
