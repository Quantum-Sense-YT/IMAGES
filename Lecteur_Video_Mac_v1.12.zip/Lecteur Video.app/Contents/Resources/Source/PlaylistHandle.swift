import SwiftUI
import AppKit

/// Poignée sur le bord GAUCHE de l'image (à droite de la playlist quand elle est ouverte) :
/// - glisser vers la droite : fait apparaître la playlist (et l'élargit) ;
/// - glisser vers la gauche : la rétrécit, puis la masque ;
/// - un simple clic : l'affiche / la masque.
/// Elle flotte au-dessus de la vidéo. Playlist masquée, elle disparaît (même en pause) et
/// ne réapparaît que le temps du survol de la zone au bord gauche de l'image.
struct PlaylistHandle: View {
    @EnvironmentObject private var model: PlayerModel

    private let minOpenWidth: CGFloat = 200
    private let maxWidth: CGFloat = 520

    @State private var startWidth: CGFloat?
    @State private var hovering = false

    /// Visible : playlist ouverte, ou curseur sur la poignée, ou glissement en cours.
    private var tabVisible: Bool {
        model.showPlaylist || hovering || startWidth != nil
    }

    var body: some View {
        ZStack {
            // Zone de saisie (transparente) sur toute la hauteur
            Color.clear
            // Languette visible
            ZStack {
                RoundedRectangle(cornerRadius: 7)
                    .fill(.ultraThinMaterial)
                    .opacity(hovering ? 1 : 0.65)
                Image(systemName: model.showPlaylist ? "chevron.compact.left" : "chevron.compact.right")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(Color.white.opacity(hovering ? 1 : 0.8))
            }
            .frame(width: hovering ? 20 : 14, height: 64)
            .shadow(color: .black.opacity(0.5), radius: 3)
            // Playlist rangée : la languette est invisible, sauf quand le curseur survole la poignée.
            .opacity(tabVisible ? 1 : 0)
            .frame(maxWidth: .infinity, alignment: .leading)
            .animation(.easeOut(duration: 0.15), value: tabVisible)
            .animation(.easeOut(duration: 0.12), value: hovering)
        }
        .frame(width: 24)
        .contentShape(Rectangle())
        .onHover { inside in
            hovering = inside
            if inside { NSCursor.resizeLeftRight.set() } else { NSCursor.arrow.set() }
        }
        .onTapGesture {
            withAnimation(.easeInOut(duration: 0.2)) { model.togglePlaylist() }
        }
        .gesture(
            DragGesture(minimumDistance: 3, coordinateSpace: .global)
                .onChanged { value in
                    if startWidth == nil {
                        startWidth = model.showPlaylist ? model.playlistWidth : 0
                    }
                    let proposed = (startWidth ?? 0) + value.translation.width
                    if proposed < 12 {
                        if model.showPlaylist { model.showPlaylist = false }
                        model.playlistWidth = 280          // largeur retrouvée à la prochaine ouverture
                    } else {
                        model.playlistWidth = min(proposed, maxWidth)
                        if !model.showPlaylist { model.showPlaylist = true }
                    }
                }
                .onEnded { _ in
                    startWidth = nil
                    defer { model.snapAfterPlaylistChange() }
                    guard model.showPlaylist else { return }
                    if model.playlistWidth < 150 {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            model.showPlaylist = false
                            model.playlistWidth = 280
                        }
                    } else if model.playlistWidth < minOpenWidth {
                        withAnimation(.easeOut(duration: 0.15)) { model.playlistWidth = minOpenWidth }
                    }
                }
        )
        .help("Glisser pour afficher, masquer ou redimensionner la playlist")
    }
}
