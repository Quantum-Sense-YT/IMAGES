import SwiftUI

struct ControlsBar: View {
    @EnvironmentObject private var model: PlayerModel

    var body: some View {
        HStack(spacing: 6) {
            // Gauche : reculer, lecture/pause, avancer, stop, playlist
            HStack(spacing: 0) {
                BarButton(systemName: "backward.fill", help: "Reculer de 10 s (←)") { model.skip(seconds: -10) }
                BarButton(systemName: model.isPlaying ? "pause.fill" : "play.fill",
                          help: model.isPlaying ? "Pause (Espace)" : "Lecture (Espace)",
                          size: 15) { model.togglePlayPause() }
                BarButton(systemName: "forward.fill", help: "Avancer de 10 s (→)") { model.skip(seconds: 10) }
            }
            BarButton(systemName: "stop.fill", help: "Arrêter", size: 11) { model.stop() }
            BarButton(systemName: "list.bullet", help: "Afficher/masquer la playlist (⌘L)") { model.togglePlaylist() }

            // Milieu : progression
            Slider(
                value: Binding(
                    get: { model.position },
                    set: { newValue in
                        model.position = newValue
                        if model.isScrubbing { model.updateScrubPreview() }
                    }
                ),
                in: 0...1,
                onEditingChanged: { editing in
                    model.isScrubbing = editing
                    if !editing { model.seek(to: model.position) }
                }
            )
            .controlSize(.small)
            .focusable(false)
            .disabled(model.currentIndex == nil)

            // Droite : temps, volume, Picture in Picture, réglages, plein écran
            Text(model.elapsedText)
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundStyle(Color.white.opacity(0.75))
                .lineLimit(1)
                .fixedSize()

            HStack(spacing: 4) {
                Button { model.toggleMute() } label: {
                    Image(systemName: (model.isMuted || model.volume == 0) ? "speaker.slash.fill" : "speaker.fill")
                        .font(.system(size: 11))
                        .foregroundStyle(Color.white.opacity(0.75))
                        .frame(width: 18, height: 24)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .focusable(false)
                .help(model.isMuted ? "Réactiver le son (M)" : "Couper le son (M)")

                Slider(value: $model.volume, in: 0...100)
                    .controlSize(.small)
                    .frame(width: 64)
                    .focusable(false)
            }

            BarButton(systemName: "pip.enter",
                      help: "Picture in Picture (P) : mini-fenêtre au-dessus de toutes les apps, en haut à droite") {
                model.togglePiP()
            }
            advancedMenu
            BarButton(systemName: "arrow.up.left.and.arrow.down.right", help: "Plein écran (F)") { model.toggleFullScreen() }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.08), lineWidth: 0.5))
        .padding(8)
        // Panneau « Format avancé » (ouvert depuis le menu Vidéo > Format)
        .popover(isPresented: $model.advancedFormatOpen, arrowEdge: .top) {
            advancedFormatPanel
        }
    }

    /// Paramètres avancés : piste audio, sous-titres, format de l'image, vitesse de lecture.
    private var advancedMenu: some View {
        Menu {
            Menu("Piste audio / langue") {
                Picker("Piste audio", selection: Binding(
                    get: { model.selectedAudioTrack },
                    set: { model.selectAudioTrack($0) }
                )) {
                    ForEach(model.audioTracks) { track in
                        Text(track.name).tag(track.id)
                    }
                }
                .pickerStyle(.inline)
            }
            .disabled(model.audioTracks.isEmpty)

            Menu("Sous-titres") {
                Picker("Sous-titres", selection: Binding(
                    get: { model.selectedSubtitleTrack },
                    set: { model.selectSubtitleTrack($0) }
                )) {
                    ForEach(model.subtitleTracks) { track in
                        Text(track.name).tag(track.id)
                    }
                }
                .pickerStyle(.inline)
                Divider()
                Button("Ajouter un fichier de sous-titres…") { model.presentSubtitlePanel() }
            }
            .disabled(model.currentIndex == nil)

            Menu("Format de l’image") {
                Picker("Format de l’image", selection: Binding(
                    get: { model.aspectID },
                    set: { model.setAspect($0) }
                )) {
                    ForEach(PlayerModel.aspectOptions) { option in
                        Text(option.label).tag(option.id)
                    }
                }
                .pickerStyle(.inline)
                Divider()
                Toggle("Remplir la fenêtre (rogne l’image)", isOn: Binding(
                    get: { model.fillWindow },
                    set: { model.setFill($0) }
                ))
                Toggle("Taille d’origine (100 %)", isOn: Binding(
                    get: { model.originalSize },
                    set: { model.setOriginalSize($0) }
                ))
                Divider()
                Button("Ajuster la fenêtre à la vidéo") { model.fitWindowToVideo() }
                Divider()
                Button("Format avancé (déformation libre)…") { model.advancedFormatOpen = true }
            }
            .disabled(model.currentIndex == nil)

            Menu("Vitesse de lecture") {
                Picker("Vitesse", selection: Binding(
                    get: { model.rate },
                    set: { model.setRate($0) }
                )) {
                    ForEach(PlayerModel.availableRates, id: \.self) { value in
                        Text(String(format: "%g×", value)).tag(value)
                    }
                }
                .pickerStyle(.inline)
            }
        } label: {
            Image(systemName: "gearshape")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.92))
                .frame(width: 28, height: 24)
        }
        .menuStyle(.borderlessButton)
        .menuIndicator(.hidden)
        .fixedSize()
        .help("Paramètres avancés : piste audio, sous-titres, format de l’image, vitesse de lecture")
    }

    /// Deux curseurs : déformation horizontale (largeur) et verticale (hauteur).
    private var advancedFormatPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Format avancé")
                .font(.headline)

            stretchSlider(title: "Horizontal (largeur)", symbol: "arrow.left.and.right",
                          value: $model.stretchX)
            stretchSlider(title: "Vertical (hauteur)", symbol: "arrow.up.and.down",
                          value: $model.stretchY)

            HStack {
                Text("Étire l’image à partir du centre ; 100 % = normal.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("Réinitialiser") { model.resetStretch() }
                    .disabled(!model.isStretched)
            }
        }
        .padding(16)
        .frame(width: 320)
    }

    private func stretchSlider(title: String, symbol: String, value: Binding<Double>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Image(systemName: symbol)
                Text(title)
                Spacer()
                Text("\(Int((value.wrappedValue * 100).rounded())) %")
                    .monospacedDigit()
                    .foregroundStyle(.secondary)
            }
            Slider(value: value, in: 0.5...2.0, step: 0.01)
        }
    }
}

/// Barre réduite affichée en mode Picture in Picture.
struct PipControlsBar: View {
    @EnvironmentObject private var model: PlayerModel

    var body: some View {
        HStack(spacing: 4) {
            IconButton(systemName: model.isPlaying ? "pause.fill" : "play.fill",
                       help: model.isPlaying ? "Pause (Espace)" : "Lecture (Espace)",
                       size: 15) { model.togglePlayPause() }

            Slider(
                value: Binding(
                    get: { model.position },
                    set: { newValue in
                        model.position = newValue
                        if model.isScrubbing { model.updateScrubPreview() }
                    }
                ),
                in: 0...1,
                onEditingChanged: { editing in
                    model.isScrubbing = editing
                    if !editing { model.seek(to: model.position) }
                }
            )
            .focusable(false)
            .disabled(model.currentIndex == nil)

            Text(model.elapsedText)
                .font(.system(size: 10, design: .monospaced))
                .lineLimit(1)
                .fixedSize()

            IconButton(systemName: "pip.exit", help: "Quitter le Picture in Picture", size: 14) {
                model.exitPiP()
            }
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 2)
        .background(.ultraThinMaterial, in: Capsule())
        .padding(8)
    }
}

private struct IconButton: View {
    let systemName: String
    let help: String
    var size: CGFloat = 15
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: size))
                .frame(width: 28, height: 26)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .focusable(false)
        .help(help)
    }
}

/// Bouton discret : icône blanche, léger halo au survol.
private struct BarButton: View {
    let systemName: String
    let help: String
    var size: CGFloat = 13
    let action: () -> Void
    @State private var hovering = false

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: size, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.92))
                .frame(width: 28, height: 24)
                .background(
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .fill(Color.white.opacity(hovering ? 0.14 : 0))
                )
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .focusable(false)
        .onHover { hovering = $0 }
        .help(help)
    }
}
