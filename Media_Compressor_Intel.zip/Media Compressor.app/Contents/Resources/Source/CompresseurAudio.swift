// Onglet Audio — conversion / compression audio (MP3, M4A, M4R, OGG, ALAC, FLAC, WAV, AIFF) et édition des tags.
// Moteur : ffmpeg (macOS ne sait pas encoder le MP3 nativement). Installation : brew install ffmpeg
// Ce fichier est compilé avec l'option -D AUDIO ; si sa compilation échoue, le lanceur retombe sur la version vidéo seule.

import SwiftUI
import AppKit
import AVFoundation
import CoreMedia
import UniformTypeIdentifiers

let extensionsAudio: Set<String> = ["mp3", "m4a", "aac", "wav", "aif", "aiff", "aifc", "caf", "flac", "ogg", "oga", "opus", "wma", "wv", "ape", "amr", "m4b", "mka", "mp2"]

// MARK: - Types

enum FormatAudio: String, CaseIterable, Identifiable {
    case mp3, wav, aiff, flac, aac, alac, m4r, ogg

    // Formats proposés dans l'interface. « .aac » = AAC avec perte dans un fichier .m4a : il est affiché sous le nom « M4A ».
    static var allCases: [FormatAudio] {
        return [.mp3, .wav, .aiff, .flac, .alac, .aac, .m4r, .ogg]
    }

    var id: String { rawValue }

    var titre: String {
        switch self {
        case .mp3: return "MP3"
        case .aac: return "M4A"
        case .m4r: return "M4R"
        case .ogg: return "OGG"
        case .alac: return "ALAC"
        case .flac: return "FLAC"
        case .wav: return "WAV"
        case .aiff: return "AIFF"
        }
    }

    var ext: String {
        switch self {
        case .mp3: return "mp3"
        case .aac: return "m4a"
        case .m4r: return "m4r"
        case .ogg: return "ogg"
        case .alac: return "m4a"
        case .flac: return "flac"
        case .wav: return "wav"
        case .aiff: return "aiff"
        }
    }

    var avecPerte: Bool {
        return self == .mp3 || self == .aac || self == .m4r || self == .ogg
    }

    var accepteCouverture: Bool {
        switch self {
        case .mp3, .aac, .alac, .flac, .m4r: return true
        case .wav, .aiff, .ogg: return false
        }
    }

    var aide: String {
        switch self {
        case .mp3: return "MP3 : lisible partout, avec tags ID3 (titre, album, année…)."
        case .aac: return "M4A : AAC avec perte dans un fichier .m4a, meilleure qualité que le MP3 à débit égal, lisible sur tous les appareils récents."
        case .m4r: return "M4R : AAC avec perte, extension des sonneries iPhone (à ajouter via le Finder ; l'iPhone limite une sonnerie à environ 40 s)."
        case .ogg: return "OGG : Vorbis avec perte, format ouvert (minimum appliqué : 32 kb/s)."
        case .alac: return "ALAC (.m4a) : sans perte, format Apple."
        case .flac: return "FLAC : sans perte, format ouvert, plus léger que le WAV."
        case .wav: return "WAV : non compressé, très lourd, lisible partout."
        case .aiff: return "AIFF : non compressé, format Apple."
        }
    }
}

struct TagsAudio {
    var titre = ""
    var artiste = ""
    var album = ""
    var artisteAlbum = ""
    var annee = ""
    var genre = ""
    var piste = ""
    var commentaire = ""
    var supprimerOrigine = false
}

struct ReglagesAudio {
    var format: FormatAudio
    var debitKbps: Int
    var frequence: Int          // 0 = origine
    var canaux: Int             // 0 = origine, 1 = mono, 2 = stéréo
    var tags: TagsAudio
    var numeroter: Bool
    var dossierFixe: URL?
}

struct FichierAudio: Identifiable {
    let id = UUID()
    let url: URL
    var sortie: URL? = nil
    var taille: Int64
    var duree: Double = 0
    var details: String = ""
    var frequence: Double = 0
    var canaux: Int = 0
    var etat: Etat = .attente
}

// Suivi de la sortie de ffmpeg (progression et messages d'erreur)
final class SuiviFFmpeg {
    private let verrou = NSLock()
    private var reste = ""
    private var journal = ""
    private var duree: Double
    private var derniereMaj = Date.distantPast
    private let progression: (Double) -> Void

    init(duree: Double, progression: @escaping (Double) -> Void) {
        self.duree = duree
        self.progression = progression
    }

    func sortie(_ data: Data) {
        guard let texte = String(data: data, encoding: .utf8) else { return }
        verrou.lock()
        reste += texte
        var lignes = reste.components(separatedBy: "\n")
        reste = lignes.removeLast()
        let dureeTotale = duree
        verrou.unlock()

        for ligne in lignes {
            if ligne.hasPrefix("out_time_us=") || ligne.hasPrefix("out_time_ms=") {
                let valeur = ligne.split(separator: "=", maxSplits: 1).last.map { String($0) } ?? ""
                if let microsecondes = Double(valeur.trimmingCharacters(in: .whitespaces)), dureeTotale > 0 {
                    let fraction = min(1.0, max(0.0, microsecondes / 1_000_000 / dureeTotale))
                    let maintenant = Date()
                    verrou.lock()
                    let assez = maintenant.timeIntervalSince(derniereMaj) > 0.3
                    if assez { derniereMaj = maintenant }
                    verrou.unlock()
                    if assez { progression(fraction) }
                }
            }
        }
    }

    func erreur(_ data: Data) {
        guard let texte = String(data: data, encoding: .utf8) else { return }
        verrou.lock()
        journal += texte
        if journal.count > 6000 {
            journal = String(journal.suffix(4000))
        }
        if duree <= 0, let r = journal.range(of: "Duration: ") {
            let extrait = journal[r.upperBound...].prefix(11)
            let morceaux = extrait.split(separator: ":")
            if morceaux.count == 3, let h = Double(morceaux[0]), let m = Double(morceaux[1]), let s = Double(morceaux[2]) {
                duree = h * 3600 + m * 60 + s
            }
        }
        verrou.unlock()
    }

    var dernierMessage: String {
        verrou.lock()
        defer { verrou.unlock() }
        let lignes = journal.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        return lignes.last ?? "Échec de la conversion"
    }
}

// MARK: - Moteur (ffmpeg)

enum MoteurAudio {

    static func chemin() -> String? {
        var candidats = ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/opt/local/bin/ffmpeg", "/usr/bin/ffmpeg"]
        candidats.append(NSHomeDirectory() + "/Library/Application Support/Media Compressor/ffmpeg")
        candidats.append(NSHomeDirectory() + "/Library/Application Support/Compresseur de videos/ffmpeg")
        for c in candidats {
            if FileManager.default.isExecutableFile(atPath: c) { return c }
        }
        return nil
    }

    static func lancer(_ chemin: String, _ args: [String]) -> String {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: chemin)
        p.arguments = args
        let tube = Pipe()
        p.standardOutput = tube
        p.standardError = FileHandle.nullDevice
        p.standardInput = FileHandle.nullDevice
        do {
            try p.run()
        } catch {
            return ""
        }
        let data = tube.fileHandleForReading.readDataToEndOfFile()
        p.waitUntilExit()
        return String(data: data, encoding: .utf8) ?? ""
    }

    // Noms des encodeurs audio disponibles dans cette version de ffmpeg
    static func encodeurs(_ chemin: String) -> Set<String> {
        let texte = lancer(chemin, ["-hide_banner", "-encoders"])
        var noms = Set<String>()
        for ligne in texte.split(separator: "\n") {
            let morceaux = ligne.split(separator: " ", omittingEmptySubsequences: true)
            if morceaux.count >= 2 && morceaux[0].count == 6 && morceaux[0].hasPrefix("A") {
                noms.insert(String(morceaux[1]))
            }
        }
        return noms
    }

    static func arguments(entree: URL, sortie: URL, r: ReglagesAudio, codecAAC: String, avecPochette: Bool, index: Int, total: Int) -> [String] {
        var a: [String] = ["-hide_banner", "-nostdin", "-y", "-i", entree.path, "-progress", "pipe:1", "-nostats"]

        if avecPochette {
            a += ["-map", "0:a:0", "-map", "0:v:0?", "-c:v", "copy"]
        } else {
            a += ["-map", "0:a:0", "-vn"]
        }

        switch r.format {
        case .mp3:
            a += ["-c:a", "libmp3lame", "-b:a", "\(r.debitKbps)k", "-id3v2_version", "3", "-write_id3v1", "1"]
        case .aac:
            a += ["-c:a", codecAAC, "-b:a", "\(r.debitKbps)k", "-movflags", "+faststart"]
        case .m4r:
            // ffmpeg ne connaît pas l'extension .m4r : on impose le conteneur « ipod » (même contenu qu'un .m4a)
            a += ["-c:a", codecAAC, "-b:a", "\(r.debitKbps)k", "-f", "ipod", "-movflags", "+faststart"]
        case .ogg:
            a += ["-c:a", "libvorbis", "-b:a", "\(max(32, r.debitKbps))k"]
        case .alac:
            a += ["-c:a", "alac", "-movflags", "+faststart"]
        case .flac:
            a += ["-c:a", "flac", "-compression_level", "8"]
        case .wav:
            a += ["-c:a", "pcm_s16le"]
        case .aiff:
            a += ["-c:a", "pcm_s16be"]
        }

        if r.frequence > 0 { a += ["-ar", "\(r.frequence)"] }
        if r.canaux > 0 { a += ["-ac", "\(r.canaux)"] }

        // Tags : on garde ceux d'origine, sauf ceux que l'utilisateur renseigne
        if r.tags.supprimerOrigine {
            a += ["-map_metadata", "-1"]
        }
        func ajouterTag(_ cle: String, _ valeur: String) {
            let v = valeur.trimmingCharacters(in: .whitespacesAndNewlines)
            if !v.isEmpty {
                a += ["-metadata", "\(cle)=\(v)"]
            }
        }
        if total == 1 {
            ajouterTag("title", r.tags.titre)
            ajouterTag("track", r.tags.piste)
        } else if r.numeroter {
            ajouterTag("track", "\(index + 1)/\(total)")
        }
        ajouterTag("artist", r.tags.artiste)
        ajouterTag("album", r.tags.album)
        ajouterTag("album_artist", r.tags.artisteAlbum)
        ajouterTag("date", r.tags.annee)
        ajouterTag("genre", r.tags.genre)
        ajouterTag("comment", r.tags.commentaire)

        a.append(sortie.path)
        return a
    }

    // Retourne : fichier créé, taille
    static func convertir(_ source: URL, _ r: ReglagesAudio, ffmpeg: String, codecAAC: String, dureeConnue: Double,
                          index: Int, total: Int, controle: Controle, progression: @escaping (Double) -> Void) throws -> (URL, Int64) {
        let fm = FileManager.default
        let dossier: URL
        if let fixe = r.dossierFixe {
            dossier = fixe
        } else {
            dossier = source.deletingLastPathComponent().appendingPathComponent(nomDossierSortie, isDirectory: true)
        }
        do {
            try fm.createDirectory(at: dossier, withIntermediateDirectories: true, attributes: nil)
        } catch {
            throw ErreurCompression(message: "Dossier inaccessible")
        }
        let base = source.deletingPathExtension().lastPathComponent
        let sortie = Compresseur.cheminUnique(dossier: dossier, base: base, ext: r.format.ext)
        let temporaire = dossier.appendingPathComponent(".\(UUID().uuidString).encours.\(r.format.ext)")

        // La pochette est copiée si possible ; en cas d'échec on réessaie sans elle
        let peutAvoirPochette = r.format.accepteCouverture && !r.tags.supprimerOrigine
            && extensionsAudio.contains(source.pathExtension.lowercased())
        let tentatives: [Bool] = peutAvoirPochette ? [true, false] : [false]

        var message = "Échec de la conversion"
        var reussi = false

        for avecPochette in tentatives {
            try? fm.removeItem(at: temporaire)
            let args = arguments(entree: source, sortie: temporaire, r: r, codecAAC: codecAAC,
                                 avecPochette: avecPochette, index: index, total: total)
            let suivi = SuiviFFmpeg(duree: dureeConnue, progression: progression)

            let p = Process()
            p.executableURL = URL(fileURLWithPath: ffmpeg)
            p.arguments = args
            let tubeSortie = Pipe()
            let tubeErreur = Pipe()
            p.standardOutput = tubeSortie
            p.standardError = tubeErreur
            p.standardInput = FileHandle.nullDevice

            tubeSortie.fileHandleForReading.readabilityHandler = { h in
                let d = h.availableData
                if d.isEmpty {
                    h.readabilityHandler = nil
                } else {
                    suivi.sortie(d)
                }
            }
            tubeErreur.fileHandleForReading.readabilityHandler = { h in
                let d = h.availableData
                if d.isEmpty {
                    h.readabilityHandler = nil
                } else {
                    suivi.erreur(d)
                }
            }

            do {
                try p.run()
            } catch {
                throw ErreurCompression(message: "ffmpeg ne démarre pas")
            }
            while p.isRunning {
                if controle.annule {
                    p.terminate()
                    break
                }
                Thread.sleep(forTimeInterval: 0.1)
            }
            p.waitUntilExit()
            tubeSortie.fileHandleForReading.readabilityHandler = nil
            tubeErreur.fileHandleForReading.readabilityHandler = nil
            suivi.sortie(tubeSortie.fileHandleForReading.readDataToEndOfFile())
            suivi.erreur(tubeErreur.fileHandleForReading.readDataToEndOfFile())

            if controle.annule {
                try? fm.removeItem(at: temporaire)
                throw ErreurCompression(message: "Annulé")
            }
            if p.terminationStatus == 0 {
                reussi = true
                break
            }
            message = suivi.dernierMessage
        }

        if !reussi || !fm.fileExists(atPath: temporaire.path) {
            try? fm.removeItem(at: temporaire)
            throw ErreurCompression(message: message)
        }

        do {
            try fm.moveItem(at: temporaire, to: sortie)
        } catch {
            try? fm.removeItem(at: temporaire)
            throw ErreurCompression(message: "Enregistrement impossible")
        }

        // Le fichier garde les dates de l'original
        if let attrs = try? fm.attributesOfItem(atPath: source.path) {
            var dates: [FileAttributeKey: Any] = [:]
            if let creation = attrs[.creationDate] { dates[.creationDate] = creation }
            if let modif = attrs[.modificationDate] { dates[.modificationDate] = modif }
            try? fm.setAttributes(dates, ofItemAtPath: sortie.path)
        }

        let attrsSortie = try? fm.attributesOfItem(atPath: sortie.path)
        let taille = (attrsSortie?[.size] as? NSNumber)?.int64Value ?? 0
        progression(1.0)
        return (sortie, taille)
    }

    // Estimation du poids final
    static func estimer(_ f: FichierAudio, _ r: ReglagesAudio) -> Int64? {
        if f.duree <= 0 { return nil }
        if r.format.avecPerte {
            return Int64(Double(r.debitKbps) * 1000 * f.duree / 8)
        }
        if f.frequence <= 0 || f.canaux <= 0 { return nil }
        let frequence = r.frequence > 0 ? Double(r.frequence) : f.frequence
        let canaux = r.canaux > 0 ? r.canaux : f.canaux
        let pcm = frequence * Double(canaux) * 2 * f.duree
        switch r.format {
        case .wav, .aiff: return Int64(pcm)
        default: return Int64(pcm * 0.6)
        }
    }
}

// MARK: - Modèle

final class ModeleAudio: ObservableObject {
    static let partage = ModeleAudio()

    @Published var items: [FichierAudio] = []
    @Published var format: FormatAudio = .mp3
    @Published var sonnerie: Bool = false      // option de M4A : produire un fichier .m4r (sonnerie iPhone)

    // Format réellement utilisé pour la conversion (M4A + option sonnerie = M4R)
    var formatEffectif: FormatAudio {
        return (format == .aac && sonnerie) ? .m4r : format
    }
    @Published var debit: Int = 320
    @Published var frequence: Int = 0
    @Published var canaux: Int = 0

    @Published var titre = ""
    @Published var artiste = ""
    @Published var album = ""
    @Published var artisteAlbum = ""
    @Published var annee = ""
    @Published var genre = ""
    @Published var piste = ""
    @Published var commentaire = ""
    @Published var supprimerTags = false
    @Published var numeroter = false

    @Published var destination: Destination = .cote
    @Published var dossierAutre: URL? = nil
    @Published var enCours = false
    @Published var progres: Double = 0
    @Published var bilan: Bilan? = nil

    @Published var ffmpegChemin: String? = nil
    @Published var encodeurs: Set<String> = []
    @Published var verifie = false

    var controle: Controle? = nil

    init() {
        chercherFFmpeg()
    }

    func chercherFFmpeg() {
        DispatchQueue.global(qos: .utility).async {
            let chemin = MoteurAudio.chemin()
            var noms = Set<String>()
            if let c = chemin { noms = MoteurAudio.encodeurs(c) }
            DispatchQueue.main.async {
                self.ffmpegChemin = chemin
                self.encodeurs = noms
                self.verifie = true
            }
        }
    }

    var ffmpegPret: Bool {
        return ffmpegChemin != nil
    }

    var encodeurDisponible: Bool {
        if !ffmpegPret || encodeurs.isEmpty { return ffmpegPret }
        switch format {
        case .mp3: return encodeurs.contains("libmp3lame")
        case .ogg: return encodeurs.contains("libvorbis")
        default: return true
        }
    }

    var avertissement: String? {
        if verifie && !ffmpegPret { return nil }     // le bandeau d'installation s'en charge
        if ffmpegPret && !encodeurDisponible {
            let nom = (format == .ogg) ? "OGG (Vorbis)" : "MP3 (LAME)"
            return "Cette version de ffmpeg n’inclut pas l’encodeur \(nom). Réinstallez-la avec Homebrew : brew install ffmpeg"
        }
        return nil
    }

    var tailleTotale: Int64 {
        return items.reduce(Int64(0)) { $0 + $1.taille }
    }

    var dureeTotale: Double {
        return items.reduce(0.0) { $0 + $1.duree }
    }

    func reglages() -> ReglagesAudio {
        var tags = TagsAudio()
        tags.titre = titre
        tags.artiste = artiste
        tags.album = album
        tags.artisteAlbum = artisteAlbum
        tags.annee = annee
        tags.genre = genre
        tags.piste = piste
        tags.commentaire = commentaire
        tags.supprimerOrigine = supprimerTags
        var dossier: URL? = nil
        if destination == .autre { dossier = dossierAutre }
        return ReglagesAudio(format: formatEffectif, debitKbps: max(8, debit), frequence: frequence, canaux: canaux,
                             tags: tags, numeroter: numeroter, dossierFixe: dossier)
    }

    func estimation(_ f: FichierAudio, _ r: ReglagesAudio) -> Int64? {
        return MoteurAudio.estimer(f, r)
    }

    // (poids avant, poids estimé après) pour les fichiers dont l'estimation est possible
    var estimationTotale: (Int64, Int64)? {
        let r = reglages()
        var avant: Int64 = 0
        var apres: Int64 = 0
        var n = 0
        for f in items {
            if let e = estimation(f, r) {
                avant += f.taille
                apres += e
                n += 1
            }
        }
        return n > 0 ? (avant, apres) : nil
    }

    // MARK: Ajout de fichiers

    func choisir() {
        if enCours { return }
        let panneau = NSOpenPanel()
        panneau.title = "Choisir des fichiers audio ou un dossier"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = true
        panneau.canChooseDirectories = true
        panneau.allowsMultipleSelection = true
        panneau.allowedContentTypes = [UTType.audio]
        if panneau.runModal() == .OK {
            ajouter(panneau.urls)
        }
    }

    func choisirDossierDestination() {
        let panneau = NSOpenPanel()
        panneau.title = "Dossier de destination"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = false
        panneau.canChooseDirectories = true
        panneau.canCreateDirectories = true
        panneau.allowsMultipleSelection = false
        if panneau.runModal() == .OK, let u = panneau.url {
            dossierAutre = u
            destination = .autre
        }
    }

    func selectionnerAutreDossier() {
        if dossierAutre == nil {
            choisirDossierDestination()
        } else {
            destination = .autre
        }
    }

    func deposer(_ providers: [NSItemProvider]) {
        let groupe = DispatchGroup()
        let verrou = NSLock()
        var urls: [URL] = []
        for p in providers {
            groupe.enter()
            p.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                var u: URL? = nil
                if let d = item as? Data {
                    u = URL(dataRepresentation: d, relativeTo: nil)
                } else if let x = item as? URL {
                    u = x
                }
                if let u = u {
                    verrou.lock()
                    urls.append(u)
                    verrou.unlock()
                }
                groupe.leave()
            }
        }
        groupe.notify(queue: .main) {
            // Détection automatique : chaque fichier va dans l'onglet qui correspond à son type
            RouteurFichiers.router(urls)
        }
    }

    func ajouter(_ urls: [URL]) {
        if enCours { return }
        DispatchQueue.global(qos: .userInitiated).async {
            var trouves: [URL] = []
            for u in urls {
                trouves.append(contentsOf: ModeleAudio.fichiers(dans: u))
            }
            DispatchQueue.main.async {
                self.integrer(trouves)
            }
        }
    }

    static func fichiers(dans url: URL) -> [URL] {
        let fm = FileManager.default
        var estDossier: ObjCBool = false
        guard fm.fileExists(atPath: url.path, isDirectory: &estDossier) else { return [] }
        if estDossier.boolValue {
            var res: [URL] = []
            guard let e = fm.enumerator(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { return [] }
            let exclu = nomDossierSortie.precomposedStringWithCanonicalMapping
            for case let f as URL in e {
                let estDir = (try? f.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
                if estDir {
                    if f.lastPathComponent.precomposedStringWithCanonicalMapping == exclu {
                        e.skipDescendants()
                    }
                    continue
                }
                if extensionsAudio.contains(f.pathExtension.lowercased()) {
                    res.append(f)
                }
            }
            return res.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
        } else {
            return extensionsAudio.contains(url.pathExtension.lowercased()) ? [url] : []
        }
    }

    func integrer(_ urls: [URL]) {
        if enCours { return }
        if bilan != nil {
            items = []
            bilan = nil
        }
        var connus = Set(items.map { $0.url.path })
        var nouveaux: [FichierAudio] = []
        for u in urls {
            if connus.contains(u.path) { continue }
            connus.insert(u.path)
            let attrs = try? FileManager.default.attributesOfItem(atPath: u.path)
            let t = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            nouveaux.append(FichierAudio(url: u, taille: t))
        }
        items.append(contentsOf: nouveaux)
        for f in nouveaux {
            analyser(f.id, f.url)
        }
    }

    func analyser(_ id: UUID, _ url: URL) {
        DispatchQueue.global(qos: .utility).async {
            var duree = 0.0
            var frequence = 0.0
            var canaux = 0
            var debit = 0.0

            let asset = AVURLAsset(url: url)
            if asset.isReadable, let piste = asset.tracks(withMediaType: .audio).first {
                let d = CMTimeGetSeconds(asset.duration)
                duree = d.isFinite ? d : 0
                debit = Double(piste.estimatedDataRate)
                if let descriptions = piste.formatDescriptions as? [CMFormatDescription], let desc = descriptions.first {
                    if let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(desc)?.pointee {
                        frequence = asbd.mSampleRate
                        canaux = Int(asbd.mChannelsPerFrame)
                    }
                }
            }

            var morceaux: [String] = [url.pathExtension.uppercased()]
            let dureeTexte = formaterDuree(duree)
            if !dureeTexte.isEmpty { morceaux.append(dureeTexte) }
            if debit > 0 { morceaux.append("\(Int((debit / 1000).rounded())) kb/s") }
            if frequence > 0 {
                let khz = String(format: "%.1f", frequence / 1000).replacingOccurrences(of: ".", with: ",")
                morceaux.append("\(khz) kHz")
            }
            if canaux == 1 { morceaux.append("mono") }
            if canaux == 2 { morceaux.append("stéréo") }
            let details = morceaux.joined(separator: " · ")

            DispatchQueue.main.async {
                self.modifier(id) { f in
                    f.duree = duree
                    f.frequence = frequence
                    f.canaux = canaux
                    f.details = details
                }
            }
        }
    }

    func modifier(_ id: UUID, _ f: (inout FichierAudio) -> Void) {
        if let i = items.firstIndex(where: { $0.id == id }) {
            f(&items[i])
        }
    }

    func retirer(_ id: UUID) {
        if enCours { return }
        items.removeAll { $0.id == id }
        if items.isEmpty { bilan = nil }
    }

    func vider() {
        if enCours { return }
        items = []
        bilan = nil
    }

    func afficherDansFinder() {
        guard let b = bilan, !b.sorties.isEmpty else { return }
        NSWorkspace.shared.activateFileViewerSelecting(b.sorties)
    }

    func annuler() {
        controle?.annuler()
    }

    // MARK: Conversion

    func compresser() {
        if enCours || items.isEmpty { return }
        guard let ffmpeg = ffmpegChemin, encodeurDisponible else { return }
        let r = reglages()
        let codecAAC = encodeurs.contains("aac_at") ? "aac_at" : "aac"
        let liste: [(UUID, URL, Int64, Double)] = items.map { ($0.id, $0.url, $0.taille, $0.duree) }
        let ctrl = Controle()
        controle = ctrl
        enCours = true
        bilan = nil
        progres = 0
        for i in items.indices {
            items[i].etat = .attente
        }

        DispatchQueue.global(qos: .userInitiated).async {
            let activite = ProcessInfo.processInfo.beginActivity(options: [.userInitiated, .idleSystemSleepDisabled], reason: "Conversion audio")

            var res = Bilan()
            res.nbTotal = liste.count
            let total = Double(liste.count)

            for (index, element) in liste.enumerated() {
                if ctrl.annule { break }
                let id = element.0
                let url = element.1
                let tailleAvant = element.2
                let duree = element.3
                DispatchQueue.main.async {
                    self.modifier(id) { f in f.etat = .enCours(0) }
                }
                do {
                    let resultat = try MoteurAudio.convertir(url, r, ffmpeg: ffmpeg, codecAAC: codecAAC, dureeConnue: duree,
                                                             index: index, total: liste.count, controle: ctrl) { fraction in
                        DispatchQueue.main.async {
                            self.modifier(id) { f in f.etat = .enCours(fraction) }
                            self.progres = (Double(index) + fraction) / total
                        }
                    }
                    let tailleApres = resultat.1
                    res.nbOk += 1
                    res.avant += tailleAvant
                    res.apres += tailleApres
                    if tailleApres > tailleAvant { res.nbPlusLourd += 1 }
                    res.sorties.append(resultat.0)
                    DispatchQueue.main.async {
                        self.modifier(id) { f in f.sortie = resultat.0; f.etat = .termine(tailleApres) }
                        self.progres = Double(index + 1) / total
                    }
                } catch {
                    if ctrl.annule {
                        DispatchQueue.main.async {
                            self.modifier(id) { f in f.etat = .attente }
                        }
                        break
                    }
                    let message = (error as? ErreurCompression)?.message ?? "Échec"
                    res.nbEchecs += 1
                    DispatchQueue.main.async {
                        self.modifier(id) { f in f.etat = .erreur(message) }
                        self.progres = Double(index + 1) / total
                    }
                }
            }

            res.annule = ctrl.annule
            ProcessInfo.processInfo.endActivity(activite)
            DispatchQueue.main.async {
                self.bilan = res
                self.enCours = false
                self.controle = nil
            }
        }
    }
}

// MARK: - Vues

struct LigneAudioView: View {
    let fichier: FichierAudio
    let estimation: Int64?
    let peutRetirer: Bool
    let retirer: () -> Void

    func variationTexte(_ t: Int64) -> String {
        let avant = Double(max(fichier.taille, 1))
        let delta = Int(((Double(t) - avant) / avant * 100.0).rounded())
        if delta <= 0 { return "−\(abs(delta)) %" }
        return "+\(delta) %"
    }

    func variationCouleur(_ t: Int64) -> Color {
        return t > fichier.taille ? Color.orange : Color.green
    }

    var detail: String {
        var morceaux: [String] = []
        if !fichier.details.isEmpty { morceaux.append(fichier.details) }
        morceaux.append(formaterTaille(fichier.taille))
        return morceaux.joined(separator: " · ")
    }

    @ViewBuilder var statut: some View {
        switch fichier.etat {
        case .attente:
            if let e = estimation {
                Text("≈ \(formaterTaille(e))")
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .help("Poids estimé après conversion avec les réglages actuels.")
            } else {
                EmptyView()
            }
        case .enCours(let fraction):
            VStack(alignment: .trailing, spacing: 3) {
                ProgressView(value: fraction).frame(width: 90)
                Text("\(Int((fraction * 100).rounded())) %").font(.caption).foregroundColor(.secondary)
            }
        case .termine(let t):
            HStack(spacing: 10) {
                BoutonDossierSortie(url: fichier.sortie)
                VStack(alignment: .trailing, spacing: 2) {
                    Text(formaterTaille(t)).font(.callout)
                    Text(variationTexte(t)).font(.caption).foregroundColor(variationCouleur(t))
                }
            }
        case .erreur(let message):
            Text(message).font(.caption).foregroundColor(.red).lineLimit(2).multilineTextAlignment(.trailing)
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 6).fill(Color.secondary.opacity(0.15))
                Image(systemName: "music.note").foregroundColor(.secondary)
            }
            .frame(width: 44, height: 44)

            VStack(alignment: .leading, spacing: 2) {
                Text(fichier.url.lastPathComponent).lineLimit(1).truncationMode(.middle)
                Text(detail).font(.caption).foregroundColor(.secondary).lineLimit(1)
            }
            Spacer()
            statut
            if peutRetirer {
                Button(action: retirer) {
                    Image(systemName: "xmark.circle.fill")
                }
                .buttonStyle(.plain)
                .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

struct VueAudio: View {
    @ObservedObject var m = ModeleAudio.partage
    @State private var survol = false
    @State private var avancesOuverts = false

    var body: some View {
        HStack(spacing: 0) {
            zoneGauche
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            Divider()
            panneau
                .frame(width: 330)
                .background(Color(NSColor.controlBackgroundColor))
        }
        .frame(minWidth: 880, idealWidth: 980, minHeight: 600, idealHeight: 660)
        .onDrop(of: [UTType.fileURL], isTargeted: $survol) { providers in
            m.deposer(providers)
            return true
        }
    }

    // MARK: Zone de gauche

    var zoneGauche: some View {
        ZStack {
            if m.items.isEmpty {
                vide
            } else {
                liste
            }
            if survol {
                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(Color.accentColor.opacity(0.08))
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(Color.accentColor, style: StrokeStyle(lineWidth: 2, dash: [8, 6]))
                }
                .padding(14)
                .allowsHitTesting(false)
            }
        }
    }

    var vide: some View {
        VStack(spacing: 10) {
            Image(systemName: "waveform")
                .font(.system(size: 54))
                .foregroundColor(.secondary)
            Text("Glissez des fichiers audio ou un dossier ici")
                .font(.title3)
            Text("ou cliquez sur « Choisir des fichiers audio… »")
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture { m.choisir() }
    }

    var titreListe: String {
        let n = m.items.count
        var texte = "\(n) fichier\(n > 1 ? "s" : "") · \(formaterTaille(m.tailleTotale))"
        let duree = formaterDuree(m.dureeTotale)
        if !duree.isEmpty { texte += " · \(duree)" }
        return texte
    }

    var liste: some View {
        VStack(spacing: 0) {
            HStack {
                Text(titreListe)
                    .font(.headline)
                Spacer()
                Button("Vider la liste") { m.vider() }
                    .disabled(m.enCours)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            Divider()
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(m.items) { f in
                        VStack(spacing: 0) {
                            LigneAudioView(fichier: f, estimation: m.estimation(f, m.reglages()),
                                           peutRetirer: !m.enCours, retirer: { m.retirer(f.id) })
                            Divider().padding(.leading, 72)
                        }
                    }
                }
            }
        }
    }

    // MARK: Blocs

    func blocFixe<Contenu: View>(_ titre: String, _ valeur: String, _ aide: String, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(titre).fontWeight(.medium).help(aide)
                Spacer()
                Text(valeur).foregroundColor(.secondary).lineLimit(1)
            }
            contenu()
        }
    }

    func sousBloc<Contenu: View>(_ titre: String, _ aide: String, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(titre)
                .font(.callout)
                .foregroundColor(.secondary)
                .help(aide)
            contenu()
        }
    }

    func blocAvances<Contenu: View>(_ titre: String, _ resume: String, _ aide: String, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: { avancesOuverts.toggle() }) {
                HStack(spacing: 6) {
                    Image(systemName: avancesOuverts ? "chevron.down" : "chevron.right")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .frame(width: 12)
                    Text(titre).fontWeight(.medium)
                    Spacer()
                    Text(resume).foregroundColor(.secondary).lineLimit(1)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .help(aide)
            if avancesOuverts {
                contenu()
            }
        }
    }

    func choixDestination(_ titre: String, actif: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 6) {
                Image(systemName: actif ? "largecircle.fill.circle" : "circle")
                    .foregroundColor(actif ? Color.accentColor : Color.secondary)
                Text(titre)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    func champ(_ nom: String, _ texte: Binding<String>, _ aide: String, actif: Bool = true) -> some View {
        HStack(spacing: 8) {
            Text(nom)
                .foregroundColor(.secondary)
                .frame(width: 100, alignment: .leading)
            TextField("Inchangé", text: texte)
                .textFieldStyle(.roundedBorder)
                .disabled(!actif)
        }
        .help(aide)
    }

    // Bandeau affiché tant que ffmpeg est introuvable
    var bandeauFFmpeg: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("ffmpeg est nécessaire", systemImage: "exclamationmark.triangle.fill")
                .foregroundColor(.orange)
                .fontWeight(.medium)
            Text("L’onglet Audio s’appuie sur ffmpeg (gratuit) pour encoder le MP3 et les autres formats. Installez-le avec Homebrew, dans le Terminal :")
                .font(.caption)
                .fixedSize(horizontal: false, vertical: true)
            Text("brew install ffmpeg")
                .font(.system(.callout, design: .monospaced))
                .textSelection(.enabled)
                .padding(6)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.secondary.opacity(0.15))
                .cornerRadius(6)
            HStack {
                Button("Copier la commande") {
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString("brew install ffmpeg", forType: .string)
                }
                Button("Vérifier à nouveau") { m.chercherFFmpeg() }
            }
        }
        .padding(12)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(8)
        .help("Vous pouvez aussi placer le programme ffmpeg dans ~/Library/Application Support/Media Compressor/")
    }

    var blocFormat: some View {
        blocFixe("Format", m.formatEffectif.titre, "Format du fichier de sortie. MP3, M4A (AAC, avec option M4R) et OGG compressent avec perte ; ALAC, FLAC, WAV et AIFF conservent toute la qualité.") {
            VStack(spacing: 6) {
                HStack(spacing: 6) {
                    ForEach([FormatAudio.mp3, .wav, .aiff, .flac]) { f in boutonFormat(f) }
                }
                HStack(spacing: 6) {
                    ForEach([FormatAudio.aac, .ogg, .alac]) { f in boutonFormat(f) }
                }
                if m.format == .aac {
                    Toggle("Sonnerie iPhone (.m4r)", isOn: $m.sonnerie)
                        .help(FormatAudio.m4r.aide)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
    }

    func boutonFormat(_ f: FormatAudio) -> some View {
        let choisi = (m.format == f)
        return Button(action: { m.format = f }) {
            Text(f.titre)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 5)
                .foregroundColor(choisi ? Color.white : Color.primary)
                .background(RoundedRectangle(cornerRadius: 6)
                    .fill(choisi ? Color.accentColor : Color.secondary.opacity(0.15)))
        }
        .buttonStyle(.plain)
        .help(f.aide)
    }

    var blocDebit: some View {
        blocFixe("Débit (kb/s)", m.formatEffectif.avecPerte ? "\(m.debit) kb/s" : "sans perte",
                 "Plus le débit est élevé, meilleure est la qualité et plus le fichier est lourd. 192 kb/s est un bon compromis ; 320 kb/s est la qualité maximale du MP3. Sans effet sur les formats sans perte.") {
            Picker("", selection: $m.debit) {
                Text("96").tag(96)
                Text("128").tag(128)
                Text("192").tag(192)
                Text("256").tag(256)
                Text("320").tag(320)
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .disabled(!m.formatEffectif.avecPerte)

            // Réglage fin : de 0 à 320 kb/s (le minimum réellement appliqué est 8 kb/s).
            HStack(spacing: 8) {
                Text("0").font(.caption).foregroundColor(.secondary)
                Slider(value: Binding(get: { Double(m.debit) },
                                      set: { m.debit = Int($0.rounded()) }),
                       in: 0...320, step: 1)
                    .disabled(!m.formatEffectif.avecPerte)
                Text("320").font(.caption).foregroundColor(.secondary)
            }
            .help("Réglage fin du débit, de 0 à 320 kb/s. Le MP3 utilise le palier standard le plus proche ; 0 est appliqué comme 8 kb/s (minimum possible).")
        }
    }

    var blocTags: some View {
        sousBloc("Informations (tags)",
                 "Titre, artiste, album, année… écrits dans le fichier (tags ID3 pour le MP3). Un champ vide conserve la valeur d’origine de chaque fichier.") {
            VStack(alignment: .leading, spacing: 6) {
                champ("Titre", $m.titre, "Titre du morceau. Disponible quand un seul fichier est dans la liste.", actif: m.items.count <= 1)
                champ("Artiste", $m.artiste, "Artiste ou interprète.")
                champ("Album", $m.album, "Nom de l’album.")
                champ("Artiste album", $m.artisteAlbum, "Artiste de l’album (utile pour les compilations).")
                champ("Année", $m.annee, "Année de sortie, par exemple 2024.")
                champ("Genre", $m.genre, "Genre musical.")
                champ("N° de piste", $m.piste, "Numéro du morceau, par exemple 3 ou 3/12. Disponible quand un seul fichier est dans la liste.", actif: m.items.count <= 1)
                champ("Commentaire", $m.commentaire, "Commentaire libre.")

                Toggle("Numéroter les pistes dans l’ordre de la liste", isOn: $m.numeroter)
                    .disabled(m.items.count < 2)
                    .help("Écrit 1/N, 2/N… selon l’ordre des fichiers dans la liste.")
                Toggle("Effacer les tags d’origine", isOn: $m.supprimerTags)
                    .help("Supprime tous les tags d’origine, y compris la pochette, avant d’écrire ceux que vous avez renseignés.")
            }
        }
    }

    var resumeAvancees: String {
        var morceaux: [String] = []
        let tagsRenseignes = [m.titre, m.artiste, m.album, m.artisteAlbum, m.annee, m.genre, m.piste, m.commentaire]
            .contains { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        if m.supprimerTags {
            morceaux.append("tags effacés")
        } else if tagsRenseignes {
            morceaux.append("tags")
        }
        if m.frequence > 0 { morceaux.append(m.frequence == 44100 ? "44,1 kHz" : "\(m.frequence / 1000) kHz") }
        if m.canaux == 1 { morceaux.append("mono") }
        if m.canaux == 2 { morceaux.append("stéréo") }
        return morceaux.isEmpty ? "par défaut" : morceaux.joined(separator: " · ")
    }

    var blocAvancees: some View {
        blocAvances("Paramètres avancés", resumeAvancees, "Informations (tags), fréquence d’échantillonnage et nombre de canaux.") {
            VStack(alignment: .leading, spacing: 14) {
                blocTags
                sousBloc("Fréquence d’échantillonnage", "Une fréquence plus basse allège le fichier. 44,1 kHz suffit pour la musique ; 22 kHz convient à la voix.") {
                    Picker("", selection: $m.frequence) {
                        Text("Origine").tag(0)
                        Text("48 kHz").tag(48000)
                        Text("44,1 kHz").tag(44100)
                        Text("22 kHz").tag(22050)
                    }
                    .labelsHidden()
                    .pickerStyle(.segmented)
                }
                sousBloc("Canaux", "Passer en mono divise à peu près par deux le poids des fichiers sans perte, et convient à la voix.") {
                    Picker("", selection: $m.canaux) {
                        Text("Origine").tag(0)
                        Text("Stéréo").tag(2)
                        Text("Mono").tag(1)
                    }
                    .labelsHidden()
                    .pickerStyle(.segmented)
                }
            }
        }
    }

    var resumeDestination: String {
        return m.destination == .cote ? "À côté" : "Autre dossier"
    }

    var blocDestination: some View {
        blocFixe("Enregistrer dans", resumeDestination, "Les originaux ne sont jamais modifiés.") {
            choixDestination("Dossier « Compressées » à côté des originaux", actif: m.destination == .cote) {
                m.destination = .cote
            }
            choixDestination("Un autre dossier", actif: m.destination == .autre) {
                m.selectionnerAutreDossier()
            }
            if m.destination == .autre, let d = m.dossierAutre {
                HStack {
                    Image(systemName: "folder").foregroundColor(.secondary)
                    Text(d.lastPathComponent).lineLimit(1).truncationMode(.middle)
                    Spacer()
                    Button("Changer…") { m.choisirDossierDestination() }
                }
                .font(.callout)
                .padding(.leading, 20)
            }
        }
    }

    var panneau: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if m.verifie && !m.ffmpegPret {
                        bandeauFFmpeg
                    }
                    if let avert = m.avertissement {
                        Text(avert)
                            .font(.caption)
                            .foregroundColor(.orange)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    blocFormat
                    blocDebit
                    blocAvancees
                    blocDestination
                }
                .padding(20)
                .disabled(m.enCours)
            }

            Divider()
            pied
                .padding(20)
        }
    }

    // MARK: Pied

    var texteBouton: String {
        let n = m.items.count
        if n == 0 { return "Convertir" }
        return "Convertir \(n) fichier\(n > 1 ? "s" : "")"
    }

    func estimationVue(_ avant: Int64, _ apres: Int64) -> some View {
        let gain = Int((100.0 * Double(avant - apres) / Double(max(avant, 1))).rounded())
        let signe = gain >= 0 ? "−" : "+"
        return VStack(alignment: .leading, spacing: 2) {
            Text("Poids estimé")
                .font(.caption).foregroundColor(.secondary)
            Text("\(formaterTaille(avant)) → ≈ \(formaterTaille(apres))  (\(signe)\(abs(gain)) %)")
                .fontWeight(.medium)
        }
        .help("Estimation calculée d’après le format, le débit et la durée de chaque fichier. Le résultat réel peut différer.")
    }

    var pied: some View {
        VStack(alignment: .leading, spacing: 10) {
            if !m.enCours && m.bilan == nil, let e = m.estimationTotale {
                estimationVue(e.0, e.1)
            }
            if m.enCours {
                ProgressView(value: m.progres, total: 1.0)
                Text("Conversion… \(Int((m.progres * 100).rounded())) %")
                    .font(.caption).foregroundColor(.secondary)
            } else if let b = m.bilan {
                bilanVue(b)
            }

            if m.enCours {
                Button(action: { m.annuler() }) {
                    Text("Annuler")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.large)
                .keyboardShortcut(.cancelAction)
            } else {
                Button(action: { m.compresser() }) {
                    Text(texteBouton)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .keyboardShortcut(.defaultAction)
                .disabled(m.items.isEmpty || !m.ffmpegPret || !m.encodeurDisponible)
            }
        }
    }

    func texteGain(_ b: Bilan) -> String {
        let gain = Int((100.0 * Double(b.avant - b.apres) / Double(max(b.avant, 1))).rounded())
        let signe = gain >= 0 ? "−" : "+"
        return "\(formaterTaille(b.avant)) → \(formaterTaille(b.apres))  (\(signe)\(abs(gain)) %)"
    }

    func bilanVue(_ b: Bilan) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("\(b.annule ? "Annulé" : "Terminé") : \(b.nbOk) fichier\(b.nbOk > 1 ? "s" : "") sur \(b.nbTotal)")
                .fontWeight(.medium)
            if b.nbOk > 0 && b.avant > 0 {
                Text(texteGain(b))
                    .foregroundColor(.green)
            }
            if b.nbPlusLourd > 0 {
                Text("\(b.nbPlusLourd) fichier(s) plus lourd(s) qu’avant : gardez l’original.")
                    .font(.caption).foregroundColor(.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if b.nbEchecs > 0 {
                Text("\(b.nbEchecs) échec(s), voir la liste.")
                    .font(.caption).foregroundColor(.red)
            }
            if !b.sorties.isEmpty {
                Button("Afficher dans le Finder") { m.afficherDansFinder() }
                    .padding(.top, 2)
            }
        }
    }
}
