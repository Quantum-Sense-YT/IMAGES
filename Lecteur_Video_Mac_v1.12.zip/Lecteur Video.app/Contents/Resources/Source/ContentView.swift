import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var model: PlayerModel

    @State private var controlsVisible = true
    @State private var hoveringControls = false
    @State private var isDropTargeted = false
    @State private var hideTask: Task<Void, Never>?
    @State private var areaWidth: CGFloat = 1000

    var body: some View {
        HStack(spacing: 0) {
            if model.showPlaylist {
                PlaylistView()
                    .frame(width: model.playlistWidth)
                Divider()
            }
            videoArea
                // La poignée flotte sur le bord gauche de l'image : elle reste visible playlist masquée.
                .overlay(alignment: .leading) { if !model.pipMode { PlaylistHandle() } }
        }
        // Playlist masquée : on peut réduire jusqu'à la taille du PiP (au relâchement, la fenêtre passe alors en PiP).
        .frame(minWidth: (model.pipMode || !model.showPlaylist) ? 240 : 660 + model.playlistWidth + 1,
               minHeight: (model.pipMode || !model.showPlaylist) ? 135 : 260)
        // En PiP la vidéo passe sous la (absente) barre de titre : pas de bande en haut.
        .ignoresSafeArea(edges: model.pipMode ? Edge.Set.all : Edge.Set())
        .background(Color.black)
        .background(WindowConfigurator())
        .preferredColorScheme(.dark)
        .navigationTitle(model.windowTitle)
        .dropDestination(for: URL.self) { urls, _ in
            model.replaceAndPlay(urls)
            return true
        } isTargeted: { targeted in
            isDropTargeted = targeted
        }
        .onOpenURL { url in
            model.replaceAndPlay([url])
        }
        .onChange(of: model.isPlaying) { _ in
            showControls()
        }
        .onAppear { showControls() }
    }

    private var videoArea: some View {
        ZStack {
            Color.black
            VLCVideoSurface(player: model.player, fill: model.fillWindow)
                // Format avancé : déformation horizontale / verticale libre
                .scaleEffect(x: CGFloat(model.stretchX), y: CGFloat(model.stretchY), anchor: .center)

            // Calque d'interaction : clic = déplacer la fenêtre, double-clic = plein écran,
            // molette = volume. (Pause : barre d'espace ou bouton.)
            VideoInteractionLayer(
                onDoubleClick: { model.toggleFullScreen() },
                onScroll: { deltaY, precise, inverted in
                    model.scrollVolume(deltaY: deltaY, precise: precise, inverted: inverted)
                    showControls()
                },
                onHorizontalScroll: { deltaX, precise, inverted in
                    model.scrubHorizontal(deltaX: deltaX, precise: precise, inverted: inverted)
                    showControls()
                }
            )

            if model.currentIndex == nil {
                emptyState
            }

            if let message = model.errorMessage {
                Text(message)
                    .padding(10)
                    .background(Color.red.opacity(0.8), in: RoundedRectangle(cornerRadius: 8))
                    .foregroundStyle(Color.white)
            }

            if let hud = model.hudText {
                VStack {
                    Text(hud)
                        .font(.system(size: 16, weight: .semibold))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial, in: Capsule())
                    Spacer()
                }
                .padding(.top, 24)
                .allowsHitTesting(false)
            }

            if isDropTargeted {
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(Color.accentColor, style: StrokeStyle(lineWidth: 3, dash: [10, 6]))
                    .padding(16)
                    .allowsHitTesting(false)
            }

            VStack {
                Spacer()
                Group {
                    // Barre réduite dès que l'image devient trop étroite (pendant la réduction par un coin).
                    if model.pipMode || (!model.showPlaylist && areaWidth < PlayerModel.normalMinWidth) {
                        PipControlsBar()
                    } else {
                        ControlsBar()
                    }
                }
                .onHover { hoveringControls = $0 }
                .opacity(controlsVisible ? 1 : 0)
                .allowsHitTesting(controlsVisible)
            }
        }
        .clipped()
        .background(
            GeometryReader { proxy in
                Color.clear
                    .onAppear { areaWidth = proxy.size.width }
                    .onChange(of: proxy.size.width) { areaWidth = $0 }
            }
        )
        .onContinuousHover { phase in
            if case .active = phase { showControls() }
        }
        .onChange(of: model.advancedFormatOpen) { _ in
            showControls()
        }
    }

    /// Écran d'accueil : s'adapte à la hauteur disponible pour que rien ne soit coupé, même en fenêtre compacte.
    private var emptyState: some View {
        ViewThatFits(in: .vertical) {
            emptyContent(showFormats: true, showHint: true)
            emptyContent(showFormats: true, showHint: false)
            emptyContent(showFormats: false, showHint: false)
        }
        .padding(.bottom, 90)      // réserve la place de la barre de contrôle
    }

    private func emptyContent(showFormats: Bool, showHint: Bool) -> some View {
        VStack(spacing: 10) {
            Image(systemName: "play.rectangle.fill")
                .font(.system(size: showFormats ? 52 : 40))
                .foregroundStyle(.secondary)
            Text("Glissez une vidéo ou un dossier ici")
                .font(.title3)
            if showFormats {
                Text("mp4 · mov · mkv · avi · h264 · h265")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
            // Petit bouton discret.
            Button { model.presentOpenPanel() } label: {
                Text("Ouvrir une vidéo…")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Color.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 6)
                    .background(Color.accentColor, in: Capsule())
                    .contentShape(Capsule())
            }
            .buttonStyle(.plain)
            if showHint {
                Text("Molette : volume · Deux doigts ←/→ : avancer/reculer\nClic-glisser : déplacer la fenêtre · Double-clic : plein écran")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
    }

    /// Affiche la barre de contrôle puis la masque après 3 s d'inactivité (si lecture en cours).
    private func showControls() {
        withAnimation(.easeIn(duration: 0.15)) { controlsVisible = true }
        hideTask?.cancel()
        hideTask = Task {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if model.isPlaying && !hoveringControls && !model.advancedFormatOpen {
                    withAnimation(.easeOut(duration: 0.3)) { controlsVisible = false }
                    NSCursor.setHiddenUntilMouseMoves(true)
                }
            }
        }
    }
}
