// Media Compressor — interface unique, glisser-déposer (onglets Image, Vidéo, Audio).
// Moteur : AVFoundation (intégré à macOS, encodage H.264 / H.265 accéléré par le Mac).
// Les vidéos originales ne sont jamais modifiées.

import SwiftUI
import AppKit
import AVFoundation
import CoreMedia
import CoreVideo
import UniformTypeIdentifiers

let extensionsVideos: Set<String> = ["mp4", "mov", "m4v", "mpg", "mpeg", "avi", "3gp", "mts", "m2ts", "mkv", "webm"]
let nomDossierSortie = "Compressées"

// MARK: - Types

enum ModeCompression: Hashable {
    case qualite
    case taille
}

enum NiveauAudio: Hashable {
    case original      // même débit que la piste son d'origine
    case aucun
    case k128
    case k192
    case k320
    case perso         // curseur de 0 à 320 kb/s
}

enum Conteneur: String, CaseIterable, Identifiable {
    case mp4, mov
    var id: String { rawValue }
    var titre: String {
        switch self {
        case .mp4: return "MP4"
        case .mov: return "MOV"
        }
    }
    var ext: String { rawValue }
    var type: AVFileType {
        switch self {
        case .mp4: return AVFileType.mp4
        case .mov: return AVFileType.mov
        }
    }
    var aide: String {
        switch self {
        case .mp4: return "MP4 : lisible partout (téléphones, web, Windows, télévisions)."
        case .mov: return "MOV : format QuickTime d’Apple, idéal pour Mac et iPhone."
        }
    }
}

enum CodecVideo: String, CaseIterable, Identifiable {
    case hevc, h264     // l'ordre = ordre d'affichage (H.265 à gauche, H.264 à droite)
    var id: String { rawValue }
    var titre: String {
        switch self {
        case .h264: return "H.264"
        case .hevc: return "H.265"
        }
    }
    var aide: String {
        switch self {
        case .h264: return "H.264 : compatible avec tous les appareils."
        case .hevc: return "H.265 (HEVC) : environ 40 % plus léger à qualité égale, mais certains anciens appareils ou lecteurs ne le lisent pas."
        }
    }
}

enum Destination {
    case cote
    case autre
}

enum Etat {
    case attente
    case enCours(Double)
    case termine(Int64)
    case erreur(String)
}

// Petit bouton « dossier » : affiche le fichier converti dans le Finder (partagé par les trois onglets)
struct BoutonDossierSortie: View {
    let url: URL?

    var body: some View {
        if let u = url {
            Button(action: { NSWorkspace.shared.activateFileViewerSelecting([u]) }) {
                Image(systemName: "folder")
            }
            .buttonStyle(.plain)
            .foregroundColor(.secondary)
            .help("Afficher le fichier converti dans le Finder")
        }
    }
}

struct Video: Identifiable {
    let id = UUID()
    let url: URL
    var sortie: URL? = nil
    var taille: Int64
    var duree: Double = 0
    var details: String = ""
    var miniature: NSImage? = nil
    var illisible: Bool = false
    var largeur: Double = 0
    var hauteur: Double = 0
    var fps: Double = 0
    var debitSource: Double = 0
    var aAudio: Bool = false
    var canaux: Int = 2
    var debitAudioSource: Double = 0
    var etat: Etat = .attente
}

struct Reglages {
    var mode: ModeCompression
    var qualite: Double
    var tailleCibleMo: Int
    var largeurMax: Int         // 0 = pas de limite
    var hauteurMax: Int         // 0 = pas de limite
    var imagesMax: Int          // 0 = cadence d'origine
    var conteneur: Conteneur
    var codec: CodecVideo
    var audio: NiveauAudio
    var sonPerso: Int           // kb/s, utilisé si audio == .perso
    var dossierFixe: URL?
    var garderMeta: Bool
}

extension Reglages {
    var sansSon: Bool {
        return audio == .aucun || (audio == .perso && sonPerso <= 0)
    }

    // Débit AAC demandé (bits/s) ; 0 = pas de son
    func debitSon(source: Double) -> Int {
        switch audio {
        case .aucun:
            return 0
        case .k128:
            return 128_000
        case .k192:
            return 192_000
        case .k320:
            return 320_000
        case .perso:
            if sonPerso <= 0 { return 0 }
            return max(32_000, min(320_000, sonPerso * 1000))
        case .original:
            if source > 0 { return max(32_000, min(320_000, Int(source))) }
            return 128_000
        }
    }
}

struct Bilan {
    var nbOk = 0
    var nbTotal = 0
    var avant: Int64 = 0
    var apres: Int64 = 0
    var nbPlusLourd = 0
    var nbAuDessusCible = 0
    var nbEchecs = 0
    var annule = false
    var sorties: [URL] = []
}

struct ErreurCompression: Error {
    let message: String
}

// Drapeau d'annulation partagé entre l'interface et le moteur
final class Controle {
    private let verrou = NSLock()
    private var drapeau = false

    var annule: Bool {
        verrou.lock()
        defer { verrou.unlock() }
        return drapeau
    }

    func annuler() {
        verrou.lock()
        drapeau = true
        verrou.unlock()
    }
}

// État partagé entre les deux files de copie (image et son)
final class EtatCopie {
    private let verrou = NSLock()
    private var drapeauEchec = false
    var derniereMaj = Date.distantPast

    var echec: Bool {
        verrou.lock()
        defer { verrou.unlock() }
        return drapeauEchec
    }

    func signalerEchec() {
        verrou.lock()
        drapeauEchec = true
        verrou.unlock()
    }
}

func formaterTaille(_ octets: Int64) -> String {
    return ByteCountFormatter.string(fromByteCount: octets, countStyle: .file)
}

func formaterDuree(_ secondes: Double) -> String {
    if !secondes.isFinite || secondes <= 0 { return "" }
    let total = Int(secondes.rounded())
    let h = total / 3600
    let m = (total % 3600) / 60
    let s = total % 60
    if h > 0 { return String(format: "%d:%02d:%02d", h, m, s) }
    return String(format: "%d:%02d", m, s)
}

let formateurEntier: NumberFormatter = {
    let f = NumberFormatter()
    f.numberStyle = .none
    f.allowsFloats = false
    f.minimum = 1
    f.maximum = 20000
    return f
}()

// MARK: - Moteur de compression

enum Compresseur {

    static func pair(_ v: CGFloat) -> Int {
        return max(2, Int((v / 2).rounded()) * 2)
    }

    // Durée d'une image pour une cadence donnée (gère 23,976 / 29,97 / 59,94 i/s)
    static func dureeImage(_ fps: Double) -> CMTime {
        let ntsc: [(Double, Int32)] = [(23.976, 24), (29.97, 30), (47.952, 48), (59.94, 60), (119.88, 120)]
        for (valeur, nominal) in ntsc {
            if abs(fps - valeur) < 0.02 {
                return CMTime(value: 1001, timescale: nominal * 1000)
            }
        }
        return CMTime(value: 1, timescale: Int32(max(1, Int(fps.rounded()))))
    }

    static func dispositionAudio(_ canaux: Int) -> Data {
        var disposition = AudioChannelLayout()
        disposition.mChannelLayoutTag = (canaux == 1) ? kAudioChannelLayoutTag_Mono : kAudioChannelLayoutTag_Stereo
        return Data(bytes: &disposition, count: MemoryLayout<AudioChannelLayout>.size)
    }

    struct Plan {
        var largeurSortie: Int
        var hauteurSortie: Int
        var fps: Double
        var fpsEntier: Int
        var debitVideo: Double
        var debitAudio: Int
        var cibleOctets: Double
    }

    static func planifier(largeur: CGFloat, hauteur: CGFloat, fpsSource: Double, debitSource: Double,
                          debitSourceAudio: Double, duree: Double, aAudio: Bool, canaux: Int, r: Reglages) -> Plan {
        // Dimensions : la vidéo tient dans la boîte largeur × hauteur (proportions gardées, jamais agrandie)
        var echelle: CGFloat = 1
        var boiteL = CGFloat(r.largeurMax)
        var boiteH = CGFloat(r.hauteurMax)
        if boiteL > 0 && boiteH > 0 && ((hauteur > largeur) != (boiteH > boiteL)) {
            swap(&boiteL, &boiteH)       // vidéo en portrait : on adapte l'orientation de la boîte
        }
        if boiteL > 0 { echelle = min(echelle, boiteL / largeur) }
        if boiteH > 0 { echelle = min(echelle, boiteH / hauteur) }
        echelle = min(1, max(0.01, echelle))
        let largeurSortie = pair(largeur * echelle)
        let hauteurSortie = pair(hauteur * echelle)

        // Cadence
        var fps = fpsSource > 1 ? fpsSource : 30.0
        if r.imagesMax > 0 && fps > Double(r.imagesMax) + 0.5 {
            fps = Double(r.imagesMax)
        }
        let fpsEntier = max(1, Int(fps.rounded()))

        // Son
        var debitAudio = r.debitSon(source: debitSourceAudio)
        if canaux == 1 { debitAudio = min(debitAudio, 160_000) }

        // Débit vidéo
        let pixelsParSeconde = Double(largeurSortie * hauteurSortie) * (fps > 30 ? 30 + (fps - 30) * 0.5 : fps)
        var debitVideo: Double
        var cibleOctets: Double = 0
        switch r.mode {
        case .qualite:
            let t = (r.qualite - 1) / 99
            let bitsParPixel = 0.012 * pow(25.0, t)
            debitVideo = pixelsParSeconde * bitsParPixel * (r.codec == .hevc ? 0.6 : 1.0)
        case .taille:
            cibleOctets = Double(r.tailleCibleMo) * 1_000_000
            let debitTotal = cibleOctets * 8 * 0.95 / max(duree, 0.1)
            debitVideo = debitTotal - (aAudio ? Double(debitAudio) : 0)
            debitVideo = max(debitVideo, 100_000)
        }
        if debitSource > 0 {
            debitVideo = min(debitVideo, debitSource * 0.95)     // on ne gonfle jamais une vidéo
        }
        debitVideo = max(debitVideo, 50_000)

        return Plan(largeurSortie: largeurSortie, hauteurSortie: hauteurSortie, fps: fps, fpsEntier: fpsEntier,
                    debitVideo: debitVideo, debitAudio: debitAudio, cibleOctets: cibleOctets)
    }

    // Estimation du poids final (octets) : débit vidéo + son, sur la durée
    static func estimerTaille(largeur: CGFloat, hauteur: CGFloat, fpsSource: Double, debitSource: Double,
                              debitSourceAudio: Double, duree: Double, aAudio: Bool, canaux: Int, r: Reglages) -> Int64 {
        let p = planifier(largeur: largeur, hauteur: hauteur, fpsSource: fpsSource, debitSource: debitSource,
                          debitSourceAudio: debitSourceAudio, duree: duree, aAudio: aAudio, canaux: canaux, r: r)
        let audio = aAudio ? Double(p.debitAudio) : 0
        let octets = (p.debitVideo + audio) * duree / 8 * 1.01
        return Int64(octets)
    }

    static func cheminUnique(dossier: URL, base: String, ext: String) -> URL {
        let fm = FileManager.default
        var candidat = dossier.appendingPathComponent(base).appendingPathExtension(ext)
        var i = 1
        while fm.fileExists(atPath: candidat.path) {
            candidat = dossier.appendingPathComponent("\(base)-\(i)").appendingPathExtension(ext)
            i += 1
        }
        return candidat
    }

    // Retourne : fichier créé, taille, true si la taille cible est dépassée de plus de 10 %
    static func traiter(_ source: URL, _ r: Reglages, controle: Controle, progression: @escaping (Double) -> Void) throws -> (URL, Int64, Bool) {
        let fm = FileManager.default
        let asset = AVURLAsset(url: source)
        guard asset.isReadable else {
            throw ErreurCompression(message: "Format non pris en charge par macOS")
        }
        guard let pisteV = asset.tracks(withMediaType: .video).first else {
            throw ErreurCompression(message: "Aucune piste vidéo")
        }
        let duree = CMTimeGetSeconds(asset.duration)
        guard duree.isFinite && duree > 0 else {
            throw ErreurCompression(message: "Durée inconnue")
        }

        // Dimensions, dans le sens d'affichage (rotation prise en compte)
        let transfo = pisteV.preferredTransform
        let brut = pisteV.naturalSize.applying(transfo)
        let largeur = abs(brut.width)
        let hauteur = abs(brut.height)
        guard largeur >= 2 && hauteur >= 2 else {
            throw ErreurCompression(message: "Dimensions inconnues")
        }

        // Son
        var pisteA: AVAssetTrack? = nil
        if !r.sansSon {
            pisteA = asset.tracks(withMediaType: .audio).first
        }
        var canaux = 2
        var frequence = 48000.0
        if let pa = pisteA {
            if let descriptions = pa.formatDescriptions as? [CMFormatDescription], let desc = descriptions.first {
                if let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(desc)?.pointee {
                    canaux = max(1, min(2, Int(asbd.mChannelsPerFrame)))
                    frequence = asbd.mSampleRate > 46000 ? 48000.0 : 44100.0
                }
            }
        }

        // Dimensions de sortie, cadence et débits (mêmes calculs que l'estimation affichée)
        let plan = planifier(largeur: largeur, hauteur: hauteur, fpsSource: Double(pisteV.nominalFrameRate),
                             debitSource: Double(pisteV.estimatedDataRate),
                             debitSourceAudio: Double(pisteA?.estimatedDataRate ?? 0), duree: duree,
                             aAudio: pisteA != nil, canaux: canaux, r: r)
        let largeurSortie = plan.largeurSortie
        let hauteurSortie = plan.hauteurSortie
        let fps = plan.fps
        let fpsEntier = plan.fpsEntier
        let debitVideo = plan.debitVideo
        let debitAudio = plan.debitAudio
        let cibleOctets = plan.cibleOctets
        let dureeUneImage = dureeImage(fps)

        // Dossier et noms de sortie
        let dossier: URL
        if let fixe = r.dossierFixe {
            dossier = fixe
        } else {
            dossier = source.deletingLastPathComponent().appendingPathComponent(nomDossierSortie, isDirectory: true)
        }
        do {
            try fm.createDirectory(at: dossier, withIntermediateDirectories: true, attributes: nil)
        } catch {
            throw ErreurCompression(message: "Dossier inaccessible")
        }
        let base = source.deletingPathExtension().lastPathComponent
        let sortie = cheminUnique(dossier: dossier, base: base, ext: r.conteneur.ext)
        let temporaire = dossier.appendingPathComponent(".\(UUID().uuidString).encours")

        // Écriture
        let writer: AVAssetWriter
        do {
            writer = try AVAssetWriter(outputURL: temporaire, fileType: r.conteneur.type)
        } catch {
            throw ErreurCompression(message: "Écriture impossible")
        }
        writer.shouldOptimizeForNetworkUse = true
        if r.garderMeta {
            writer.metadata = asset.metadata
        }

        let lecteur: AVAssetReader
        do {
            lecteur = try AVAssetReader(asset: asset)
        } catch {
            throw ErreurCompression(message: "Lecture impossible")
        }

        func abandonner() {
            if lecteur.status == .reading { lecteur.cancelReading() }
            if writer.status == .writing { writer.cancelWriting() }
            try? fm.removeItem(at: temporaire)
        }

        // Entrée vidéo (écriture)
        var compression: [String: Any] = [
            AVVideoAverageBitRateKey: Int(debitVideo),
            AVVideoExpectedSourceFrameRateKey: fpsEntier,
            AVVideoMaxKeyFrameIntervalKey: fpsEntier * 2
        ]
        if r.codec == .h264 {
            compression[AVVideoProfileLevelKey] = AVVideoProfileLevelH264HighAutoLevel
        }
        let codecVideo: AVVideoCodecType = (r.codec == .hevc) ? AVVideoCodecType.hevc : AVVideoCodecType.h264
        var reglagesVideo: [String: Any] = [
            AVVideoCodecKey: codecVideo,
            AVVideoWidthKey: largeurSortie,
            AVVideoHeightKey: hauteurSortie,
            AVVideoCompressionPropertiesKey: compression
        ]
        if !writer.canApply(outputSettings: reglagesVideo, forMediaType: .video) {
            if r.codec == .hevc {
                abandonner()
                throw ErreurCompression(message: "H.265 indisponible sur ce Mac")
            }
            compression.removeValue(forKey: AVVideoProfileLevelKey)
            reglagesVideo[AVVideoCompressionPropertiesKey] = compression
            if !writer.canApply(outputSettings: reglagesVideo, forMediaType: .video) {
                abandonner()
                throw ErreurCompression(message: "Réglages vidéo non pris en charge")
            }
        }
        let entreeV = AVAssetWriterInput(mediaType: .video, outputSettings: reglagesVideo)
        entreeV.expectsMediaDataInRealTime = false
        guard writer.canAdd(entreeV) else {
            abandonner()
            throw ErreurCompression(message: "Réglages vidéo non pris en charge")
        }
        writer.add(entreeV)

        // Sortie vidéo (lecture) : redimensionnement, rotation et cadence via une composition
        let composition = AVMutableVideoComposition()
        composition.renderSize = CGSize(width: largeurSortie, height: hauteurSortie)
        composition.frameDuration = dureeUneImage
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: CMTime.zero, duration: asset.duration)
        let couche = AVMutableVideoCompositionLayerInstruction(assetTrack: pisteV)
        let ajuste = transfo.concatenating(CGAffineTransform(scaleX: CGFloat(largeurSortie) / largeur, y: CGFloat(hauteurSortie) / hauteur))
        couche.setTransform(ajuste, at: CMTime.zero)
        instruction.layerInstructions = [couche]
        composition.instructions = [instruction]

        let reglagesLectureV: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA)
        ]
        let sortieV = AVAssetReaderVideoCompositionOutput(videoTracks: [pisteV], videoSettings: reglagesLectureV)
        sortieV.videoComposition = composition
        sortieV.alwaysCopiesSampleData = false
        guard lecteur.canAdd(sortieV) else {
            abandonner()
            throw ErreurCompression(message: "Lecture vidéo impossible")
        }
        lecteur.add(sortieV)

        // Son
        var sortieA: AVAssetReaderAudioMixOutput? = nil
        var entreeA: AVAssetWriterInput? = nil
        if let pa = pisteA {
            let disposition = dispositionAudio(canaux)
            let reglagesLectureA: [String: Any] = [
                AVFormatIDKey: kAudioFormatLinearPCM,
                AVSampleRateKey: frequence,
                AVNumberOfChannelsKey: canaux,
                AVLinearPCMBitDepthKey: 16,
                AVLinearPCMIsFloatKey: false,
                AVLinearPCMIsBigEndianKey: false,
                AVLinearPCMIsNonInterleaved: false,
                AVChannelLayoutKey: disposition
            ]
            let mix = AVAssetReaderAudioMixOutput(audioTracks: [pa], audioSettings: reglagesLectureA)
            mix.alwaysCopiesSampleData = false
            guard lecteur.canAdd(mix) else {
                abandonner()
                throw ErreurCompression(message: "Lecture du son impossible")
            }
            lecteur.add(mix)

            var reglagesEcritureA: [String: Any] = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVSampleRateKey: frequence,
                AVNumberOfChannelsKey: canaux,
                AVEncoderBitRateKey: debitAudio,
                AVChannelLayoutKey: disposition
            ]
            if !writer.canApply(outputSettings: reglagesEcritureA, forMediaType: .audio) {
                reglagesEcritureA.removeValue(forKey: AVEncoderBitRateKey)
            }
            if !writer.canApply(outputSettings: reglagesEcritureA, forMediaType: .audio) {
                abandonner()
                throw ErreurCompression(message: "Réglages audio non pris en charge")
            }
            let entree = AVAssetWriterInput(mediaType: .audio, outputSettings: reglagesEcritureA)
            entree.expectsMediaDataInRealTime = false
            guard writer.canAdd(entree) else {
                abandonner()
                throw ErreurCompression(message: "Réglages audio non pris en charge")
            }
            writer.add(entree)
            sortieA = mix
            entreeA = entree
        }

        // Démarrage
        guard lecteur.startReading() else {
            let message = lecteur.error?.localizedDescription ?? "Lecture impossible"
            abandonner()
            throw ErreurCompression(message: message)
        }
        guard writer.startWriting() else {
            let message = writer.error?.localizedDescription ?? "Écriture impossible"
            abandonner()
            throw ErreurCompression(message: message)
        }
        writer.startSession(atSourceTime: CMTime.zero)

        // Copie image par image (et son) jusqu'à la fin
        let groupe = DispatchGroup()
        let etat = EtatCopie()

        let fileV = DispatchQueue(label: "compresseur.video")
        groupe.enter()
        entreeV.requestMediaDataWhenReady(on: fileV) {
            while entreeV.isReadyForMoreMediaData {
                if controle.annule {
                    entreeV.markAsFinished()
                    groupe.leave()
                    return
                }
                guard let tampon = sortieV.copyNextSampleBuffer() else {
                    entreeV.markAsFinished()
                    groupe.leave()
                    return
                }
                let instant = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(tampon))
                if !entreeV.append(tampon) {
                    etat.signalerEchec()
                    entreeV.markAsFinished()
                    groupe.leave()
                    return
                }
                let maintenant = Date()
                if maintenant.timeIntervalSince(etat.derniereMaj) > 0.3 {
                    etat.derniereMaj = maintenant
                    progression(min(1.0, max(0.0, instant / duree)))
                }
            }
        }

        if let entree = entreeA, let sortie = sortieA {
            let fileA = DispatchQueue(label: "compresseur.audio")
            groupe.enter()
            entree.requestMediaDataWhenReady(on: fileA) {
                while entree.isReadyForMoreMediaData {
                    if controle.annule {
                        entree.markAsFinished()
                        groupe.leave()
                        return
                    }
                    guard let tampon = sortie.copyNextSampleBuffer() else {
                        entree.markAsFinished()
                        groupe.leave()
                        return
                    }
                    if !entree.append(tampon) {
                        etat.signalerEchec()
                        entree.markAsFinished()
                        groupe.leave()
                        return
                    }
                }
            }
        }

        groupe.wait()

        if controle.annule {
            abandonner()
            throw ErreurCompression(message: "Annulé")
        }
        if etat.echec || lecteur.status == .failed {
            let message = lecteur.error?.localizedDescription ?? writer.error?.localizedDescription ?? "Échec de l’encodage"
            abandonner()
            throw ErreurCompression(message: message)
        }

        let fin = DispatchSemaphore(value: 0)
        writer.finishWriting {
            fin.signal()
        }
        fin.wait()
        if writer.status != .completed {
            let message = writer.error?.localizedDescription ?? "Écriture impossible"
            try? fm.removeItem(at: temporaire)
            throw ErreurCompression(message: message)
        }

        do {
            try fm.moveItem(at: temporaire, to: sortie)
        } catch {
            try? fm.removeItem(at: temporaire)
            throw ErreurCompression(message: "Enregistrement impossible")
        }

        // La vidéo compressée garde les dates de l'original
        if let attrs = try? fm.attributesOfItem(atPath: source.path) {
            var dates: [FileAttributeKey: Any] = [:]
            if let creation = attrs[.creationDate] { dates[.creationDate] = creation }
            if let modif = attrs[.modificationDate] { dates[.modificationDate] = modif }
            try? fm.setAttributes(dates, ofItemAtPath: sortie.path)
        }

        let attrsSortie = try? fm.attributesOfItem(atPath: sortie.path)
        let taille = (attrsSortie?[.size] as? NSNumber)?.int64Value ?? 0
        let depasse = (r.mode == .taille) && (Double(taille) > cibleOctets * 1.1)
        progression(1.0)
        return (sortie, taille, depasse)
    }
}

// MARK: - Modèle

final class Modele: ObservableObject {
    static let partage = Modele()

    @Published var items: [Video] = []
    @Published var qualite: Double = 60
    @Published var valeurMo: Int = 0          // taille cible en Mo ; 0 = désactivée
    @Published var largeurMax: Int = 0
    @Published var hauteurMax: Int = 0
    @Published var imagesMax: Int = 0
    @Published var conteneur: Conteneur = .mp4
    @Published var codec: CodecVideo = .hevc
    @Published var audio: NiveauAudio = .original
    @Published var sonPerso: Double = 128
    @Published var destination: Destination = .cote
    @Published var dossierAutre: URL? = nil
    @Published var garderMeta: Bool = false
    @Published var enCours: Bool = false
    @Published var progres: Double = 0
    @Published var bilan: Bilan? = nil

    var controle: Controle? = nil

    var aideQualite: String {
        let q = Int(qualite)
        if q >= 90 { return "Quasi identique" }
        if q >= 75 { return "Très haute qualité" }
        if q >= 55 { return "Recommandé" }
        if q >= 35 { return "Bon compromis" }
        if q >= 15 { return "Fort allègement" }
        return "Très compressé"
    }

    var tailleTotale: Int64 {
        return items.reduce(Int64(0)) { $0 + $1.taille }
    }

    var dureeTotale: Double {
        return items.reduce(0.0) { $0 + $1.duree }
    }

    var tailleValide: Int64 {
        return items.filter { !$0.illisible }.reduce(Int64(0)) { $0 + $1.taille }
    }

    func estimation(_ v: Video, _ r: Reglages) -> Int64? {
        if v.illisible || v.duree <= 0 || v.largeur < 2 || v.hauteur < 2 { return nil }
        return Compresseur.estimerTaille(largeur: CGFloat(v.largeur), hauteur: CGFloat(v.hauteur), fpsSource: v.fps,
                                         debitSource: v.debitSource, debitSourceAudio: v.debitAudioSource, duree: v.duree,
                                         aAudio: v.aAudio && !r.sansSon, canaux: v.canaux, r: r)
    }

    var estimationTotale: Int64? {
        let r = reglages()
        var total: Int64 = 0
        var n = 0
        for v in items {
            if let e = estimation(v, r) {
                total += e
                n += 1
            }
        }
        return n > 0 ? total : nil
    }

    var nbATraiter: Int {
        return items.filter { !$0.illisible }.count
    }

    // La taille cible remplace la qualité dès qu'une valeur est saisie
    var mode: ModeCompression {
        return valeurMo > 0 ? .taille : .qualite
    }

    var tailleCibleMo: Int {
        return min(20000, max(0, valeurMo))
    }

    // MARK: Ajout de vidéos

    func choisir() {
        if enCours { return }
        let panneau = NSOpenPanel()
        panneau.title = "Choisir des vidéos ou un dossier"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = true
        panneau.canChooseDirectories = true
        panneau.allowsMultipleSelection = true
        panneau.allowedContentTypes = [UTType.movie]
        if panneau.runModal() == .OK {
            ajouter(panneau.urls)
        }
    }

    func choisirDossierDestination() {
        let panneau = NSOpenPanel()
        panneau.title = "Dossier de destination"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = false
        panneau.canChooseDirectories = true
        panneau.canCreateDirectories = true
        panneau.allowsMultipleSelection = false
        if panneau.runModal() == .OK, let u = panneau.url {
            dossierAutre = u
            destination = .autre
        }
    }

    func selectionnerAutreDossier() {
        if dossierAutre == nil {
            choisirDossierDestination()
        } else {
            destination = .autre
        }
    }

    func deposer(_ providers: [NSItemProvider]) {
        let groupe = DispatchGroup()
        let verrou = NSLock()
        var urls: [URL] = []
        for p in providers {
            groupe.enter()
            p.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                var u: URL? = nil
                if let d = item as? Data {
                    u = URL(dataRepresentation: d, relativeTo: nil)
                } else if let x = item as? URL {
                    u = x
                }
                if let u = u {
                    verrou.lock()
                    urls.append(u)
                    verrou.unlock()
                }
                groupe.leave()
            }
        }
        groupe.notify(queue: .main) {
            // Détection automatique : chaque fichier va dans l'onglet qui correspond à son type
            RouteurFichiers.router(urls)
        }
    }

    func ajouter(_ urls: [URL]) {
        if enCours { return }
        DispatchQueue.global(qos: .userInitiated).async {
            var trouves: [URL] = []
            for u in urls {
                trouves.append(contentsOf: Modele.videos(dans: u))
            }
            DispatchQueue.main.async {
                self.integrer(trouves)
            }
        }
    }

    static func videos(dans url: URL) -> [URL] {
        let fm = FileManager.default
        var estDossier: ObjCBool = false
        guard fm.fileExists(atPath: url.path, isDirectory: &estDossier) else { return [] }
        if estDossier.boolValue {
            var res: [URL] = []
            guard let e = fm.enumerator(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { return [] }
            let exclu = nomDossierSortie.precomposedStringWithCanonicalMapping
            for case let f as URL in e {
                let estDir = (try? f.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
                if estDir {
                    if f.lastPathComponent.precomposedStringWithCanonicalMapping == exclu {
                        e.skipDescendants()
                    }
                    continue
                }
                if extensionsVideos.contains(f.pathExtension.lowercased()) {
                    res.append(f)
                }
            }
            return res.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
        } else {
            return extensionsVideos.contains(url.pathExtension.lowercased()) ? [url] : []
        }
    }

    func integrer(_ urls: [URL]) {
        if enCours { return }
        if bilan != nil {
            // Nouvelle série après une compression terminée
            items = []
            bilan = nil
        }
        var connus = Set(items.map { $0.url.path })
        var nouveaux: [Video] = []
        for u in urls {
            if connus.contains(u.path) { continue }
            connus.insert(u.path)
            let attrs = try? FileManager.default.attributesOfItem(atPath: u.path)
            let t = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            nouveaux.append(Video(url: u, taille: t))
        }
        items.append(contentsOf: nouveaux)
        for v in nouveaux {
            analyser(v.id, v.url)
        }
    }

    func analyser(_ id: UUID, _ url: URL) {
        DispatchQueue.global(qos: .utility).async {
            var miniature: NSImage? = nil
            var details = ""
            var duree = 0.0
            var illisible = false
            var largeurV = 0.0
            var hauteurV = 0.0
            var fpsV = 0.0
            var debitV = 0.0
            var aAudio = false
            var canauxV = 2
            var debitAudioV = 0.0

            let asset = AVURLAsset(url: url)
            if asset.isReadable, let piste = asset.tracks(withMediaType: .video).first {
                let d = CMTimeGetSeconds(asset.duration)
                duree = d.isFinite ? d : 0
                let taille = piste.naturalSize.applying(piste.preferredTransform)
                let w = Int(abs(taille.width))
                let h = Int(abs(taille.height))
                var morceaux: [String] = []
                if w > 0 && h > 0 { morceaux.append("\(w) × \(h)") }
                let fps = Double(piste.nominalFrameRate)
                if fps > 0 { morceaux.append("\(Int(fps.rounded())) i/s") }
                let dureeTexte = formaterDuree(duree)
                if !dureeTexte.isEmpty { morceaux.append(dureeTexte) }
                details = morceaux.joined(separator: " · ")
                largeurV = Double(abs(taille.width))
                hauteurV = Double(abs(taille.height))
                fpsV = fps
                debitV = Double(piste.estimatedDataRate)
                if let pa = asset.tracks(withMediaType: .audio).first {
                    aAudio = true
                    debitAudioV = Double(pa.estimatedDataRate)
                    if let descriptions = pa.formatDescriptions as? [CMFormatDescription], let desc = descriptions.first {
                        if let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(desc)?.pointee {
                            canauxV = max(1, min(2, Int(asbd.mChannelsPerFrame)))
                        }
                    }
                }

                let generateur = AVAssetImageGenerator(asset: asset)
                generateur.appliesPreferredTrackTransform = true
                generateur.maximumSize = CGSize(width: 160, height: 160)
                let instant = CMTime(seconds: min(1.0, max(0.0, duree / 2)), preferredTimescale: 600)
                if let cg = try? generateur.copyCGImage(at: instant, actualTime: nil) {
                    miniature = NSImage(cgImage: cg, size: NSSize(width: cg.width, height: cg.height))
                }
            } else {
                illisible = true
            }

            DispatchQueue.main.async {
                self.modifier(id) { v in
                    v.miniature = miniature
                    v.details = details
                    v.duree = duree
                    v.illisible = illisible
                    v.largeur = largeurV
                    v.hauteur = hauteurV
                    v.fps = fpsV
                    v.debitSource = debitV
                    v.aAudio = aAudio
                    v.canaux = canauxV
                    v.debitAudioSource = debitAudioV
                    if illisible {
                        v.etat = .erreur("Format non pris en charge par macOS")
                    }
                }
            }
        }
    }

    func modifier(_ id: UUID, _ f: (inout Video) -> Void) {
        if let i = items.firstIndex(where: { $0.id == id }) {
            f(&items[i])
        }
    }

    func retirer(_ id: UUID) {
        if enCours { return }
        items.removeAll { $0.id == id }
        if items.isEmpty { bilan = nil }
    }

    func vider() {
        if enCours { return }
        items = []
        bilan = nil
    }

    func afficherDansFinder() {
        guard let b = bilan, !b.sorties.isEmpty else { return }
        NSWorkspace.shared.activateFileViewerSelecting(b.sorties)
    }

    func annuler() {
        controle?.annuler()
    }

    // MARK: Compression

    func reglages() -> Reglages {
        var dossier: URL? = nil
        if destination == .autre { dossier = dossierAutre }
        return Reglages(mode: mode, qualite: qualite, tailleCibleMo: tailleCibleMo, largeurMax: largeurMax, hauteurMax: hauteurMax, imagesMax: imagesMax,
                        conteneur: conteneur, codec: codec, audio: audio, sonPerso: Int(sonPerso), dossierFixe: dossier, garderMeta: garderMeta)
    }

    func compresser() {
        if enCours { return }
        let liste: [(UUID, URL, Int64)] = items.filter { !$0.illisible }.map { ($0.id, $0.url, $0.taille) }
        if liste.isEmpty { return }
        let r = reglages()
        let ctrl = Controle()
        controle = ctrl
        enCours = true
        bilan = nil
        progres = 0
        for i in items.indices {
            if !items[i].illisible { items[i].etat = .attente }
        }

        DispatchQueue.global(qos: .userInitiated).async {
            // Empêche la mise en veille et le ralentissement de l'app pendant l'encodage
            let activite = ProcessInfo.processInfo.beginActivity(options: [.userInitiated, .idleSystemSleepDisabled], reason: "Compression de vidéos")

            var res = Bilan()
            res.nbTotal = liste.count
            let total = Double(liste.count)

            for (index, element) in liste.enumerated() {
                if ctrl.annule { break }
                let id = element.0
                let url = element.1
                let tailleAvant = element.2
                DispatchQueue.main.async {
                    self.modifier(id) { v in v.etat = .enCours(0) }
                }
                do {
                    let resultat = try Compresseur.traiter(url, r, controle: ctrl) { fraction in
                        DispatchQueue.main.async {
                            self.modifier(id) { v in v.etat = .enCours(fraction) }
                            self.progres = (Double(index) + fraction) / total
                        }
                    }
                    let sortie = resultat.0
                    let tailleApres = resultat.1
                    let depasse = resultat.2
                    res.nbOk += 1
                    res.avant += tailleAvant
                    res.apres += tailleApres
                    if tailleApres > tailleAvant { res.nbPlusLourd += 1 }
                    if depasse { res.nbAuDessusCible += 1 }
                    res.sorties.append(sortie)
                    DispatchQueue.main.async {
                        self.modifier(id) { v in v.sortie = sortie; v.etat = .termine(tailleApres) }
                        self.progres = Double(index + 1) / total
                    }
                } catch {
                    if ctrl.annule {
                        DispatchQueue.main.async {
                            self.modifier(id) { v in v.etat = .attente }
                        }
                        break
                    }
                    let message = (error as? ErreurCompression)?.message ?? "Échec"
                    res.nbEchecs += 1
                    DispatchQueue.main.async {
                        self.modifier(id) { v in v.etat = .erreur(message) }
                        self.progres = Double(index + 1) / total
                    }
                }
            }

            res.annule = ctrl.annule
            ProcessInfo.processInfo.endActivity(activite)
            DispatchQueue.main.async {
                self.bilan = res
                self.enCours = false
                self.controle = nil
            }
        }
    }
}

// MARK: - Vues

struct LigneView: View {
    let video: Video
    let estimation: Int64?
    let peutRetirer: Bool
    let retirer: () -> Void

    func variationTexte(_ t: Int64) -> String {
        let avant = Double(max(video.taille, 1))
        let delta = Int(((Double(t) - avant) / avant * 100.0).rounded())
        if delta <= 0 { return "−\(abs(delta)) %" }
        return "+\(delta) %"
    }

    func variationCouleur(_ t: Int64) -> Color {
        return t > video.taille ? Color.orange : Color.green
    }

    var detail: String {
        var morceaux: [String] = []
        if !video.details.isEmpty { morceaux.append(video.details) }
        morceaux.append(formaterTaille(video.taille))
        return morceaux.joined(separator: " · ")
    }

    @ViewBuilder var statut: some View {
        switch video.etat {
        case .attente:
            if let e = estimation {
                Text("≈ \(formaterTaille(e))")
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .help("Poids estimé après compression avec les réglages actuels.")
            } else {
                EmptyView()
            }
        case .enCours(let fraction):
            VStack(alignment: .trailing, spacing: 3) {
                ProgressView(value: fraction).frame(width: 90)
                Text("\(Int((fraction * 100).rounded())) %").font(.caption).foregroundColor(.secondary)
            }
        case .termine(let t):
            HStack(spacing: 10) {
                BoutonDossierSortie(url: video.sortie)
                VStack(alignment: .trailing, spacing: 2) {
                    Text(formaterTaille(t)).font(.callout)
                    Text(variationTexte(t)).font(.caption).foregroundColor(variationCouleur(t))
                }
            }
        case .erreur(let message):
            Text(message).font(.caption).foregroundColor(.red).lineLimit(2).multilineTextAlignment(.trailing)
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            Group {
                if let img = video.miniature {
                    Image(nsImage: img).resizable().scaledToFill()
                } else {
                    ZStack {
                        Rectangle().fill(Color.secondary.opacity(0.15))
                        Image(systemName: "film").foregroundColor(.secondary)
                    }
                }
            }
            .frame(width: 66, height: 44)
            .clipped()
            .cornerRadius(6)

            VStack(alignment: .leading, spacing: 2) {
                Text(video.url.lastPathComponent).lineLimit(1).truncationMode(.middle)
                Text(detail).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            statut
            if peutRetirer {
                Button(action: retirer) {
                    Image(systemName: "xmark.circle.fill")
                }
                .buttonStyle(.plain)
                .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

struct ContentView: View {
    @ObservedObject var m = Modele.partage
    @State private var survol = false
    @State private var avancesOuverts = false


    var body: some View {
        HStack(spacing: 0) {
            zoneGauche
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            Divider()
            panneau
                .frame(width: 330)
                .background(Color(NSColor.controlBackgroundColor))
        }
        .frame(minWidth: 880, idealWidth: 980, minHeight: 640, idealHeight: 700)
        .onDrop(of: [UTType.fileURL], isTargeted: $survol) { providers in
            m.deposer(providers)
            return true
        }
    }

    // MARK: Zone de gauche (dépôt + liste)

    var zoneGauche: some View {
        ZStack {
            if m.items.isEmpty {
                vide
            } else {
                liste
            }
            if survol {
                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(Color.accentColor.opacity(0.08))
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(Color.accentColor, style: StrokeStyle(lineWidth: 2, dash: [8, 6]))
                }
                .padding(14)
                .allowsHitTesting(false)
            }
        }
    }

    var vide: some View {
        VStack(spacing: 10) {
            Image(systemName: "film.stack")
                .font(.system(size: 54))
                .foregroundColor(.secondary)
            Text("Glissez des vidéos ou un dossier ici")
                .font(.title3)
            Text("ou cliquez sur « Choisir des vidéos… »")
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture { m.choisir() }
    }

    var titreListe: String {
        let n = m.items.count
        var texte = "\(n) vidéo\(n > 1 ? "s" : "") · \(formaterTaille(m.tailleTotale))"
        let duree = formaterDuree(m.dureeTotale)
        if !duree.isEmpty { texte += " · \(duree)" }
        return texte
    }

    var liste: some View {
        VStack(spacing: 0) {
            HStack {
                Text(titreListe)
                    .font(.headline)
                Spacer()
                Button("Vider la liste") { m.vider() }
                    .disabled(m.enCours)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            Divider()
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(m.items) { v in
                        VStack(spacing: 0) {
                            LigneView(video: v, estimation: m.estimation(v, m.reglages()), peutRetirer: !m.enCours, retirer: { m.retirer(v.id) })
                            Divider().padding(.leading, 94)
                        }
                    }
                }
            }
        }
    }

    // MARK: Panneau de réglages

    func bloc<Contenu: View>(_ titre: String, _ valeur: String? = nil, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(titre).fontWeight(.medium)
                Spacer()
                if let v = valeur {
                    Text(v).foregroundColor(.secondary)
                }
            }
            contenu()
        }
    }

    func choixDestination(_ titre: String, actif: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 6) {
                Image(systemName: actif ? "largecircle.fill.circle" : "circle")
                    .foregroundColor(actif ? Color.accentColor : Color.secondary)
                Text(titre)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: Blocs repliables (les descriptions s'affichent au survol de la souris)

    // Bloc toujours visible
    func blocFixe<Contenu: View>(_ titre: String, _ valeur: String, _ aide: String, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(titre).fontWeight(.medium).help(aide)
                Spacer()
                Text(valeur).foregroundColor(.secondary).lineLimit(1)
            }
            contenu()
        }
    }

    // Seul bloc que l'on peut replier : les paramètres avancés
    func blocAvances<Contenu: View>(_ titre: String, _ resume: String, _ aide: String, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: { avancesOuverts.toggle() }) {
                HStack(spacing: 6) {
                    Image(systemName: avancesOuverts ? "chevron.down" : "chevron.right")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .frame(width: 12)
                    Text(titre).fontWeight(.medium)
                    Spacer()
                    Text(resume).foregroundColor(.secondary).lineLimit(1)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .help(aide)
            if avancesOuverts {
                contenu()
            }
        }
    }

    func sousBloc<Contenu: View>(_ titre: String, _ aide: String, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(titre)
                .font(.callout)
                .foregroundColor(.secondary)
                .help(aide)
            contenu()
        }
    }

    var resumeDimension: String {
        if m.largeurMax == 0 && m.hauteurMax == 0 { return "Origine" }
        let l = m.largeurMax > 0 ? "\(m.largeurMax)" : "auto"
        let h = m.hauteurMax > 0 ? "\(m.hauteurMax)" : "auto"
        return "\(l) × \(h)"
    }

    // Champ texte pour un entier (vide = 0 = pas de limite)
    func texteEntier(_ valeur: Binding<Int>) -> Binding<String> {
        return Binding<String>(
            get: { valeur.wrappedValue > 0 ? String(valeur.wrappedValue) : "" },
            set: { texte in
                let chiffres = texte.filter { $0.isNumber }
                valeur.wrappedValue = min(20000, Int(chiffres) ?? 0)
            }
        )
    }

    // Boutons rapides : remplissent les deux cases
    var presetDimension: Binding<Int> {
        return Binding<Int>(
            get: {
                switch (m.largeurMax, m.hauteurMax) {
                case (0, 0): return 0
                case (1920, 1080): return 1080
                case (1280, 720): return 720
                case (854, 480): return 480
                case (640, 360): return 360
                default: return -1
                }
            },
            set: { choix in
                switch choix {
                case 1080:
                    m.largeurMax = 1920
                    m.hauteurMax = 1080
                case 720:
                    m.largeurMax = 1280
                    m.hauteurMax = 720
                case 480:
                    m.largeurMax = 854
                    m.hauteurMax = 480
                case 360:
                    m.largeurMax = 640
                    m.hauteurMax = 360
                default:
                    m.largeurMax = 0
                    m.hauteurMax = 0
                }
            }
        )
    }

    var resumeQualite: String {
        if m.mode == .taille { return "taille cible" }
        return "\(Int(m.qualite)) % · \(m.aideQualite)"
    }

    var resumeAudio: String {
        switch m.audio {
        case .original: return "son d’origine"
        case .aucun: return "sans son"
        case .k128: return "128 kb/s"
        case .k192: return "192 kb/s"
        case .k320: return "320 kb/s"
        case .perso: return m.sonPerso <= 0 ? "sans son" : "\(Int(m.sonPerso)) kb/s"
        }
    }

    var resumeAvancees: String {
        var morceaux: [String] = []
        if m.audio != .original { morceaux.append(resumeAudio) }
        if m.imagesMax > 0 { morceaux.append("\(m.imagesMax) i/s") }
        if m.mode == .taille { morceaux.append("\(m.tailleCibleMo) Mo max") }
        return morceaux.isEmpty ? "par défaut" : morceaux.joined(separator: " · ")
    }

    var resumeDestination: String {
        return m.destination == .cote ? "À côté" : "Autre dossier"
    }

    var aideCurseur: String {
        if m.mode == .taille {
            return "Ignorée tant que la taille cible est active (Paramètres avancés)."
        }
        return "\(m.aideQualite) · plus le % est bas, plus le fichier est léger."
    }

    // 2. Qualité
    var blocQualite: some View {
        blocFixe("Qualité", resumeQualite,
                      "Plus le pourcentage est bas, plus le fichier est léger. Vers 60 %, le compromis poids / image est bon pour la plupart des vidéos.") {
            Slider(value: $m.qualite, in: 1...100, step: 1)
                .disabled(m.mode == .taille)
                .help(aideCurseur)
        }
    }

    // 1. Dimensions
    var blocDimensions: some View {
        blocFixe("Dimensions", resumeDimension,
                 "Réduire les dimensions est le moyen le plus efficace d’alléger une vidéo.") {
            Picker("", selection: presetDimension) {
                Text("Origine").tag(0)
                Text("1080p").tag(1080)
                Text("720p").tag(720)
                Text("480p").tag(480)
                Text("360p").tag(360)
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .help("Raccourcis : 1080p = 1920 × 1080, 720p = 1280 × 720, 480p = 854 × 480, 360p = 640 × 360.")

            HStack(spacing: 8) {
                TextField("Auto", text: texteEntier($m.largeurMax))
                    .frame(width: 80)
                    .multilineTextAlignment(.trailing)
                Text("×").foregroundColor(.secondary)
                TextField("Auto", text: texteEntier($m.hauteurMax))
                    .frame(width: 80)
                    .multilineTextAlignment(.trailing)
                Text("px").foregroundColor(.secondary)
                Spacer()
            }
            .help("Largeur × hauteur maximales, par exemple 1920 × 1080. La vidéo garde ses proportions, n’est jamais agrandie, et la boîte s’adapte aux vidéos en portrait. Cases vides : dimensions d’origine.")
        }
    }

    // 3. Format
    var blocFormat: some View {
        blocFixe("Format", "\(m.conteneur.titre) · \(m.codec.titre)",
                      "Conteneur du fichier (MP4 ou MOV) et codec vidéo (H.264 ou H.265).") {
            Picker("", selection: $m.conteneur) {
                ForEach(Conteneur.allCases) { c in
                    Text(c.titre).tag(c)
                }
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .help(Conteneur.allCases.map { $0.aide }.joined(separator: "\n"))

            Picker("", selection: $m.codec) {
                ForEach(CodecVideo.allCases) { c in
                    Text(c.titre).tag(c)
                }
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .help(CodecVideo.allCases.map { $0.aide }.joined(separator: "\n"))
        }
    }

    // Options avancées : son, images par seconde, taille cible
    var blocSon: some View {
        sousBloc("Débit du son (kb/s)", "Qualité du son (AAC). « Origine » conserve le débit de l’original, « Sans son » supprime la piste audio. Plus le débit est bas, plus la vidéo est légère.") {
            Picker("", selection: $m.audio) {
                Text("Origine").tag(NiveauAudio.original)
                Text("Sans son").tag(NiveauAudio.aucun)
                Text("128").tag(NiveauAudio.k128)
                Text("192").tag(NiveauAudio.k192)
                Text("320").tag(NiveauAudio.k320)
            }
            .labelsHidden()
            .pickerStyle(.segmented)
        }
    }

    var blocImages: some View {
        sousBloc("Fréquence d’images", "Réduire la cadence allège surtout les vidéos en 50 ou 60 images/s. La vitesse de la vidéo n’est pas modifiée, et une vidéo n’est jamais portée à une cadence supérieure à l’originale.") {
            Picker("", selection: $m.imagesMax) {
                Text("Origine").tag(0)
                Text("30").tag(30)
                Text("24").tag(24)
                Text("15").tag(15)
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .help("Images par seconde maximum : Origine, 30, 24 ou 15.")
        }
    }

    var blocTailleCible: some View {
        sousBloc("Taille cible", "Chaque vidéo est compressée pour approcher cette taille en Mo. Remplace le réglage de qualité. Laisser vide pour désactiver. Une vidéo n’est jamais grossie, et une cible trop petite dégrade fortement l’image.") {
            HStack(spacing: 8) {
                TextField("Aucune", text: texteEntier($m.valeurMo))
                    .frame(width: 90)
                    .multilineTextAlignment(.trailing)
                Text("Mo par vidéo").foregroundColor(.secondary)
                Spacer()
            }
        }
    }

    var blocAvancees: some View {
        blocAvances("Paramètres avancés", resumeAvancees,
                    "Débit du son, fréquence d’images et taille cible.") {
            VStack(alignment: .leading, spacing: 14) {
                blocSon
                blocImages
                blocTailleCible
            }
        }
    }

    var blocDestination: some View {
        blocFixe("Enregistrer dans", resumeDestination, "Les originales ne sont jamais modifiées.") {
            choixDestination("Dossier « Compressées » à côté des originales", actif: m.destination == .cote) {
                m.destination = .cote
            }
            choixDestination("Un autre dossier", actif: m.destination == .autre) {
                m.selectionnerAutreDossier()
            }
            if m.destination == .autre, let d = m.dossierAutre {
                HStack {
                    Image(systemName: "folder").foregroundColor(.secondary)
                    Text(d.lastPathComponent).lineLimit(1).truncationMode(.middle)
                    Spacer()
                    Button("Changer…") { m.choisirDossierDestination() }
                }
                .font(.callout)
                .padding(.leading, 20)
            }
        }
    }

    var panneau: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    blocDimensions
                    blocQualite
                    blocFormat
                    blocAvancees
                    blocDestination

                    Toggle("Conserver les métadonnées", isOn: $m.garderMeta)
                        .help("Date, lieu de tournage (GPS)… Décochez pour les supprimer.")
                }
                .padding(20)
                .disabled(m.enCours)
            }

            Divider()
            pied
                .padding(20)
        }
    }

    // MARK: Pied : bouton, progression, bilan

    var texteBouton: String {
        let n = m.nbATraiter
        if n == 0 { return "Compresser" }
        return "Compresser \(n) vidéo\(n > 1 ? "s" : "")"
    }

    func estimationVue(_ e: Int64) -> some View {
        let avant = m.tailleValide
        let gain = Int((100.0 * Double(avant - e) / Double(max(avant, 1))).rounded())
        let signe = gain >= 0 ? "−" : "+"
        return VStack(alignment: .leading, spacing: 2) {
            Text("Poids estimé")
                .font(.caption).foregroundColor(.secondary)
            Text("\(formaterTaille(avant)) → ≈ \(formaterTaille(e))  (\(signe)\(abs(gain)) %)")
                .fontWeight(.medium)
        }
        .help("Estimation calculée d’après les réglages, la durée et les dimensions de chaque vidéo. Le résultat réel peut différer.")
    }

    var pied: some View {
        VStack(alignment: .leading, spacing: 10) {
            if !m.enCours && m.bilan == nil, let e = m.estimationTotale {
                estimationVue(e)
            }
            if m.enCours {
                ProgressView(value: m.progres, total: 1.0)
                Text("Compression… \(Int((m.progres * 100).rounded())) %")
                    .font(.caption).foregroundColor(.secondary)
            } else if let b = m.bilan {
                bilanVue(b)
            }

            if m.enCours {
                Button(action: { m.annuler() }) {
                    Text("Annuler")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.large)
                .keyboardShortcut(.cancelAction)
            } else {
                Button(action: { m.compresser() }) {
                    Text(texteBouton)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .keyboardShortcut(.defaultAction)
                .disabled(m.nbATraiter == 0)
            }
        }
    }

    func texteGain(_ b: Bilan) -> String {
        let gain = Int((100.0 * Double(b.avant - b.apres) / Double(max(b.avant, 1))).rounded())
        let signe = gain >= 0 ? "−" : "+"
        return "\(formaterTaille(b.avant)) → \(formaterTaille(b.apres))  (\(signe)\(abs(gain)) %)"
    }

    func bilanVue(_ b: Bilan) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("\(b.annule ? "Annulé" : "Terminé") : \(b.nbOk) vidéo\(b.nbOk > 1 ? "s" : "") sur \(b.nbTotal)")
                .fontWeight(.medium)
            if b.nbOk > 0 && b.avant > 0 {
                Text(texteGain(b))
                    .foregroundColor(.green)
            }
            if b.nbPlusLourd > 0 {
                Text("\(b.nbPlusLourd) vidéo(s) plus lourde(s) qu’avant : gardez l’original.")
                    .font(.caption).foregroundColor(.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if b.nbAuDessusCible > 0 {
                Text("\(b.nbAuDessusCible) vidéo(s) au-dessus de la taille cible : choisissez une cible plus grande ou des dimensions plus petites.")
                    .font(.caption).foregroundColor(.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if b.nbEchecs > 0 {
                Text("\(b.nbEchecs) échec(s), voir la liste.")
                    .font(.caption).foregroundColor(.red)
            }
            if !b.sorties.isEmpty {
                Button("Afficher dans le Finder") { m.afficherDansFinder() }
                    .padding(.top, 2)
            }
        }
    }
}

// MARK: - Application

// Détection automatique du type de fichier : image, vidéo ou audio.
// Les fichiers (et les dossiers) déposés dans n'importe quel onglet vont dans l'onglet qui leur correspond.
enum RouteurFichiers {
    static func router(_ urls: [URL]) {
        DispatchQueue.global(qos: .userInitiated).async {
            var videos: [URL] = []
            var sons: [URL] = []
            var images: [URL] = []
            for u in urls {
                videos.append(contentsOf: Modele.videos(dans: u))
                #if AUDIO
                sons.append(contentsOf: ModeleAudio.fichiers(dans: u))
                #endif
                #if IMAGE
                images.append(contentsOf: ModeleImage.images(dans: u))
                #endif
            }
            DispatchQueue.main.async {
                if !videos.isEmpty { Modele.partage.integrer(videos) }
                #if AUDIO
                if !sons.isEmpty { ModeleAudio.partage.integrer(sons) }
                #endif
                #if IMAGE
                if !images.isEmpty { ModeleImage.partage.integrer(images) }
                #endif

                // Onglet affiché : l'onglet courant s'il reçoit des fichiers, sinon celui qui en reçoit le plus
                let comptes: [(Int, Int)] = [(2, images.count), (0, videos.count), (1, sons.count)]
                if let actuel = comptes.first(where: { $0.0 == Onglets.partage.courant }), actuel.1 > 0 { return }
                if let meilleur = comptes.max(by: { $0.1 < $1.1 }), meilleur.1 > 0 {
                    Onglets.partage.courant = meilleur.0
                }
            }
        }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationWillFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.activate(ignoringOtherApps: true)
    }

    // Glisser des fichiers / un dossier sur l'icône de l'app : détection automatique du type
    func application(_ sender: NSApplication, openFiles filenames: [String]) {
        RouteurFichiers.router(filenames.map { URL(fileURLWithPath: $0) })
        sender.reply(toOpenOrPrint: .success)
    }

    func applicationWillTerminate(_ notification: Notification) {
        #if IMAGE
        ModeleImage.partage.sauverReglages()
        #endif
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}

final class Onglets: ObservableObject {
    static let partage = Onglets()
    @Published var courant: Int      // 0 = Vidéo, 1 = Audio, 2 = Image

    init() {
        #if IMAGE
        courant = 2                  // l'onglet Image s'ouvre en premier
        #else
        courant = 0
        #endif
    }

    // Ordre d'affichage : Image, Vidéo, Audio
    static var disponibles: [(Int, String)] {
        var liste: [(Int, String)] = []
        #if IMAGE
        liste.append((2, "Image"))
        #endif
        liste.append((0, "Vidéo"))
        #if AUDIO
        liste.append((1, "Audio"))
        #endif
        return liste
    }
}

#if AUDIO
func vueOngletAudio() -> AnyView { return AnyView(VueAudio()) }
#else
func vueOngletAudio() -> AnyView { return AnyView(EmptyView()) }
#endif

#if IMAGE
func vueOngletImage() -> AnyView { return AnyView(VueImage()) }
#else
func vueOngletImage() -> AnyView { return AnyView(EmptyView()) }
#endif

struct RacineView: View {
    @ObservedObject var onglets = Onglets.partage

    var body: some View {
        VStack(spacing: 0) {
            if Onglets.disponibles.count > 1 {
                Picker("", selection: $onglets.courant) {
                    ForEach(Onglets.disponibles, id: \.0) { element in
                        Text(element.1).tag(element.0)
                    }
                }
                .labelsHidden()
                .pickerStyle(.segmented)
                .frame(width: 300)
                .padding(.vertical, 8)
                Divider()
            }
            switch onglets.courant {
            case 1:
                vueOngletAudio()
            case 2:
                vueOngletImage()
            default:
                ContentView()
            }
        }
    }
}

@main
struct CompresseurApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate

    init() {
        NSWindow.allowsAutomaticWindowTabbing = false
    }

    var body: some Scene {
        WindowGroup("Media Compressor") {
            RacineView()
        }
        .handlesExternalEvents(matching: ["*"])
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Choisir des fichiers…") {
                    switch Onglets.partage.courant {
                    case 1:
                        #if AUDIO
                        ModeleAudio.partage.choisir()
                        #else
                        break
                        #endif
                    case 2:
                        #if IMAGE
                        ModeleImage.partage.choisir()
                        #else
                        break
                        #endif
                    default:
                        Modele.partage.choisir()
                    }
                }
                .keyboardShortcut("o")
            }
        }
    }
}
