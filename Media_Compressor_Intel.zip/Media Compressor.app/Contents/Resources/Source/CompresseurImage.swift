// Onglet Image — compression de photos + « Ajouter une grille ».
// Compilé avec l'option -D IMAGE ; si sa compilation échoue, le lanceur retombe sur les autres onglets.
// Moteur : ImageIO / Core Graphics (intégrés à macOS). Les photos originales ne sont jamais modifiées.
//
// Pour chaque photo, le traitement suit toujours le même ordre :
//   1. redimensionnement (si la compression est activée),
//   2. dessin de la grille (si elle est activée),
//   3. encodage avec le format et la qualité choisis.
// La grille est donc dessinée à la taille finale : ses lignes restent nettes
// et gardent les mêmes proportions que sur la photo d'origine.

import SwiftUI
import AppKit
import Combine
import ImageIO
import UniformTypeIdentifiers

let extensionsImages: Set<String> = ["jpg", "jpeg", "png", "heic", "heif", "tif", "tiff", "bmp", "gif"]
let nomDossierSortieImage = "Exports"
let nomsDossiersIgnores: [String] = ["Exports", "Compressées"]

// MARK: - Types

struct GridSettings {
    var columns: Int
    var rows: Int
    var thickness: CGFloat   // en pixels de l'image d'origine
    var opacity: CGFloat     // de 0 à 1
    var outerBorder: Bool
    var doubled: Bool        // seconde grille identique, décalée
    var offsetX: CGFloat     // décalage horizontal, en fraction d'une cellule (0 à 1)
    var offsetY: CGFloat     // décalage vertical, en fraction d'une cellule (0 à 1)
    var red: CGFloat         // couleur des lignes (sRGB, 0 à 1)
    var green: CGFloat
    var blue: CGFloat
}

enum DimensionImage: Hashable {
    case origine
    case pourcent(Int)
    case cote(Int)
    case pourcentPerso
    case cotePerso
    case boite(Int)          // boîte 16:9 définie par sa hauteur : 2160 (4K), 1080, 720, 480
}

enum CibleImage {
    case aucune
    case pourcent(Int)
    case cote(Int)
    case boite(Int, Int)     // largeur × hauteur de la boîte (côté le plus long en premier)
}

/// Boîte 16:9 correspondant à un raccourci (comme pour les vidéos).
func dimensionsBoite(_ hauteur: Int) -> (Int, Int) {
    switch hauteur {
    case 2160: return (3840, 2160)
    case 1080: return (1920, 1080)
    case 720: return (1280, 720)
    default: return (854, 480)
    }
}

enum FormatSortie: String, CaseIterable, Identifiable {
    case png, jpeg, heic, origine
    var id: String { rawValue }
    var titre: String {
        switch self {
        case .png: return "PNG"
        case .jpeg: return "JPEG"
        case .heic: return "HEIC"
        case .origine: return "Original"
        }
    }
    var aide: String {
        switch self {
        case .png: return "Sans perte, avec transparence. Pas de réglage de qualité : seul le redimensionnement allège le fichier."
        case .jpeg: return "Compatible partout."
        case .heic: return "Plus léger, format Apple moderne."
        case .origine: return "Garde le PNG et le HEIC tels quels ; les autres formats (JPEG, TIFF, BMP, GIF) sortent en JPEG."
        }
    }
}

enum DestinationImage {
    case cote
    case autre
}

enum EtatImage {
    case attente
    case enCours
    case termine(Int64)
    case erreur(String)
}

struct Photo: Identifiable {
    let id = UUID()
    let url: URL
    var sortie: URL? = nil
    var taille: Int64
    var dimensions: String = ""
    var miniature: NSImage? = nil
    var etat: EtatImage = .attente
}

struct ReglagesImage {
    var grille: GridSettings?        // nil = pas de grille
    var largeurReference: Int        // largeur qui a servi à régler l'épaisseur des lignes
    var compresser: Bool
    var qualite: Double
    var cible: CibleImage
    var format: FormatSortie
    var dossierFixe: URL?
    var garderMeta: Bool
    var letterbox: Bool = false          // centrer l'image sur un fond de la taille exacte de la boîte
    var bandesBlanches: Bool = false     // couleur des bandes : noir (défaut) ou blanc
}

struct BilanImage {
    var nbOk = 0
    var nbTotal = 0
    var avant: Int64 = 0
    var apres: Int64 = 0
    var nbPlusLourd = 0
    var nbEchecs = 0
    var avecCompression = false
    var annule = false
    var nbIgnorees = 0
    var sorties: [URL] = []
}

/// Drapeau d'annulation partagé entre l'interface et les threads de traitement.
final class Jeton {
    private let verrou = NSLock()
    private var annule = false

    func annuler() {
        verrou.lock()
        annule = true
        verrou.unlock()
    }

    var estAnnule: Bool {
        verrou.lock()
        defer { verrou.unlock() }
        return annule
    }
}

struct ErreurImage: Error {
    let message: String
}

func formaterTailleImage(_ octets: Int64) -> String {
    return ByteCountFormatter.string(fromByteCount: octets, countStyle: .file)
}

let formateurEntierImage: NumberFormatter = {
    let f = NumberFormatter()
    f.numberStyle = .none
    f.allowsFloats = false
    f.minimum = 1
    f.maximum = 20000
    return f
}()

// MARK: - Outils d'image (lecture et grille)

enum ImageTools {

    /// Taille en pixels de l'image, orientation EXIF prise en compte.
    static func pixelSize(of url: URL) -> (width: Int, height: Int)? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil),
              CGImageSourceGetCount(src) > 0,
              let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
              let w = props[kCGImagePropertyPixelWidth] as? Int,
              let h = props[kCGImagePropertyPixelHeight] as? Int,
              w > 0, h > 0
        else { return nil }
        let orientation = (props[kCGImagePropertyOrientation] as? Int) ?? 1
        return (5...8).contains(orientation) ? (h, w) : (w, h)
    }

    /// Décode l'image (orientée correctement), au plus `maxPixel` pixels sur le grand côté.
    static func decode(url: URL, maxPixel: Int) -> CGImage? {
        guard let size = pixelSize(of: url),
              let src = CGImageSourceCreateWithURL(url as CFURL, nil)
        else { return nil }
        let target = max(1, min(maxPixel, max(size.width, size.height)))
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: target
        ]
        return CGImageSourceCreateThumbnailAtIndex(src, 0, options as CFDictionary)
    }

    /// Dessine l'image puis la grille (couleur au choix) par-dessus. L'image produite a la taille de `source`.
    /// - referenceWidth : largeur de l'image d'origine, pour que l'épaisseur (en pixels
    ///   d'origine) reste proportionnelle quand on travaille sur une image réduite.
    static func render(source: CGImage,
                       referenceWidth: Int,
                       settings: GridSettings,
                       forJPEG: Bool,
                       pixelAligned: Bool) -> CGImage? {
        let w = source.width
        let h = source.height
        let W = CGFloat(w)
        let H = CGFloat(h)

        let scale = W / CGFloat(max(referenceWidth, 1))
        var t = settings.thickness * scale
        t = pixelAligned ? max(1, t.rounded()) : max(0.5, t)

        // Espace colorimétrique : celui de l'image si c'est du RGB, sinon sRGB.
        var spaces: [CGColorSpace] = []
        if let cs = source.colorSpace, cs.model == .rgb { spaces.append(cs) }
        if let srgb = CGColorSpace(name: CGColorSpace.sRGB) { spaces.append(srgb) }

        let info: UInt32 = forJPEG
            ? CGImageAlphaInfo.noneSkipLast.rawValue
            : CGImageAlphaInfo.premultipliedLast.rawValue

        var context: CGContext?
        for cs in spaces {
            context = CGContext(data: nil, width: w, height: h,
                                bitsPerComponent: 8, bytesPerRow: 0,
                                space: cs, bitmapInfo: info)
            if context != nil { break }
        }
        guard let ctx = context else { return nil }

        ctx.interpolationQuality = .high
        let full = CGRect(x: 0, y: 0, width: W, height: H)

        if forJPEG {
            // Pas de transparence : fond blanc sous l'image.
            ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
            ctx.fill(full)
        }
        ctx.draw(source, in: full)

        // Toutes les lignes forment un seul tracé : les croisements ne sont pas
        // dessinés deux fois, même avec une opacité inférieure à 100 %.
        let path = CGMutablePath()
        let cols = max(1, settings.columns)
        let rows = max(1, settings.rows)
        let firstC = settings.outerBorder ? 0 : 1
        let lastC = settings.outerBorder ? cols : cols - 1
        let firstR = settings.outerBorder ? 0 : 1
        let lastR = settings.outerBorder ? rows : rows - 1

        for i in stride(from: firstC, through: lastC, by: 1) {
            var left = W * CGFloat(i) / CGFloat(cols) - t / 2
            if i == 0 { left = 0 }
            if i == cols { left = W - t }
            if pixelAligned { left = left.rounded() }
            path.addRect(CGRect(x: left, y: 0, width: t, height: H))
        }
        for j in stride(from: firstR, through: lastR, by: 1) {
            var bottom = H * CGFloat(j) / CGFloat(rows) - t / 2
            if j == 0 { bottom = 0 }
            if j == rows { bottom = H - t }
            if pixelAligned { bottom = bottom.rounded() }
            path.addRect(CGRect(x: 0, y: bottom, width: W, height: t))
        }

        // Seconde grille (option « Doubler la grille ») : même tracé, donc pas de double
        // mélange aux croisements. Jamais de ligne sur le bord de l'image.
        if settings.doubled {
            let dx = min(1, max(0, settings.offsetX))
            let dy = min(1, max(0, settings.offsetY))
            for i in 0...cols {
                let cx = W * (CGFloat(i) + dx) / CGFloat(cols)
                if cx <= 0 || cx >= W { continue }
                var left = cx - t / 2
                if pixelAligned { left = left.rounded() }
                path.addRect(CGRect(x: left, y: 0, width: t, height: H))
            }
            for j in 0...rows {
                // Le décalage vertical se mesure depuis le haut de l'image ;
                // Core Graphics compte depuis le bas.
                let cyTop = H * (CGFloat(j) + dy) / CGFloat(rows)
                if cyTop <= 0 || cyTop >= H { continue }
                var bottom = (H - cyTop) - t / 2
                if pixelAligned { bottom = bottom.rounded() }
                path.addRect(CGRect(x: 0, y: bottom, width: W, height: t))
            }
        }

        ctx.setFillColor(CGColor(red: settings.red, green: settings.green, blue: settings.blue, alpha: settings.opacity))
        ctx.addPath(path)
        ctx.fillPath()
        return ctx.makeImage()
    }
}

// MARK: - Moteur de traitement (redimensionnement + grille + encodage)

enum CompresseurImage {

    static func aTransparence(_ img: CGImage) -> Bool {
        switch img.alphaInfo {
        case .none, .noneSkipFirst, .noneSkipLast:
            return false
        default:
            return true
        }
    }

    // Aplatit sur fond blanc (le JPEG ne gère pas la transparence)
    static func aplatir(_ img: CGImage) -> CGImage? {
        var espaces: [CGColorSpace] = []
        if let c = img.colorSpace, c.model == .rgb { espaces.append(c) }
        if let s = CGColorSpace(name: CGColorSpace.sRGB) { espaces.append(s) }
        let rect = CGRect(x: 0, y: 0, width: img.width, height: img.height)
        for cs in espaces {
            let info = CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
            if let ctx = CGContext(data: nil, width: img.width, height: img.height, bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: info) {
                ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
                ctx.fill(rect)
                ctx.draw(img, in: rect)
                return ctx.makeImage()
            }
        }
        return nil
    }

    // Centre l'image sur un fond uni (noir ou blanc) de largeur × hauteur donnée. Pas d'agrandissement.
    static func ajouterBandes(_ img: CGImage, largeur: Int, hauteur: Int, blanc: Bool) -> CGImage? {
        let largeurFond = max(largeur, img.width)
        let hauteurFond = max(hauteur, img.height)
        var espaces: [CGColorSpace] = []
        if let c = img.colorSpace, c.model == .rgb { espaces.append(c) }
        if let s = CGColorSpace(name: CGColorSpace.sRGB) { espaces.append(s) }
        let valeur: CGFloat = blanc ? 1 : 0
        for cs in espaces {
            let info = CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
            if let ctx = CGContext(data: nil, width: largeurFond, height: hauteurFond, bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: info) {
                ctx.setFillColor(CGColor(red: valeur, green: valeur, blue: valeur, alpha: 1))
                ctx.fill(CGRect(x: 0, y: 0, width: largeurFond, height: hauteurFond))
                let x = (largeurFond - img.width) / 2
                let y = (hauteurFond - img.height) / 2
                ctx.draw(img, in: CGRect(x: x, y: y, width: img.width, height: img.height))
                return ctx.makeImage()
            }
        }
        return nil
    }

    static func cheminUnique(dossier: URL, base: String, ext: String, verrou: NSLock) -> URL {
        verrou.lock()
        defer { verrou.unlock() }
        let fm = FileManager.default
        var candidat = dossier.appendingPathComponent(base).appendingPathExtension(ext)
        var i = 1
        while fm.fileExists(atPath: candidat.path) {
            candidat = dossier.appendingPathComponent("\(base)-\(i)").appendingPathExtension(ext)
            i += 1
        }
        fm.createFile(atPath: candidat.path, contents: nil)
        return candidat
    }

    static func traiter(_ source: URL, _ r: ReglagesImage, verrou: NSLock) throws -> (URL, Int64) {
        guard let src = CGImageSourceCreateWithURL(source as CFURL, nil), CGImageSourceGetCount(src) > 0 else {
            throw ErreurImage(message: "Fichier illisible")
        }
        let props = (CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any]) ?? [:]
        let w = (props[kCGImagePropertyPixelWidth] as? Int) ?? 0
        let h = (props[kCGImagePropertyPixelHeight] as? Int) ?? 0
        if w <= 0 || h <= 0 { throw ErreurImage(message: "Dimensions inconnues") }

        // 1. Redimensionnement (jamais d'agrandissement)
        let plusGrand = max(w, h)
        var cote = plusGrand
        switch r.cible {
        case .aucune:
            break
        case .pourcent(let p):
            cote = max(1, Int((Double(plusGrand) * Double(p) / 100.0).rounded()))
        case .cote(let c):
            cote = c
        case .boite(let bl, let bh):
            // Dimensions réelles (orientation EXIF appliquée) ; la boîte pivote pour les images en portrait
            let orientation = (props[kCGImagePropertyOrientation] as? Int) ?? 1
            let ow = orientation >= 5 ? h : w
            let oh = orientation >= 5 ? w : h
            let boiteL = oh > ow ? bh : bl
            let boiteH = oh > ow ? bl : bh
            let echelle = min(1.0, Double(boiteL) / Double(ow), Double(boiteH) / Double(oh))
            cote = max(1, Int((Double(plusGrand) * echelle).rounded()))
        }
        cote = min(cote, plusGrand)

        let optsMiniature: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: cote,
            kCGImageSourceShouldCacheImmediately: true
        ]
        guard var image = CGImageSourceCreateThumbnailAtIndex(src, 0, optsMiniature as CFDictionary) else {
            throw ErreurImage(message: "Décodage impossible")
        }

        // Format de sortie
        let extSource = source.pathExtension.lowercased()
        var uti = "public.jpeg"
        var extSortie = "jpg"
        switch r.format {
        case .png:
            uti = "public.png"
            extSortie = "png"
        case .jpeg:
            break
        case .heic:
            uti = "public.heic"
            extSortie = "heic"
        case .origine:
            if extSource == "png" {
                uti = "public.png"
                extSortie = "png"
            } else if extSource == "heic" || extSource == "heif" {
                uti = "public.heic"
                extSortie = "heic"
            }
        }

        let typesPris = (CGImageDestinationCopyTypeIdentifiers() as? [String]) ?? []
        if !typesPris.contains(uti) {
            throw ErreurImage(message: "Format non pris en charge")
        }

        // 2. Grille (dessinée à la taille finale)
        if let g = r.grille {
            // Le JPEG n'a pas de transparence ; pour les autres formats, on ne garde un canal
            // alpha que si l'image d'origine en avait un.
            let sansAlpha = (uti == "public.jpeg") || !aTransparence(image)
            guard let dessinee = ImageTools.render(source: image,
                                                   referenceWidth: r.largeurReference,
                                                   settings: g,
                                                   forJPEG: sansAlpha,
                                                   pixelAligned: true) else {
                throw ErreurImage(message: "Dessin de la grille impossible")
            }
            image = dessinee
        } else if uti == "public.jpeg" && aTransparence(image) {
            if let plat = aplatir(image) { image = plat }
        }

        // 2 bis. Letterbox : l'image est centrée sur un fond à la taille exacte de la boîte
        if r.letterbox, case .boite(let bl, let bh) = r.cible {
            let portrait = image.height > image.width
            let largeurFond = portrait ? bh : bl
            let hauteurFond = portrait ? bl : bh
            guard let avecBandes = ajouterBandes(image, largeur: largeurFond, hauteur: hauteurFond, blanc: r.bandesBlanches) else {
                throw ErreurImage(message: "Ajout des bandes impossible")
            }
            image = avecBandes
        }

        // 3. Encodage : propriétés
        var dprops: [CFString: Any] = [:]
        if r.garderMeta {
            dprops = props
            dprops.removeValue(forKey: kCGImagePropertyPixelWidth)
            dprops.removeValue(forKey: kCGImagePropertyPixelHeight)
            dprops.removeValue(forKey: kCGImagePropertyDepth)
            dprops[kCGImagePropertyOrientation] = 1   // déjà appliquée
            if var tiff = dprops[kCGImagePropertyTIFFDictionary] as? [CFString: Any] {
                tiff[kCGImagePropertyTIFFOrientation] = 1
                dprops[kCGImagePropertyTIFFDictionary] = tiff
            }
            if var exif = dprops[kCGImagePropertyExifDictionary] as? [CFString: Any] {
                exif[kCGImagePropertyExifPixelXDimension] = image.width
                exif[kCGImagePropertyExifPixelYDimension] = image.height
                dprops[kCGImagePropertyExifDictionary] = exif
            }
        }
        if uti != "public.png" {
            // Sans compression, la qualité est fixée à 95 % (comme l'ancienne application Grille).
            let qualite = r.compresser ? r.qualite : 95.0
            dprops[kCGImageDestinationLossyCompressionQuality] = max(0.01, min(1.0, qualite / 100.0))
        }

        // Dossier et nom de sortie
        let fm = FileManager.default
        let dossier: URL
        if let fixe = r.dossierFixe {
            dossier = fixe
        } else {
            dossier = source.deletingLastPathComponent().appendingPathComponent(nomDossierSortieImage, isDirectory: true)
        }
        do {
            try fm.createDirectory(at: dossier, withIntermediateDirectories: true, attributes: nil)
        } catch {
            throw ErreurImage(message: "Dossier inaccessible")
        }
        let suffixe = (r.grille != nil) ? "_grille" : ""
        let base = source.deletingPathExtension().lastPathComponent + suffixe
        let sortie = cheminUnique(dossier: dossier, base: base, ext: extSortie, verrou: verrou)

        guard let dest = CGImageDestinationCreateWithURL(sortie as CFURL, uti as CFString, 1, nil) else {
            try? fm.removeItem(at: sortie)
            throw ErreurImage(message: "Écriture impossible")
        }
        CGImageDestinationAddImage(dest, image, dprops as CFDictionary)
        if !CGImageDestinationFinalize(dest) {
            try? fm.removeItem(at: sortie)
            throw ErreurImage(message: "Échec de l’encodage")
        }

        let attrs = try? fm.attributesOfItem(atPath: sortie.path)
        let taille = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
        return (sortie, taille)
    }
}

// MARK: - Modèle

final class ModeleImage: ObservableObject {
    static let partage = ModeleImage()

    // Liste des photos et aperçu
    @Published var items: [Photo] = []
    @Published private(set) var selectionID: UUID? = nil
    @Published private(set) var apercu: NSImage? = nil
    @Published var messageErreur: String? = nil

    // Grille (valeurs par défaut : 18 × 9, lignes de 4 px pour 1920 px de large)
    @Published var gridEnabled: Bool = false { didSet { rafraichirApercu() } }
    @Published var columns: Double = 18 { didSet { rafraichirApercu() } }
    @Published var rows: Double = 9 { didSet { rafraichirApercu() } }
    @Published var thickness: Double = 4 {
        didSet {
            // On retient l'épaisseur en proportion de la largeur de l'image, pour la mémoriser.
            if !miseAJourAuto && largeurReference > 0 {
                epaisseurRelative = thickness / Double(largeurReference)
            }
            rafraichirApercu()
        }
    }
    @Published var thicknessMax: Double = 40
    @Published var opacityPercent: Double = 100 { didSet { rafraichirApercu() } }
    @Published var outerBorder: Bool = false { didSet { rafraichirApercu() } }
    @Published var doubled: Bool = false { didSet { rafraichirApercu() } }
    @Published var offsetXPercent: Double = 50 { didSet { rafraichirApercu() } }
    @Published var offsetYPercent: Double = 50 { didSet { rafraichirApercu() } }
    @Published var couleurGrille: Color = Color.white { didSet { rafraichirApercu() } }

    // Compression
    @Published var compressionActive: Bool = true
    @Published var qualite: Double = 50
    @Published var dimension: DimensionImage = .origine
    @Published var valeurPct: Int = 50
    @Published var valeurPx: Int = 1920
    @Published var letterbox: Bool = false
    @Published var bandesBlanches: Bool = false

    // Sortie
    @Published var format: FormatSortie = .jpeg
    @Published var destination: DestinationImage = .cote
    @Published var dossierAutre: URL? = nil
    @Published var garderMeta: Bool = true

    // Traitement
    @Published var enCours: Bool = false
    @Published var progres: Int = 0
    @Published var bilan: BilanImage? = nil
    @Published var annulationDemandee: Bool = false

    private var jeton: Jeton? = nil
    private var epaisseurRelative: Double = 4.0 / 1920.0
    private var miseAJourAuto = false
    private let defauts = UserDefaults.standard

    private var apercuSource: CGImage? = nil
    private var largeurReference: Int = 0   // largeur de la première image : référence de l'épaisseur

    var composantesCouleur: (CGFloat, CGFloat, CGFloat) {
        let c = NSColor(couleurGrille).usingColorSpace(.sRGB) ?? NSColor.white
        return (c.redComponent, c.greenComponent, c.blueComponent)
    }

    var reglagesGrille: GridSettings {
        let couleur = composantesCouleur
        return GridSettings(columns: max(1, Int(columns.rounded())),
                     rows: max(1, Int(rows.rounded())),
                     thickness: CGFloat(thickness),
                     opacity: CGFloat(opacityPercent / 100),
                     outerBorder: outerBorder,
                     doubled: doubled,
                     offsetX: CGFloat(offsetXPercent / 100),
                     offsetY: CGFloat(offsetYPercent / 100),
                     red: couleur.0,
                     green: couleur.1,
                     blue: couleur.2)
    }

    // MARK: Mémorisation des réglages

    init() {
        chargerReglages()
    }

    private func lire(_ cle: String, _ defaut: Double, _ plage: ClosedRange<Double>) -> Double {
        guard defauts.object(forKey: cle) != nil else { return defaut }
        return min(plage.upperBound, max(plage.lowerBound, defauts.double(forKey: cle)))
    }

    private func lireBool(_ cle: String, _ defaut: Bool) -> Bool {
        guard defauts.object(forKey: cle) != nil else { return defaut }
        return defauts.bool(forKey: cle)
    }

    private func texteDimension(_ d: DimensionImage) -> String {
        switch d {
        case .origine: return "origine"
        case .pourcent(let p): return "pct:\(p)"
        case .cote(let c): return "cote:\(c)"
        case .pourcentPerso: return "pctPerso"
        case .cotePerso: return "cotePerso"
        case .boite(let h): return "boite:\(h)"
        }
    }

    private func texteVersDimension(_ t: String) -> DimensionImage {
        if t == "pctPerso" { return .pourcentPerso }
        if t == "cotePerso" { return .cotePerso }
        if t.hasPrefix("pct:"), let n = Int(t.dropFirst(4)) { return .pourcent(n) }
        if t.hasPrefix("cote:"), let n = Int(t.dropFirst(5)) { return .cote(n) }
        if t.hasPrefix("boite:"), let n = Int(t.dropFirst(6)), [2160, 1080, 720, 480].contains(n) { return .boite(n) }
        return .origine
    }

    private func chargerReglages() {
        // Nouvelles valeurs par défaut (compression activée, qualité 50 %, JPEG) :
        // on oublie une seule fois les anciens choix correspondants.
        if defauts.integer(forKey: "versionReglages") < 2 {
            defauts.removeObject(forKey: "compressionActive")
            defauts.removeObject(forKey: "qualite")
            defauts.removeObject(forKey: "format")
            defauts.set(2, forKey: "versionReglages")
        }
        // Version 3 : la grille n'est plus activée par défaut (on oublie une seule fois l'ancien choix).
        if defauts.integer(forKey: "versionReglages") < 3 {
            defauts.removeObject(forKey: "gridEnabled")
            defauts.set(3, forKey: "versionReglages")
        }
        gridEnabled = lireBool("gridEnabled", false)
        columns = lire("columns", 18, 1...60)
        rows = lire("rows", 9, 1...60)
        opacityPercent = lire("opacityPercent", 100, 0...100)
        outerBorder = lireBool("outerBorder", false)
        doubled = lireBool("doubled", false)
        offsetXPercent = lire("offsetXPercent", 50, 0...100)
        offsetYPercent = lire("offsetYPercent", 50, 0...100)
        epaisseurRelative = lire("epaisseurRelative", 4.0 / 1920.0, 0.0001...0.2)
        if defauts.object(forKey: "couleurR") != nil {
            couleurGrille = Color(.sRGB,
                                  red: lire("couleurR", 1, 0...1),
                                  green: lire("couleurG", 1, 0...1),
                                  blue: lire("couleurB", 1, 0...1),
                                  opacity: 1)
        }
        compressionActive = lireBool("compressionActive", true)
        qualite = lire("qualite", 50, 1...100)
        dimension = texteVersDimension(defauts.string(forKey: "dimension") ?? "origine")
        valeurPct = Int(lire("valeurPct", 50, 1...99))
        valeurPx = Int(lire("valeurPx", 1920, 16...20000))
        letterbox = lireBool("letterbox", false)
        bandesBlanches = lireBool("bandesBlanches", false)
        format = FormatSortie(rawValue: defauts.string(forKey: "format") ?? "") ?? .jpeg
        garderMeta = lireBool("garderMeta", true)
        if let chemin = defauts.string(forKey: "dossierAutre"),
           FileManager.default.fileExists(atPath: chemin) {
            dossierAutre = URL(fileURLWithPath: chemin, isDirectory: true)
            if defauts.string(forKey: "destination") == "autre" { destination = .autre }
        }
    }

    func sauverReglages() {
        defauts.set(gridEnabled, forKey: "gridEnabled")
        defauts.set(columns, forKey: "columns")
        defauts.set(rows, forKey: "rows")
        defauts.set(opacityPercent, forKey: "opacityPercent")
        defauts.set(outerBorder, forKey: "outerBorder")
        defauts.set(doubled, forKey: "doubled")
        defauts.set(offsetXPercent, forKey: "offsetXPercent")
        defauts.set(offsetYPercent, forKey: "offsetYPercent")
        defauts.set(epaisseurRelative, forKey: "epaisseurRelative")
        let c = composantesCouleur
        defauts.set(Double(c.0), forKey: "couleurR")
        defauts.set(Double(c.1), forKey: "couleurG")
        defauts.set(Double(c.2), forKey: "couleurB")
        defauts.set(compressionActive, forKey: "compressionActive")
        defauts.set(qualite, forKey: "qualite")
        defauts.set(texteDimension(dimension), forKey: "dimension")
        defauts.set(valeurPct, forKey: "valeurPct")
        defauts.set(valeurPx, forKey: "valeurPx")
        defauts.set(letterbox, forKey: "letterbox")
        defauts.set(bandesBlanches, forKey: "bandesBlanches")
        defauts.set(format.rawValue, forKey: "format")
        defauts.set(garderMeta, forKey: "garderMeta")
        defauts.set(destination == .autre ? "autre" : "cote", forKey: "destination")
        if let dossier = dossierAutre { defauts.set(dossier.path, forKey: "dossierAutre") }
    }

    var selection: Photo? {
        guard let id = selectionID else { return nil }
        return items.first(where: { $0.id == id })
    }

    var aideQualite: String {
        let q = Int(qualite)
        if q >= 95 { return "Quasi identique" }
        if q >= 90 { return "Très haute qualité" }
        if q >= 80 { return "Recommandé" }
        if q >= 65 { return "Bon compromis" }
        if q > 40 { return "Allègement marqué" }
        if q > 20 { return "Fort allègement" }
        return "Très compressé"
    }

    var tailleTotale: Int64 {
        return items.reduce(Int64(0)) { $0 + $1.taille }
    }

    // MARK: Ajout de photos

    func choisir() {
        if enCours { return }
        let panneau = NSOpenPanel()
        panneau.title = "Choisir des photos ou un dossier"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = true
        panneau.canChooseDirectories = true
        panneau.allowsMultipleSelection = true
        panneau.allowedContentTypes = [UTType.image]
        if panneau.runModal() == .OK {
            ajouter(panneau.urls)
        }
    }

    func choisirDossierDestination() {
        let panneau = NSOpenPanel()
        panneau.title = "Dossier de destination"
        panneau.prompt = "Choisir"
        panneau.canChooseFiles = false
        panneau.canChooseDirectories = true
        panneau.canCreateDirectories = true
        panneau.allowsMultipleSelection = false
        if panneau.runModal() == .OK, let u = panneau.url {
            dossierAutre = u
            destination = .autre
        }
    }

    func selectionnerAutreDossier() {
        if dossierAutre == nil {
            choisirDossierDestination()
        } else {
            destination = .autre
        }
    }

    func deposer(_ providers: [NSItemProvider]) {
        let groupe = DispatchGroup()
        let verrou = NSLock()
        var urls: [URL] = []
        for p in providers {
            groupe.enter()
            p.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                var u: URL? = nil
                if let d = item as? Data {
                    u = URL(dataRepresentation: d, relativeTo: nil)
                } else if let x = item as? URL {
                    u = x
                }
                if let u = u {
                    verrou.lock()
                    urls.append(u)
                    verrou.unlock()
                }
                groupe.leave()
            }
        }
        groupe.notify(queue: .main) {
            // Détection automatique : chaque fichier va dans l'onglet qui correspond à son type
            RouteurFichiers.router(urls)
        }
    }

    func ajouter(_ urls: [URL]) {
        if enCours { return }
        DispatchQueue.global(qos: .userInitiated).async {
            var trouves: [URL] = []
            for u in urls {
                trouves.append(contentsOf: ModeleImage.images(dans: u))
            }
            DispatchQueue.main.async {
                self.integrer(trouves)
            }
        }
    }

    static func images(dans url: URL) -> [URL] {
        let fm = FileManager.default
        var estDossier: ObjCBool = false
        guard fm.fileExists(atPath: url.path, isDirectory: &estDossier) else { return [] }
        if estDossier.boolValue {
            var res: [URL] = []
            guard let e = fm.enumerator(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { return [] }
            let exclus = Set(nomsDossiersIgnores.map { $0.precomposedStringWithCanonicalMapping })
            for case let f as URL in e {
                let estDir = (try? f.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
                if estDir {
                    if exclus.contains(f.lastPathComponent.precomposedStringWithCanonicalMapping) {
                        e.skipDescendants()
                    }
                    continue
                }
                if extensionsImages.contains(f.pathExtension.lowercased()) {
                    res.append(f)
                }
            }
            return res.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
        } else {
            return extensionsImages.contains(url.pathExtension.lowercased()) ? [url] : []
        }
    }

    func integrer(_ urls: [URL]) {
        if enCours { return }
        if urls.isEmpty {
            messageErreur = "Aucune image trouvée dans cette sélection."
            return
        }
        messageErreur = nil
        if bilan != nil {
            // Nouvelle série après un traitement terminé
            items = []
            bilan = nil
            effacerApercu()
        }
        let etaitVide = items.isEmpty
        var connus = Set(items.map { $0.url.path })
        var nouveaux: [Photo] = []
        for u in urls {
            if connus.contains(u.path) { continue }
            connus.insert(u.path)
            let attrs = try? FileManager.default.attributesOfItem(atPath: u.path)
            let t = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            nouveaux.append(Photo(url: u, taille: t))
        }
        items.append(contentsOf: nouveaux)
        for p in nouveaux {
            chargerMiniature(p.id, p.url)
        }
        if etaitVide || apercuSource == nil {
            selectionnerPremiere(reinitialiserReference: etaitVide || largeurReference == 0)
        }
    }

    func chargerMiniature(_ id: UUID, _ url: URL) {
        DispatchQueue.global(qos: .utility).async {
            var miniature: NSImage? = nil
            var dims = ""
            if let t = ImageTools.pixelSize(of: url) {
                dims = "\(t.width) × \(t.height)"
            }
            if let src = CGImageSourceCreateWithURL(url as CFURL, nil) {
                let opts: [CFString: Any] = [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceThumbnailMaxPixelSize: 132
                ]
                if let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) {
                    miniature = NSImage(cgImage: cg, size: NSSize(width: cg.width, height: cg.height))
                }
            }
            DispatchQueue.main.async {
                self.modifier(id) { photo in
                    photo.miniature = miniature
                    photo.dimensions = dims
                }
            }
        }
    }

    func modifier(_ id: UUID, _ f: (inout Photo) -> Void) {
        if let i = items.firstIndex(where: { $0.id == id }) {
            f(&items[i])
        }
    }

    func retirer(_ id: UUID) {
        if enCours { return }
        items.removeAll { $0.id == id }
        if items.isEmpty {
            bilan = nil
            effacerApercu()
        } else if selectionID == id {
            selectionnerPremiere(reinitialiserReference: false)
        }
    }

    func vider() {
        if enCours { return }
        items = []
        bilan = nil
        messageErreur = nil
        effacerApercu()
    }

    func afficherDansFinder() {
        guard let b = bilan, !b.sorties.isEmpty else { return }
        NSWorkspace.shared.activateFileViewerSelecting(b.sorties)
    }

    // MARK: Aperçu

    /// Affiche une autre photo de la liste dans l'aperçu.
    func selectionner(_ id: UUID) {
        guard let photo = items.first(where: { $0.id == id }) else { return }
        guard let petite = ImageTools.decode(url: photo.url, maxPixel: 1600) else {
            messageErreur = "« \(photo.url.lastPathComponent) » n’a pas pu être ouverte pour l’aperçu."
            return
        }
        messageErreur = nil
        selectionID = id
        apercuSource = petite
        rafraichirApercu()
    }

    /// Affiche la première photo lisible de la liste. Si `reinitialiserReference` est vrai,
    /// cette photo sert aussi de référence pour l'épaisseur des lignes : la dernière
    /// épaisseur utilisée, en proportion de la largeur (4 px pour 1920 px la première fois).
    private func selectionnerPremiere(reinitialiserReference: Bool) {
        for p in items {
            guard let taille = ImageTools.pixelSize(of: p.url),
                  let petite = ImageTools.decode(url: p.url, maxPixel: 1600) else { continue }
            selectionID = p.id
            apercuSource = petite
            if reinitialiserReference {
                largeurReference = taille.width
                let defaut = max(1, (Double(taille.width) * epaisseurRelative).rounded())
                thicknessMax = max(40, defaut * 3)
                miseAJourAuto = true
                thickness = defaut
                miseAJourAuto = false
            }
            rafraichirApercu()
            return
        }
        effacerApercu()
    }

    private func effacerApercu() {
        selectionID = nil
        apercuSource = nil
        apercu = nil
        largeurReference = 0
    }

    private func rafraichirApercu() {
        guard let src = apercuSource, largeurReference > 0 else {
            apercu = nil
            return
        }
        if !gridEnabled {
            apercu = NSImage(cgImage: src, size: NSSize(width: src.width, height: src.height))
            return
        }
        if let cg = ImageTools.render(source: src,
                                      referenceWidth: largeurReference,
                                      settings: reglagesGrille,
                                      forJPEG: false,
                                      pixelAligned: false) {
            apercu = NSImage(cgImage: cg, size: NSSize(width: cg.width, height: cg.height))
        }
    }

    // MARK: Traitement

    func reglages() -> ReglagesImage {
        let cible: CibleImage
        if compressionActive {
            switch dimension {
            case .origine: cible = .aucune
            case .pourcent(let p): cible = .pourcent(p)
            case .cote(let c): cible = .cote(c)
            case .pourcentPerso: cible = .pourcent(min(99, max(1, valeurPct)))
            case .cotePerso: cible = .cote(min(20000, max(16, valeurPx)))
            case .boite(let h):
                let (bl, bh) = dimensionsBoite(h)
                cible = .boite(bl, bh)
            }
        } else {
            cible = .aucune
        }
        var dossier: URL? = nil
        if destination == .autre { dossier = dossierAutre }
        return ReglagesImage(grille: gridEnabled ? reglagesGrille : nil,
                        largeurReference: largeurReference,
                        compresser: compressionActive,
                        qualite: qualite,
                        cible: cible,
                        format: format,
                        dossierFixe: dossier,
                        garderMeta: garderMeta,
                        letterbox: letterbox,
                        bandesBlanches: bandesBlanches)
    }

    // Boutons rapides (comme pour les vidéos) : 0 = origine, sinon hauteur de la boîte 16:9
    var presetDimension: Binding<Int> {
        return Binding<Int>(
            get: {
                switch self.dimension {
                case .origine: return 0
                case .boite(let h): return h
                default: return -1
                }
            },
            set: { choix in
                self.dimension = (choix == 0) ? .origine : .boite(choix)
            }
        )
    }

    func lancer() {
        if enCours || items.isEmpty { return }
        if !gridEnabled && !compressionActive { return }
        sauverReglages()
        let r = reglages()
        let liste: [(UUID, URL, Int64)] = items.map { ($0.id, $0.url, $0.taille) }
        let jeton = Jeton()
        self.jeton = jeton
        annulationDemandee = false
        enCours = true
        bilan = nil
        messageErreur = nil
        progres = 0
        for i in items.indices { items[i].etat = .attente }

        DispatchQueue.global(qos: .userInitiated).async {
            let verrouNoms = NSLock()
            let verrouRes = NSLock()
            var res = BilanImage()
            res.nbTotal = liste.count
            res.avecCompression = r.compresser
            var sortiesParIndex: [Int: URL] = [:]

            DispatchQueue.concurrentPerform(iterations: liste.count) { i in
                let id = liste[i].0
                let url = liste[i].1
                let tailleAvant = liste[i].2
                if jeton.estAnnule {
                    verrouRes.lock()
                    res.nbIgnorees += 1
                    verrouRes.unlock()
                    DispatchQueue.main.async {
                        self.modifier(id) { photo in photo.etat = .attente }
                    }
                    return
                }
                DispatchQueue.main.async {
                    self.modifier(id) { photo in photo.etat = .enCours }
                }
                do {
                    let resultat = try CompresseurImage.traiter(url, r, verrou: verrouNoms)
                    let sortie = resultat.0
                    let tailleApres = resultat.1
                    verrouRes.lock()
                    res.nbOk += 1
                    res.avant += tailleAvant
                    res.apres += tailleApres
                    if tailleApres > tailleAvant { res.nbPlusLourd += 1 }
                    sortiesParIndex[i] = sortie
                    verrouRes.unlock()
                    DispatchQueue.main.async {
                        self.modifier(id) { photo in photo.sortie = sortie; photo.etat = .termine(tailleApres) }
                        self.progres += 1
                    }
                } catch {
                    let message = (error as? ErreurImage)?.message ?? "Échec"
                    verrouRes.lock()
                    res.nbEchecs += 1
                    verrouRes.unlock()
                    DispatchQueue.main.async {
                        self.modifier(id) { photo in photo.etat = .erreur(message) }
                        self.progres += 1
                    }
                }
            }

            res.annule = res.nbIgnorees > 0
            res.sorties = sortiesParIndex.keys.sorted().compactMap { sortiesParIndex[$0] }
            DispatchQueue.main.async {
                self.bilan = res
                self.enCours = false
                self.annulationDemandee = false
                self.jeton = nil
            }
        }
    }

    /// Arrête le traitement : les photos en cours se terminent, les suivantes sont ignorées.
    /// Les fichiers déjà créés sont conservés.
    func annulerTraitement() {
        guard enCours else { return }
        annulationDemandee = true
        jeton?.annuler()
    }
}

// MARK: - Vues

struct LigneImageView: View {
    let photo: Photo
    let selectionne: Bool
    let afficherVariation: Bool
    let peutRetirer: Bool
    let retirer: () -> Void

    func variationTexte(_ t: Int64) -> String {
        let avant = Double(max(photo.taille, 1))
        let delta = Int(((Double(t) - avant) / avant * 100.0).rounded())
        if delta <= 0 { return "−\(abs(delta)) %" }
        return "+\(delta) %"
    }

    func variationCouleur(_ t: Int64) -> Color {
        return t > photo.taille ? Color.orange : Color.green
    }

    var detail: String {
        var morceaux: [String] = []
        if !photo.dimensions.isEmpty { morceaux.append(photo.dimensions) }
        morceaux.append(formaterTailleImage(photo.taille))
        return morceaux.joined(separator: " · ")
    }

    @ViewBuilder var statut: some View {
        switch photo.etat {
        case .attente:
            EmptyView()
        case .enCours:
            ProgressView().controlSize(.small)
        case .termine(let t):
            HStack(spacing: 10) {
                BoutonDossierSortie(url: photo.sortie)
                VStack(alignment: .trailing, spacing: 2) {
                    Text(formaterTailleImage(t)).font(.callout)
                    if afficherVariation {
                        Text(variationTexte(t)).font(.caption).foregroundColor(variationCouleur(t))
                    }
                }
            }
        case .erreur(let message):
            Text(message).font(.caption).foregroundColor(.red).lineLimit(1)
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            Group {
                if let img = photo.miniature {
                    Image(nsImage: img).resizable().scaledToFill()
                } else {
                    Rectangle().fill(Color.secondary.opacity(0.15))
                }
            }
            .frame(width: 44, height: 44)
            .clipped()
            .cornerRadius(6)

            VStack(alignment: .leading, spacing: 2) {
                Text(photo.url.lastPathComponent).lineLimit(1).truncationMode(.middle)
                Text(detail).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            statut
            if peutRetirer {
                Button(action: retirer) {
                    Image(systemName: "xmark.circle.fill")
                }
                .buttonStyle(.plain)
                .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(selectionne ? Color.accentColor.opacity(0.12) : Color.clear)
    }
}

struct VueImage: View {
    @ObservedObject var m = ModeleImage.partage
    @State private var survol = false

    var body: some View {
        HStack(spacing: 0) {
            zoneGauche
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            Divider()
            panneau
                .frame(width: 330)
                .background(Color(NSColor.controlBackgroundColor))
        }
        .frame(minWidth: 900, idealWidth: 1040, minHeight: 640, idealHeight: 720)
        .onDrop(of: [UTType.fileURL], isTargeted: $survol) { providers in
            m.deposer(providers)
            return true
        }
    }

    // MARK: Zone de gauche (aperçu + liste)

    var zoneGauche: some View {
        VStack(spacing: 0) {
            apercuVue
            if !m.items.isEmpty {
                Divider()
                liste
            }
        }
    }

    var apercuVue: some View {
        ZStack {
            Color(nsColor: .underPageBackgroundColor)

            if let image = m.apercu {
                Image(nsImage: image)
                    .resizable()
                    .interpolation(.high)
                    .aspectRatio(contentMode: .fit)
                    .padding(16)
            } else if m.items.isEmpty {
                vide
            } else {
                Text("Aperçu indisponible")
                    .foregroundColor(.secondary)
            }

            if survol {
                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(Color.accentColor.opacity(0.08))
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(Color.accentColor, style: StrokeStyle(lineWidth: 2, dash: [8, 6]))
                }
                .padding(14)
                .allowsHitTesting(false)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    var vide: some View {
        VStack(spacing: 10) {
            Image(systemName: "photo.on.rectangle.angled")
                .font(.system(size: 54))
                .foregroundColor(.secondary)
            Text("Glissez des photos ou un dossier ici")
                .font(.title3)
            Text("ou cliquez sur « Choisir des photos… »")
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture { m.choisir() }
    }

    var titreListe: String {
        let n = m.items.count
        return "\(n) photo\(n > 1 ? "s" : "") · \(formaterTailleImage(m.tailleTotale))"
    }

    var liste: some View {
        VStack(spacing: 0) {
            HStack {
                Text(titreListe)
                    .font(.headline)
                Spacer()
                Button("Vider la liste") { m.vider() }
                    .disabled(m.enCours)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            Divider()
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(m.items) { p in
                        VStack(spacing: 0) {
                            LigneImageView(photo: p,
                                      selectionne: p.id == m.selectionID,
                                      afficherVariation: m.compressionActive,
                                      peutRetirer: !m.enCours,
                                      retirer: { m.retirer(p.id) })
                                .contentShape(Rectangle())
                                .onTapGesture { m.selectionner(p.id) }
                            Divider().padding(.leading, 72)
                        }
                    }
                }
            }
            .frame(height: CGFloat(min(m.items.count, 4)) * 61)
        }
    }

    // MARK: Panneau de réglages

    func bloc<Contenu: View>(_ titre: String, _ valeur: String? = nil, @ViewBuilder _ contenu: () -> Contenu) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(titre).fontWeight(.medium)
                Spacer()
                if let v = valeur {
                    Text(v).foregroundColor(.secondary)
                }
            }
            contenu()
        }
    }

    func curseur(_ titre: String,
                 value: Binding<Double>,
                 range: ClosedRange<Double>,
                 display: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(titre)
                Spacer()
                Text(display).foregroundColor(.secondary)
            }
            Slider(value: value, in: range, step: 1)
        }
    }

    func choixDestination(_ titre: String, actif: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 6) {
                Image(systemName: actif ? "largecircle.fill.circle" : "circle")
                    .foregroundColor(actif ? Color.accentColor : Color.secondary)
                Text(titre)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    var panneau: some View {
        VStack(spacing: 0) {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    if let p = m.selection {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(p.url.lastPathComponent)
                                .font(.caption)
                                .lineLimit(1)
                                .truncationMode(.middle)
                            Text(p.dimensions.isEmpty ? formaterTailleImage(p.taille) : "\(p.dimensions) px · \(formaterTailleImage(p.taille))")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }

                    Divider()
                    sectionCompression

                    Divider()
                    sectionGrille

                    Divider()
                    sectionSortie
                }
                .padding(20)
                .disabled(m.enCours)
            }

            Divider()
            pied
                .padding(20)
        }
    }

    var sectionGrille: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: $m.gridEnabled) {
                Text("Ajouter une grille").fontWeight(.medium)
            }

            if m.gridEnabled {
                curseur("Colonnes", value: $m.columns, range: 1...60,
                        display: "\(Int(m.columns.rounded()))")
                curseur("Rangées", value: $m.rows, range: 1...60,
                        display: "\(Int(m.rows.rounded()))")
                curseur("Épaisseur", value: $m.thickness, range: 1...m.thicknessMax,
                        display: "\(Int(m.thickness.rounded())) px")
                curseur("Opacité", value: $m.opacityPercent, range: 0...100,
                        display: "\(Int(m.opacityPercent.rounded())) %")

                HStack(spacing: 8) {
                    Text("Couleur")
                    Spacer()
                    Button("Blanc") { m.couleurGrille = Color.white }
                    Button("Noir") { m.couleurGrille = Color.black }
                    ColorPicker("", selection: $m.couleurGrille, supportsOpacity: false)
                        .labelsHidden()
                }

                Toggle("Bordure extérieure", isOn: $m.outerBorder)
                Toggle("Doubler la grille (2 grilles décalées)", isOn: $m.doubled)

                if m.doubled {
                    curseur("Décalage horizontal", value: $m.offsetXPercent, range: 0...100,
                            display: "\(Int(m.offsetXPercent.rounded())) %")
                    curseur("Décalage vertical", value: $m.offsetYPercent, range: 0...100,
                            display: "\(Int(m.offsetYPercent.rounded())) %")
                }
            }
        }
    }

    var sectionCompression: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: $m.compressionActive) {
                Text("Compresser").fontWeight(.medium)
            }

            if m.compressionActive {
                bloc("Qualité conservée", "\(Int(m.qualite)) %") {
                    Slider(value: $m.qualite, in: 1...100, step: 1)
                    Text("\(m.aideQualite) · plus le % est bas, plus le fichier est léger.")
                        .font(.caption).foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    if m.format == .png {
                        Text("Le PNG n’a pas de réglage de qualité : choisissez JPEG ou HEIC plus bas pour alléger les fichiers.")
                            .font(.caption).foregroundColor(.orange)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                bloc("Dimensions") {
                    Picker("", selection: m.presetDimension) {
                        Text("Origine").tag(0)
                        Text("4K").tag(2160)
                        Text("1080p").tag(1080)
                        Text("720p").tag(720)
                        Text("480p").tag(480)
                    }
                    .labelsHidden()
                    .pickerStyle(.segmented)
                    .help("Raccourcis : 4K = 3840 × 2160, 1080p = 1920 × 1080, 720p = 1280 × 720, 480p = 854 × 480. L’image garde ses proportions et n’est jamais agrandie ; en portrait, la boîte est pivotée.")

                    if case .boite = m.dimension {
                        Toggle("Letterbox (bandes pour obtenir le format exact)", isOn: $m.letterbox)
                            .help("Si l’image n’a pas le même format que la boîte (16:9), elle est centrée sur un fond de la taille exacte de la boîte, par exemple 1920 × 1080, avec des bandes sur les côtés ou en haut et en bas.")
                        if m.letterbox {
                            HStack {
                                Text("Couleur des bandes")
                                Picker("", selection: $m.bandesBlanches) {
                                    Text("Noir").tag(false)
                                    Text("Blanc").tag(true)
                                }
                                .labelsHidden()
                                .pickerStyle(.segmented)
                                .frame(width: 140)
                            }
                        }
                    }

                    Picker("", selection: $m.dimension) {
                        Text("Dimensions d’origine").tag(DimensionImage.origine)
                        Text("4K : boîte 3840 × 2160").tag(DimensionImage.boite(2160))
                        Text("1080p : boîte 1920 × 1080").tag(DimensionImage.boite(1080))
                        Text("720p : boîte 1280 × 720").tag(DimensionImage.boite(720))
                        Text("480p : boîte 854 × 480").tag(DimensionImage.boite(480))
                        Text("75 % des dimensions").tag(DimensionImage.pourcent(75))
                        Text("50 % des dimensions").tag(DimensionImage.pourcent(50))
                        Text("25 % des dimensions").tag(DimensionImage.pourcent(25))
                        Text("Plus grand côté : 3840 px (4K)").tag(DimensionImage.cote(3840))
                        Text("Plus grand côté : 2560 px").tag(DimensionImage.cote(2560))
                        Text("Plus grand côté : 1920 px (Full HD)").tag(DimensionImage.cote(1920))
                        Text("Plus grand côté : 1600 px").tag(DimensionImage.cote(1600))
                        Text("Plus grand côté : 1280 px").tag(DimensionImage.cote(1280))
                        Text("Plus grand côté : 1024 px").tag(DimensionImage.cote(1024))
                        Text("Plus grand côté : 800 px").tag(DimensionImage.cote(800))
                        Text("Pourcentage personnalisé…").tag(DimensionImage.pourcentPerso)
                        Text("Taille en pixels personnalisée…").tag(DimensionImage.cotePerso)
                    }
                    .labelsHidden()
                    .pickerStyle(.menu)

                    if m.dimension == .pourcentPerso {
                        HStack {
                            TextField("", value: $m.valeurPct, formatter: formateurEntierImage)
                                .frame(width: 70)
                            Text("% des dimensions (1 à 99)")
                                .font(.caption).foregroundColor(.secondary)
                        }
                    } else if m.dimension == .cotePerso {
                        HStack {
                            TextField("", value: $m.valeurPx, formatter: formateurEntierImage)
                                .frame(width: 70)
                            Text("px, plus grand côté")
                                .font(.caption).foregroundColor(.secondary)
                        }
                    }
                    Text("Les petites images ne sont jamais agrandies (avec letterbox, elles sont seulement centrées sur le fond). La grille est dessinée après le redimensionnement, avec les mêmes proportions.")
                        .font(.caption).foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            } else {
                Text("Désactivé : dimensions d’origine, et qualité de 95 % pour le JPEG et le HEIC.")
                    .font(.caption).foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    var sectionSortie: some View {
        VStack(alignment: .leading, spacing: 16) {
            bloc("Format") {
                Picker("", selection: $m.format) {
                    ForEach(FormatSortie.allCases) { f in
                        Text(f.titre).tag(f)
                    }
                }
                .labelsHidden()
                .pickerStyle(.segmented)
                Text(m.format.aide)
                    .font(.caption).foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            bloc("Enregistrer dans") {
                choixDestination("Dossier « \(nomDossierSortieImage) » à côté des originales", actif: m.destination == .cote) {
                    m.destination = .cote
                }
                choixDestination("Un autre dossier", actif: m.destination == .autre) {
                    m.selectionnerAutreDossier()
                }
                if m.destination == .autre, let d = m.dossierAutre {
                    HStack {
                        Image(systemName: "folder").foregroundColor(.secondary)
                        Text(d.lastPathComponent).lineLimit(1).truncationMode(.middle)
                        Spacer()
                        Button("Changer…") { m.choisirDossierDestination() }
                    }
                    .font(.callout)
                    .padding(.leading, 20)
                }
                Text("Les originales ne sont jamais modifiées. Avec la grille, les fichiers sont nommés « nom_grille ».")
                    .font(.caption).foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            VStack(alignment: .leading, spacing: 4) {
                Toggle("Conserver les métadonnées", isOn: $m.garderMeta)
                Text("Date, appareil, position GPS… Décochez pour les supprimer.")
                    .font(.caption).foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    // MARK: Pied : bouton, progression, bilan

    var texteBouton: String {
        let n = m.items.count
        if n == 0 { return "Exporter" }
        return "Exporter \(n) photo\(n > 1 ? "s" : "")"
    }

    var pied: some View {
        VStack(alignment: .leading, spacing: 10) {
            if m.enCours {
                ProgressView(value: Double(m.progres), total: Double(max(m.items.count, 1)))
                Text("Traitement… \(m.progres) / \(m.items.count)")
                    .font(.caption).foregroundColor(.secondary)
            } else if let b = m.bilan {
                bilanVue(b)
            }

            if let e = m.messageErreur {
                Text(e)
                    .font(.caption).foregroundColor(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if !m.gridEnabled && !m.compressionActive {
                Text("Activez la grille et/ou la compression pour exporter.")
                    .font(.caption).foregroundColor(.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if m.enCours {
                Button(action: { m.annulerTraitement() }) {
                    Text(m.annulationDemandee ? "Annulation en cours…" : "Annuler")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.large)
                .keyboardShortcut(.cancelAction)
                .disabled(m.annulationDemandee)
            } else {
                Button(action: { m.lancer() }) {
                    Text(texteBouton)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .keyboardShortcut(.defaultAction)
                .disabled(m.items.isEmpty || (!m.gridEnabled && !m.compressionActive))
            }
        }
    }

    func texteGain(_ b: BilanImage) -> String {
        let gain = Int((100.0 * Double(b.avant - b.apres) / Double(max(b.avant, 1))).rounded())
        let signe = gain >= 0 ? "−" : "+"
        return "\(formaterTailleImage(b.avant)) → \(formaterTailleImage(b.apres))  (\(signe)\(abs(gain)) %)"
    }

    func bilanVue(_ b: BilanImage) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("\(b.annule ? "Annulé" : "Terminé") : \(b.nbOk) photo\(b.nbOk > 1 ? "s" : "") sur \(b.nbTotal)")
                .fontWeight(.medium)
            if b.annule {
                Text("Les fichiers déjà créés sont conservés.")
                    .font(.caption).foregroundColor(.secondary)
            }
            if b.avecCompression && b.nbOk > 0 && b.avant > 0 {
                Text(texteGain(b))
                    .foregroundColor(.green)
            }
            if b.avecCompression && b.nbPlusLourd > 0 {
                Text("\(b.nbPlusLourd) photo(s) plus lourde(s) qu’avant (déjà très compressées) : gardez l’original.")
                    .font(.caption).foregroundColor(.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if b.nbEchecs > 0 {
                Text("\(b.nbEchecs) échec(s), voir la liste.")
                    .font(.caption).foregroundColor(.red)
            }
            if !b.sorties.isEmpty {
                Button("Afficher dans le Finder") { m.afficherDansFinder() }
                    .padding(.top, 2)
            }
        }
    }
}
