import SwiftUI
import AppKit

/// Calque transparent au-dessus de la vidéo :
/// - un clic (glisser) déplace la fenêtre — il ne met PAS en pause ;
/// - un double-clic bascule le plein écran ;
/// - la molette (ou le défilement à deux doigts, haut/bas) règle le volume ;
/// - deux doigts vers la gauche / droite : recul / avance dans la vidéo.
struct VideoInteractionLayer: NSViewRepresentable {
    var onDoubleClick: () -> Void
    var onScroll: (_ deltaY: CGFloat, _ precise: Bool, _ inverted: Bool) -> Void
    var onHorizontalScroll: (_ deltaX: CGFloat, _ precise: Bool, _ inverted: Bool) -> Void

    func makeNSView(context: Context) -> InteractionView {
        let view = InteractionView()
        view.onDoubleClick = onDoubleClick
        view.onScroll = onScroll
        view.onHorizontalScroll = onHorizontalScroll
        return view
    }

    func updateNSView(_ view: InteractionView, context: Context) {
        view.onDoubleClick = onDoubleClick
        view.onScroll = onScroll
        view.onHorizontalScroll = onHorizontalScroll
    }

    final class InteractionView: NSView {
        var onDoubleClick: (() -> Void)?
        var onScroll: ((CGFloat, Bool, Bool) -> Void)?
        var onHorizontalScroll: ((CGFloat, Bool, Bool) -> Void)?

        override var mouseDownCanMoveWindow: Bool { true }
        override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

        override func mouseDown(with event: NSEvent) {
            if event.clickCount >= 2 {
                onDoubleClick?()
            } else {
                window?.performDrag(with: event)
            }
        }

        override func scrollWheel(with event: NSEvent) {
            let deltaX = event.scrollingDeltaX
            let deltaY = event.scrollingDeltaY
            let precise = event.hasPreciseScrollingDeltas
            let inverted = event.isDirectionInvertedFromDevice

            if abs(deltaX) > abs(deltaY) {
                // Geste horizontal : on ignore l'inertie après le relâchement pour ne pas dépasser.
                guard event.momentumPhase.isEmpty else { return }
                onHorizontalScroll?(deltaX, precise, inverted)
            } else if deltaY != 0 {
                onScroll?(deltaY, precise, inverted)
            }
        }
    }
}
