import SwiftUI
import AppKit

/// Au lancement, la fenêtre s'ouvre toujours en format compact (et non à la taille de la session précédente).
struct WindowConfigurator: NSViewRepresentable {
    static let compactSize = NSSize(width: 668, height: 314)

    func makeNSView(context: Context) -> NSView { ConfiguratorView() }
    func updateNSView(_ nsView: NSView, context: Context) {}

    private final class ConfiguratorView: NSView {
        private var done = false

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            guard !done, let window = window else { return }
            done = true
            window.isRestorable = false
            // SwiftUI applique parfois une taille mémorisée juste après : on repasse donc après coup.
            for delay in [0.0, 0.15] {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    window.setContentSize(WindowConfigurator.compactSize)
                    window.center()
                }
            }
        }
    }
}
