import AppKit
import SwiftUI
import Combine
import UniformTypeIdentifiers
import VLCKit

struct MediaTrack: Identifiable, Hashable {
    let id: Int32        // index VLC (-1 = désactivé)
    let name: String
}

/// Format d'image proposé à l'utilisateur (ratio d'affichage).
struct AspectOption: Identifiable, Hashable {
    let id: String
    let label: String
    let value: String?          // nil = format d'origine de la vidéo

    var ratio: Double? {
        guard let value else { return nil }
        let parts = value.split(separator: ":").compactMap { Double($0) }
        guard parts.count == 2, parts[1] > 0 else { return nil }
        return parts[0] / parts[1]
    }
}

enum SupportedFormats {
    /// Conteneurs et flux bruts lisibles par libVLC.
    /// .h264 / .h265 sont des flux « bruts » (sans conteneur).
    static let videoExtensions = [
        "mp4", "m4v", "mov", "mkv", "avi",
        "h264", "264", "h265", "265", "hevc",
        "webm", "ts", "mpg", "mpeg", "wmv", "flv"
    ]
    static let subtitleExtensions = ["srt", "ass", "ssa", "sub", "vtt"]
}

/// Pilote le lecteur VLC et expose l'état à l'interface SwiftUI.
final class PlayerModel: NSObject, ObservableObject, VLCMediaPlayerDelegate {

    let player = VLCMediaPlayer()

    // MARK: Playlist
    @Published private(set) var playlist: [URL] = []
    @Published private(set) var currentIndex: Int?

    // MARK: État de lecture
    @Published private(set) var isPlaying = false
    @Published var position: Double = 0                 // 0...1
    @Published private(set) var elapsedText = "0:00"
    @Published private(set) var totalText = "0:00"
    @Published var isScrubbing = false
    @Published private(set) var errorMessage: String?

    // MARK: Réglages
    @Published var volume: Double = 80 {                // 0...100
        didSet {
            if isMuted { isMuted = false }
            applyVolume()
        }
    }
    @Published private(set) var isMuted = false
    @Published private(set) var rate: Float = 1.0
    @Published private(set) var audioTracks: [MediaTrack] = []
    @Published private(set) var subtitleTracks: [MediaTrack] = []
    @Published private(set) var selectedAudioTrack: Int32 = -1
    @Published private(set) var selectedSubtitleTrack: Int32 = -1
    @Published var showPlaylist = false { didSet { updateWindowAspectLock() } }
    @Published var playlistWidth: CGFloat = 280          // largeur réglable à la poignée

    func togglePlaylist() {
        if showPlaylist {
            showPlaylist = false
        } else {
            if playlistWidth < 200 { playlistWidth = 280 }
            showPlaylist = true
        }
        snapAfterPlaylistChange()
    }

    // MARK: Format / dimensions de l'image
    static let aspectOptions: [AspectOption] = [
        AspectOption(id: "auto", label: "Automatique (format d’origine)", value: nil),
        AspectOption(id: "16:9", label: "16:9", value: "16:9"),
        AspectOption(id: "4:3", label: "4:3", value: "4:3"),
        AspectOption(id: "16:10", label: "16:10", value: "16:10"),
        AspectOption(id: "21:9", label: "21:9 (ultra-large)", value: "21:9"),
        AspectOption(id: "2.35:1", label: "2,35:1 (cinémascope)", value: "235:100"),
        AspectOption(id: "5:4", label: "5:4", value: "5:4"),
        AspectOption(id: "1:1", label: "1:1 (carré)", value: "1:1")
    ]
    @Published private(set) var aspectID = "auto"
    @Published private(set) var fillWindow = false       // remplit la fenêtre en rognant
    @Published private(set) var originalSize = false     // 100 % (sinon : adapté à la fenêtre)

    // MARK: Bulle d'information (volume, format, piste…)
    @Published private(set) var hudText: String?
    private var hudTask: Task<Void, Never>?
    private var lastTrackRefresh = Date.distantPast
    private var lastAspectUnlock = Date.distantPast
    private var needsAutoFit = false          // une nouvelle vidéo vient d'être lancée : adapter la fenêtre
    private var hasAutoFitted = false         // la fenêtre a déjà été dimensionnée une première fois

    // MARK: Déformation libre de l'image (format avancé)
    @Published var stretchX: Double = 1.0 { didSet { updateWindowAspectLock() } }          // largeur  : 0,5 ... 2,0
    @Published var stretchY: Double = 1.0 { didSet { updateWindowAspectLock() } }          // hauteur  : 0,5 ... 2,0
    @Published var advancedFormatOpen = false
    var isStretched: Bool { abs(stretchX - 1) > 0.001 || abs(stretchY - 1) > 0.001 }

    func resetStretch() {
        stretchX = 1
        stretchY = 1
        showHUD("Déformation réinitialisée")
    }

    // MARK: Fenêtre : le cadre suit le format de la vidéo (comme VLC), sans bandes noires

    private var mainWindow: NSWindow? {
        NSApp.windows.first { $0.isVisible && $0.canBecomeMain }
    }

    /// Format d'affichage actuel de la vidéo (format forcé et déformation inclus).
    private func displayRatio() -> CGFloat? {
        let native = player.videoSize
        guard currentIndex != nil, native.width > 0, native.height > 0 else { return nil }
        var ratio = native.width / native.height
        if let forced = Self.aspectOptions.first(where: { $0.id == aspectID })?.ratio {
            ratio = CGFloat(forced)
        }
        ratio *= CGFloat(stretchX / max(stretchY, 0.01))
        return ratio
    }

    /// Hauteur de la barre de titre qui recouvre le haut du contenu (la zone vidéo visible commence en dessous).
    /// C'est elle qui faussait le format : la fenêtre entière avait le format de la vidéo, mais pas la zone visible,
    /// d'où les bandes noires sur les côtés. En PiP (pas de barre de titre), elle vaut 0.
    private func titlebarInset(_ window: NSWindow) -> CGFloat {
        guard !pipMode else { return 0 }
        let full = window.contentRect(forFrameRect: window.frame).height
        return max(0, full - window.contentLayoutRect.height)
    }

    /// Playlist masquée : la fenêtre garde le format de la vidéo quand on tire sur un coin.
    /// Playlist visible : le recalage se fait au relâchement (voir snapWindowToVideo).
    /// Le verrou vise la zone vidéo visible (barre de titre exclue) : il est réajusté à chaque changement de taille.
    func updateWindowAspectLock() {
        guard let window = mainWindow, !window.styleMask.contains(.fullScreen) else { return }
        if let ratio = displayRatio(), !showPlaylist {
            let width = max(window.contentRect(forFrameRect: window.frame).width, 1)
            let height = width / ratio + titlebarInset(window)
            window.contentAspectRatio = NSSize(width: width, height: height)
        } else {
            // Retire le verrou (réinitialiser les incréments annule le ratio imposé).
            window.resizeIncrements = NSSize(width: 1, height: 1)
            window.contentResizeIncrements = NSSize(width: 1, height: 1)
        }
    }

    // MARK: Réduction par un coin : fenêtre normale -> Picture in Picture (et inversement)

    /// Largeur minimale de la fenêtre normale (playlist masquée).
    static let normalMinWidth: CGFloat = 660
    /// En dessous de cette largeur, au relâchement de la souris, la fenêtre passe en Picture in Picture.
    /// Au-dessus, un PiP agrandi à la souris repasse en fenêtre normale.
    static let pipThresholdWidth: CGFloat = 520
    private var frameBeforeResize: NSRect?

    private func handleEndOfLiveResize(_ window: NSWindow) {
        guard window === mainWindow, !window.styleMask.contains(.fullScreen) else {
            snapWindowToVideo(window)
            return
        }
        let width = window.contentRect(forFrameRect: window.frame).width
        if !pipMode {
            if !showPlaylist && width < Self.pipThresholdWidth {
                enterPiP(fromDrag: true)
                return
            }
            if !showPlaylist && width < Self.normalMinWidth {
                // Entre les deux : on revient à la taille minimale de la fenêtre normale.
                var size = window.contentRect(forFrameRect: window.frame).size
                size.width = Self.normalMinWidth
                window.setContentSize(size)
            }
        } else if width >= Self.pipThresholdWidth {
            exitPiP(fromDrag: true)
            return
        }
        snapWindowToVideo(window)
    }

    /// Après affichage / masquage de la playlist : recale le cadre sur le format de la vidéo.
    func snapAfterPlaylistChange() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            guard let self, let window = self.mainWindow else { return }
            self.updateWindowAspectLock()
            self.snapWindowToVideo(window)
        }
    }

    /// Après un redimensionnement à la souris : ajuste la hauteur pour que la zone vidéo
    /// ait exactement le format de la vidéo (pas de bandes noires).
    func snapWindowToVideo(_ window: NSWindow) {
        guard !window.styleMask.contains(.fullScreen), let ratio = displayRatio() else { return }
        let content = window.contentRect(forFrameRect: window.frame).size
        let inset = titlebarInset(window)
        let extra: CGFloat = showPlaylist ? playlistWidth + 1 : 0
        var videoWidth = max(content.width - extra, 200)
        var height = videoWidth / ratio
        let maxHeight = (window.screen ?? NSScreen.main)?.visibleFrame.height ?? 900
        if height > maxHeight - 40 - inset {
            height = maxHeight - 40 - inset
            videoWidth = height * ratio
        }
        let target = NSSize(width: videoWidth + extra, height: height + inset)
        if abs(target.width - content.width) > 1 || abs(target.height - content.height) > 1 {
            window.setContentSize(target)
        }
    }

    static let availableRates: [Float] = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]

    private var durationMs: Int32 = 0

    var windowTitle: String {
        guard let index = currentIndex, playlist.indices.contains(index) else { return "Lecteur Vidéo" }
        return playlist[index].lastPathComponent
    }

    override init() {
        super.init()
        player.delegate = self
        applyVolume()
        // Fin d'un redimensionnement à la souris : la zone vidéo reprend le format de la vidéo.
        NotificationCenter.default.addObserver(
            forName: NSWindow.didEndLiveResizeNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let window = notification.object as? NSWindow else { return }
            self?.handleEndOfLiveResize(window)
        }
        // Pendant un redimensionnement : le verrou de proportions suit la largeur courante (barre de titre comprise).
        NotificationCenter.default.addObserver(
            forName: NSWindow.didResizeNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self, !self.showPlaylist,
                  let window = notification.object as? NSWindow,
                  window === self.mainWindow else { return }
            self.updateWindowAspectLock()
        }
        // Début d'un redimensionnement à la souris : on mémorise le cadre pour pouvoir y revenir en quittant le PiP.
        NotificationCenter.default.addObserver(
            forName: NSWindow.willStartLiveResizeNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self, !self.pipMode,
                  let window = notification.object as? NSWindow,
                  window === self.mainWindow else { return }
            self.frameBeforeResize = window.frame
        }
        // En PiP, SwiftUI peut rétablir la barre de titre après un redimensionnement : on la re-masque aussitôt.
        NotificationCenter.default.addObserver(
            forName: NSWindow.didUpdateNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self, self.pipMode,
                  let window = notification.object as? NSWindow,
                  window === self.mainWindow else { return }
            let chromeRestored = !window.styleMask.contains(.fullSizeContentView)
                || !window.titlebarAppearsTransparent
                || window.titleVisibility != .hidden
                || window.standardWindowButton(.closeButton)?.isHidden == false
            if window.level != .floating { window.level = .floating }
            if chromeRestored {
                self.setWindowChromeHidden(true, for: window)
                self.fixSafeArea(for: window)
                self.updateWindowAspectLock()
                self.snapWindowToVideo(window)
            }
        }
    }

    // MARK: - Ouverture

    /// Remplace la playlist et lance la lecture du premier fichier.
    func replaceAndPlay(_ urls: [URL]) {
        let files = Self.collectVideos(from: urls)
        guard !files.isEmpty else { return }
        playlist = files
        play(at: 0)
    }

    /// Ajoute à la fin de la playlist (lance la lecture si rien ne joue encore).
    func append(_ urls: [URL]) {
        let files = Self.collectVideos(from: urls)
        guard !files.isEmpty else { return }
        let firstNewIndex = playlist.count
        playlist.append(contentsOf: files)
        if currentIndex == nil { play(at: firstNewIndex) }
    }

    /// Fichiers vidéo à partir de fichiers et/ou de dossiers (parcourus récursivement, triés par nom).
    static func collectVideos(from urls: [URL]) -> [URL] {
        let fileManager = FileManager.default
        var result: [URL] = []
        for url in urls where url.isFileURL {
            var isDirectory: ObjCBool = false
            guard fileManager.fileExists(atPath: url.path, isDirectory: &isDirectory) else { continue }
            if isDirectory.boolValue {
                guard let enumerator = fileManager.enumerator(
                    at: url,
                    includingPropertiesForKeys: nil,
                    options: [.skipsHiddenFiles, .skipsPackageDescendants]
                ) else { continue }
                var found: [URL] = []
                for case let file as URL in enumerator {
                    if SupportedFormats.videoExtensions.contains(file.pathExtension.lowercased()) {
                        found.append(file)
                    }
                }
                found.sort { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
                result += found
            } else if !SupportedFormats.subtitleExtensions.contains(url.pathExtension.lowercased()) {
                result.append(url)
            }
        }
        return result
    }

    /// Réorganise la playlist (glisser les lignes) en gardant la vidéo en cours.
    func movePlaylist(from source: IndexSet, to destination: Int) {
        var items = playlist.enumerated().map { (oldIndex: $0.offset, url: $0.element) }
        items.move(fromOffsets: source, toOffset: destination)
        playlist = items.map { $0.url }
        if let current = currentIndex {
            currentIndex = items.firstIndex(where: { $0.oldIndex == current })
        }
    }

    func play(at index: Int) {
        guard playlist.indices.contains(index) else { return }
        currentIndex = index
        errorMessage = nil
        position = 0
        durationMs = 0
        elapsedText = "0:00"
        totalText = "0:00"
        audioTracks = []
        subtitleTracks = []
        needsAutoFit = true
        player.media = VLCMedia(url: playlist[index])
        player.play()
        applyVolume()
    }

    func remove(at index: Int) {
        guard playlist.indices.contains(index) else { return }
        let removedCurrent = (index == currentIndex)
        playlist.remove(at: index)
        if playlist.isEmpty {
            clearPlaylist()
            return
        }
        guard let current = currentIndex else { return }
        if removedCurrent {
            play(at: min(index, playlist.count - 1))
        } else if index < current {
            currentIndex = current - 1
        }
    }

    func clearPlaylist() {
        stop()
        playlist = []
        currentIndex = nil
    }

    // MARK: - Commandes de lecture

    func togglePlayPause() {
        guard currentIndex != nil else {
            if playlist.isEmpty { presentOpenPanel() } else { play(at: 0) }
            return
        }
        if player.isPlaying { player.pause() } else { player.play() }
    }

    func stop() {
        player.stop()
        isPlaying = false
        position = 0
        elapsedText = "0:00"
    }

    func seek(to fraction: Double) {
        guard currentIndex != nil else { return }
        player.position = Float(min(max(fraction, 0), 1))
    }

    func skip(seconds: Int) {
        guard currentIndex != nil else { return }
        if seconds >= 0 {
            player.jumpForward(Int32(seconds))
        } else {
            player.jumpBackward(Int32(-seconds))
        }
    }

    func next() {
        guard let index = currentIndex, index + 1 < playlist.count else { return }
        play(at: index + 1)
    }

    func previous() {
        guard let index = currentIndex else { return }
        // Comme VLC : au-delà de 3 s, on revient au début du fichier courant.
        if index == 0 || player.time.intValue > 3000 {
            player.position = 0
        } else {
            play(at: index - 1)
        }
    }

    func setRate(_ value: Float) {
        rate = min(max(value, 0.25), 4.0)
        player.rate = rate
    }

    func adjustRate(by delta: Float) {
        setRate(rate + delta)
    }

    func changeVolume(by delta: Double) {
        volume = min(max(volume + delta, 0), 100)
    }

    func toggleMute() {
        isMuted.toggle()
        applyVolume()
    }

    func updateScrubPreview() {
        elapsedText = Self.format(ms: Int32(Double(durationMs) * position))
    }

    func toggleFullScreen() {
        if pipMode { exitPiP(); return }          // « agrandir » depuis le PiP = retour à la fenêtre normale
        (NSApp.keyWindow ?? NSApp.windows.first)?.toggleFullScreen(nil)
    }

    // MARK: - Picture in Picture (mini-fenêtre au-dessus de toutes les apps)

    @Published private(set) var pipMode = false
    private var savedFrame: NSRect?
    private var savedShowPlaylist = false

    func togglePiP() {
        if pipMode { exitPiP() } else { enterPiP() }
    }

    func enterPiP(fromDrag: Bool = false) {
        guard !pipMode, let window = mainWindow, !window.styleMask.contains(.fullScreen) else { return }
        let dragFrame = window.frame
        savedFrame = fromDrag ? (frameBeforeResize ?? dragFrame) : window.frame
        savedShowPlaylist = showPlaylist
        showPlaylist = false
        pipMode = true                                   // relâche la taille minimale de la fenêtre

        window.level = .floating                         // au-dessus des fenêtres des autres apps
        window.collectionBehavior.insert([.canJoinAllSpaces, .fullScreenAuxiliary])
        window.hidesOnDeactivate = false
        setWindowChromeHidden(true, for: window)         // plus de barre de titre ni de boutons rouge/jaune/vert

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { [weak self] in
            guard let self, self.pipMode else { return }
            if fromDrag {
                // Réduction à la souris : la fenêtre garde la taille et la position où on l'a lâchée.
                window.setFrame(dragFrame, display: true, animate: false)
                self.forceRelayout(window)
                self.updateWindowAspectLock()
                self.snapWindowToVideo(window)
                self.showHUD("Picture in Picture")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                    guard self.pipMode else { return }
                    self.forceRelayout(window)
                    self.snapWindowToVideo(window)
                }
                return
            }
            // Taille la plus compacte (240 × 135 au minimum), au format de la vidéo, dans le coin en haut à droite de l'écran.
            let ratio = self.displayRatio() ?? (16.0 / 9.0)
            var pipWidth: CGFloat = 240
            var pipHeight = pipWidth / ratio
            if pipHeight < 135 {
                pipHeight = 135
                pipWidth = pipHeight * ratio
            }
            let content = NSSize(width: pipWidth, height: pipHeight)
            var frame = window.frameRect(forContentRect: NSRect(origin: .zero, size: content))
            let visible = (window.screen ?? NSScreen.main)?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
            frame.origin = NSPoint(x: visible.maxX - frame.width - 20, y: visible.maxY - frame.height - 20)
            window.setFrame(frame, display: true, animate: true)
            self.forceRelayout(window)
            self.updateWindowAspectLock()
            self.snapWindowToVideo(window)
            self.showHUD("Picture in Picture")
        }
    }

    /// Force SwiftUI à recalculer la mise en page après un changement de barre de titre
    /// (sinon la vidéo peut rester décalée de la hauteur de l'ancienne barre et être rognée en bas).
    /// Le « coup de pouce » est réparti sur deux tours de boucle : dans le même tour, SwiftUI l'annulerait.
    private func forceRelayout(_ window: NSWindow) {
        let size = window.contentRect(forFrameRect: window.frame).size
        window.setContentSize(NSSize(width: size.width + 2, height: size.height + 2))
        window.contentView?.needsLayout = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) { [weak self, weak window] in
            guard let self, let window else { return }
            window.setContentSize(size)
            self.fixSafeArea(for: window)
            window.contentView?.needsLayout = true
            window.contentView?.layoutSubtreeIfNeeded()
            self.updateWindowAspectLock()
            self.snapWindowToVideo(window)
        }
    }

    /// En PiP, annule la marge de sécurité du haut (ancienne barre de titre) que SwiftUI peut conserver :
    /// c'est elle qui décale la vidéo vers le bas et rogne le bas de l'image. Hors PiP, remet tout à zéro.
    private func fixSafeArea(for window: NSWindow) {
        guard let view = window.contentView else { return }
        var extra = view.additionalSafeAreaInsets
        extra.top = 0
        view.additionalSafeAreaInsets = extra
        view.layoutSubtreeIfNeeded()
        let inset = view.safeAreaInsets.top
        if pipMode && inset > 0.5 {
            extra.top = -inset
            view.additionalSafeAreaInsets = extra
        }
        view.needsLayout = true
    }

    /// Masque (ou rétablit) la barre de titre : la vidéo occupe alors toute la fenêtre.
    private func setWindowChromeHidden(_ hidden: Bool, for window: NSWindow) {
        if hidden {
            window.styleMask.insert(.fullSizeContentView)
        } else {
            window.styleMask.remove(.fullSizeContentView)
        }
        window.titlebarAppearsTransparent = hidden
        window.titleVisibility = hidden ? .hidden : .visible
        for button in [NSWindow.ButtonType.closeButton, .miniaturizeButton, .zoomButton] {
            window.standardWindowButton(button)?.isHidden = hidden
        }
    }

    func exitPiP(fromDrag: Bool = false) {
        guard pipMode else { return }
        pipMode = false
        showPlaylist = fromDrag ? false : savedShowPlaylist
        guard let window = mainWindow else { return }
        let dragFrame = window.frame
        window.level = .normal
        window.collectionBehavior.remove([.canJoinAllSpaces, .fullScreenAuxiliary])
        setWindowChromeHidden(false, for: window)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { [weak self] in
            guard let self else { return }
            if fromDrag {
                // Agrandissement à la souris : on reste là où on est, à la taille minimale de la fenêtre normale.
                window.setFrame(dragFrame, display: true, animate: false)
                var size = window.contentRect(forFrameRect: window.frame).size
                size.width = max(size.width, Self.normalMinWidth)
                window.setContentSize(size)
                self.forceRelayout(window)
                self.updateWindowAspectLock()
                self.snapWindowToVideo(window)
                return
            }
            if let frame = self.savedFrame {
                window.setFrame(frame, display: true, animate: true)
            }
            self.forceRelayout(window)
            self.updateWindowAspectLock()
        }
    }

    // MARK: - Pistes audio / sous-titres

    func selectAudioTrack(_ id: Int32) {
        player.currentAudioTrackIndex = id
        selectedAudioTrack = id
    }

    func selectSubtitleTrack(_ id: Int32) {
        player.currentVideoSubTitleIndex = id
        selectedSubtitleTrack = id
    }

    func presentSubtitlePanel() {
        guard currentIndex != nil else { return }
        let panel = NSOpenPanel()
        panel.title = "Ajouter des sous-titres"
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.allowedContentTypes = SupportedFormats.subtitleExtensions.compactMap { UTType(filenameExtension: $0) }
        guard panel.runModal() == .OK, let url = panel.url else { return }
        _ = player.addPlaybackSlave(url, type: .subtitle, enforce: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            self?.refreshTracks()
        }
    }

    /// `folders: true` -> choix d'un (ou plusieurs) dossier(s) ; sinon fichiers ET dossiers possibles.
    func presentOpenPanel(append shouldAppend: Bool = false, folders: Bool = false) {
        let panel = NSOpenPanel()
        panel.title = folders
            ? (shouldAppend ? "Ajouter un dossier à la playlist" : "Ouvrir un dossier")
            : (shouldAppend ? "Ajouter à la playlist" : "Ouvrir des vidéos")
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = true
        panel.canChooseFiles = !folders
        if !folders {
            var types: [UTType] = [.movie, .video, .audiovisualContent, .folder]
            types += SupportedFormats.videoExtensions.compactMap { UTType(filenameExtension: $0) }
            panel.allowedContentTypes = types
        }
        guard panel.runModal() == .OK else { return }
        if shouldAppend {
            append(panel.urls)
        } else {
            replaceAndPlay(panel.urls)
        }
    }

    // MARK: - Rappels VLCMediaPlayerDelegate

    func mediaPlayerStateChanged(_ aNotification: Notification!) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.isPlaying = self.player.isPlaying
            switch self.player.state {
            case .playing:
                self.player.rate = self.rate
                self.applyVolume()
                self.applyDisplaySettings()
                self.updateWindowAspectLock()
                self.autoFitWindowIfNeeded()
                self.refreshTracks()
                // Certaines pistes ne sont déclarées qu'un instant après le début.
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in
                    self?.refreshTracks()
                }
            case .ended:
                self.playNextOrFinish()
            case .error:
                self.errorMessage = "Impossible de lire ce fichier."
                self.isPlaying = false
            default:
                break
            }
        }
    }

    func mediaPlayerTimeChanged(_ aNotification: Notification!) {
        DispatchQueue.main.async { [weak self] in
            guard let self, !self.isScrubbing else { return }
            self.position = Double(self.player.position)
            self.durationMs = self.player.media?.length.intValue ?? 0
            self.elapsedText = Self.format(ms: self.player.time.intValue)
            self.totalText = Self.format(ms: self.durationMs)
            self.autoFitWindowIfNeeded()
            if Date().timeIntervalSince(self.lastAspectUnlock) > 2 {
                self.lastAspectUnlock = Date()
                self.updateWindowAspectLock()
            }
            // Les pistes (langues) d'un MKV sont parfois déclarées avec un léger retard.
            if self.audioTracks.count < 2, Date().timeIntervalSince(self.lastTrackRefresh) > 1 {
                self.refreshTracks()
            }
        }
    }

    // MARK: - Bulle d'information

    func showHUD(_ text: String) {
        hudText = text
        hudTask?.cancel()
        hudTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 1_300_000_000)
            guard !Task.isCancelled else { return }
            self?.hudText = nil
        }
    }

    // MARK: - Molette = volume

    func scrollVolume(deltaY: CGFloat, precise: Bool, inverted: Bool) {
        let direction = inverted ? -deltaY : deltaY
        let step = Double(direction) * (precise ? 0.25 : 2.0)
        guard step != 0 else { return }
        volume = min(max(volume + step, 0), 100)
        showHUD("Volume \(Int(volume.rounded())) %")
    }

    // MARK: - Deux doigts gauche / droite = avance / recul

    private var scrubPending = 0.0          // secondes accumulées pas encore appliquées
    private var scrubTotal = 0              // total du geste en cours (pour la bulle)
    private var lastScrubEvent = Date.distantPast
    private var lastScrubSeek = Date.distantPast

    func scrubHorizontal(deltaX: CGFloat, precise: Bool, inverted: Bool) {
        guard currentIndex != nil else { return }
        // Sens physique : doigts vers la droite = avancer, quel que soit le réglage « défilement naturel ».
        let direction = inverted ? deltaX : -deltaX
        let now = Date()
        if now.timeIntervalSince(lastScrubEvent) > 0.7 { scrubTotal = 0; scrubPending = 0 }
        lastScrubEvent = now

        scrubPending += Double(direction) * (precise ? 0.2 : 5.0)    // trackpad : 100 pt ≈ 20 s
        guard abs(scrubPending) >= 1,
              now.timeIntervalSince(lastScrubSeek) > 0.08 else { return }

        let seconds = Int(scrubPending)
        scrubPending -= Double(seconds)
        scrubTotal += seconds
        lastScrubSeek = now
        skip(seconds: seconds)
        showHUD(scrubTotal >= 0 ? "▶▶ +\(scrubTotal) s" : "◀◀ \(scrubTotal) s")
    }

    // MARK: - Format et dimensions de l'image

    func setAspect(_ id: String) {
        guard let option = Self.aspectOptions.first(where: { $0.id == id }) else { return }
        aspectID = id
        applyAspect(option.value)
        updateWindowAspectLock()
        showHUD("Format : \(option.label)")
    }

    func cycleAspect() {
        let options = Self.aspectOptions
        let index = options.firstIndex(where: { $0.id == aspectID }) ?? 0
        setAspect(options[(index + 1) % options.count].id)
    }

    func setFill(_ value: Bool) {
        fillWindow = value
        showHUD(value ? "Image remplissant la fenêtre" : "Image entière visible")
    }

    func setOriginalSize(_ value: Bool) {
        originalSize = value
        player.scaleFactor = value ? 1 : 0
        showHUD(value ? "Taille d’origine (100 %)" : "Adapté à la fenêtre")
    }

    /// Redimensionne la fenêtre à la taille de la vidéo (réduite si elle dépasse l'écran).
    func fitWindowToVideo() {
        guard currentIndex != nil,
              let window = NSApp.keyWindow ?? NSApp.windows.first,
              !window.styleMask.contains(.fullScreen) else { return }
        let native = player.videoSize
        guard native.width > 0, native.height > 0 else { return }
        var width = native.width
        var height = native.height
        if let ratio = Self.aspectOptions.first(where: { $0.id == aspectID })?.ratio {
            width = height * CGFloat(ratio)
        }
        let screen = (window.screen ?? NSScreen.main)?.visibleFrame.size ?? CGSize(width: 1440, height: 900)
        let extra: CGFloat = showPlaylist ? playlistWidth + 1 : 0
        let scale = min(1, (screen.width * 0.92 - extra) / width, (screen.height * 0.85) / height)
        width *= scale
        height *= scale
        window.setContentSize(NSSize(width: width + extra, height: height + titlebarInset(window)))
        window.center()
    }

    /// À l'ouverture d'une vidéo : dès que son format est connu, la fenêtre prend exactement ce format
    /// (ni bandes noires ni rognage). Ensuite, les coins gardent les mêmes proportions.
    private func autoFitWindowIfNeeded() {
        guard needsAutoFit, currentIndex != nil,
              let window = mainWindow,
              let ratio = displayRatio() else { return }
        needsAutoFit = false
        guard !window.styleMask.contains(.fullScreen) else { return }

        if pipMode {
            // En PiP : on garde la largeur, seule la hauteur suit le nouveau format.
            updateWindowAspectLock()
            snapWindowToVideo(window)
            return
        }

        let extra: CGFloat = showPlaylist ? playlistWidth + 1 : 0
        if hasAutoFitted {
            // Vidéo suivante : on garde la largeur choisie, la hauteur suit le format.
            updateWindowAspectLock()
            snapWindowToVideo(window)
            applyDisplaySettings()
            return
        }
        hasAutoFitted = true

        // Première vidéo : taille d'origine, limitée à ~60 % de la largeur de l'écran et ~80 % de sa hauteur.
        let native = player.videoSize
        let visible = (window.screen ?? NSScreen.main)?.visibleFrame.size ?? CGSize(width: 1440, height: 900)
        var width = min(native.width > 0 ? native.width : 1000, visible.width * 0.6)
        width = max(width, Self.normalMinWidth)
        let inset = titlebarInset(window)
        var height = width / ratio
        let maxHeight = visible.height * 0.8 - 40 - inset
        if height > maxHeight {
            height = maxHeight
            width = max(height * ratio, 240)
        }
        window.setContentSize(NSSize(width: width + extra, height: height + inset))
        window.center()
        updateWindowAspectLock()
        snapWindowToVideo(window)
        applyDisplaySettings()      // VLC recalcule l'image pour la nouvelle taille (pas de réduction résiduelle)
    }

    private func applyAspect(_ value: String?) {
#if VLC_CSTRING_ASPECT
        // Anciennes versions de VLCKit : la propriété est un « char * ».
        if let value {
            let pointer = strdup(value)
            player.videoAspectRatio = pointer
            free(pointer)
        } else {
            player.videoAspectRatio = nil
        }
#else
        player.videoAspectRatio = value
#endif
    }

    private func applyDisplaySettings() {
        applyAspect(Self.aspectOptions.first(where: { $0.id == aspectID })?.value)
        player.scaleFactor = originalSize ? 1 : 0
    }

    // MARK: - Changer de piste audio / sous-titres au clavier

    func cycleAudioTrack() {
        let ids = audioTracks.map { $0.id }.filter { $0 >= 0 }
        guard ids.count > 1 else { return }
        let index = ids.firstIndex(of: selectedAudioTrack) ?? -1
        let next = ids[(index + 1) % ids.count]
        selectAudioTrack(next)
        let name = audioTracks.first(where: { $0.id == next })?.name ?? ""
        showHUD("Audio : \(Self.shortName(name))")
    }

    func cycleSubtitleTrack() {
        let ids = subtitleTracks.map { $0.id }
        guard ids.count > 1 else { return }
        let index = ids.firstIndex(of: selectedSubtitleTrack) ?? -1
        let next = ids[(index + 1) % ids.count]
        selectSubtitleTrack(next)
        let name = subtitleTracks.first(where: { $0.id == next })?.name ?? ""
        showHUD("Sous-titres : \(Self.shortName(name))")
    }

    /// « Piste 2 - [Français] » -> « Français »
    static func shortName(_ name: String) -> String {
        if let open = name.firstIndex(of: "["),
           let close = name.firstIndex(of: "]"),
           open < close {
            return String(name[name.index(after: open)..<close])
        }
        return name
    }

    // MARK: - Interne

    private func applyVolume() {
        player.audio?.volume = isMuted ? 0 : Int32(volume)
    }

    private func playNextOrFinish() {
        if let index = currentIndex, index + 1 < playlist.count {
            play(at: index + 1)
        } else {
            isPlaying = false
            position = 0
        }
    }

    private func refreshTracks() {
        lastTrackRefresh = Date()
        audioTracks = Self.makeTracks(names: player.audioTrackNames, indexes: player.audioTrackIndexes)
        subtitleTracks = Self.makeTracks(names: player.videoSubTitlesNames, indexes: player.videoSubTitlesIndexes)
        selectedAudioTrack = player.currentAudioTrackIndex
        selectedSubtitleTrack = player.currentVideoSubTitleIndex
    }

    private static func makeTracks(names: [Any]?, indexes: [Any]?) -> [MediaTrack] {
        guard let names = names as? [String],
              let indexes = indexes as? [NSNumber],
              names.count == indexes.count else { return [] }
        return zip(names, indexes).map { MediaTrack(id: $0.1.int32Value, name: $0.0) }
    }

    static func format(ms: Int32) -> String {
        let total = max(Int(ms), 0) / 1000
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let seconds = total % 60
        if hours > 0 {
            return String(format: "%d:%02d:%02d", hours, minutes, seconds)
        }
        return String(format: "%d:%02d", minutes, seconds)
    }
}
