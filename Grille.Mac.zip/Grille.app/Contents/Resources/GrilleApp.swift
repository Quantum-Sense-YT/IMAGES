// GrilleApp.swift
// Application macOS (SwiftUI) : importer une image, y appliquer une grille blanche,
// puis l'exporter à l'emplacement de votre choix.

import SwiftUI
import AppKit
import Combine
import ImageIO
import UniformTypeIdentifiers

// MARK: - Réglages et erreurs

struct GridSettings {
    var columns: Int
    var rows: Int
    var thickness: CGFloat   // en pixels de l'image d'origine
    var opacity: CGFloat     // de 0 à 1
    var outerBorder: Bool
    var doubled: Bool        // seconde grille identique, décalée
    var offsetX: CGFloat     // décalage horizontal, en fraction d'une cellule (0 à 1)
    var offsetY: CGFloat     // décalage vertical, en fraction d'une cellule (0 à 1)
}

enum ExportFormat: String, CaseIterable, Identifiable {
    case png = "PNG"
    case jpeg = "JPEG"

    var id: String { rawValue }
    var utType: UTType { self == .png ? .png : .jpeg }
    var fileExtension: String { self == .png ? "png" : "jpg" }
}

enum GridError: LocalizedError {
    case decode, render, write

    var errorDescription: String? {
        switch self {
        case .decode: return "Impossible de relire l'image d'origine."
        case .render: return "Impossible de dessiner la grille sur cette image."
        case .write:  return "Impossible d'écrire le fichier à cet emplacement."
        }
    }
}

// MARK: - Traitement d'image (Core Graphics / ImageIO)

enum ImageTools {

    /// Taille en pixels de l'image, orientation EXIF prise en compte.
    static func pixelSize(of url: URL) -> (width: Int, height: Int)? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil),
              CGImageSourceGetCount(src) > 0,
              let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
              let w = props[kCGImagePropertyPixelWidth] as? Int,
              let h = props[kCGImagePropertyPixelHeight] as? Int,
              w > 0, h > 0
        else { return nil }
        let orientation = (props[kCGImagePropertyOrientation] as? Int) ?? 1
        return (5...8).contains(orientation) ? (h, w) : (w, h)
    }

    /// Décode l'image (orientée correctement), au plus `maxPixel` pixels sur le grand côté.
    static func decode(url: URL, maxPixel: Int) -> CGImage? {
        guard let size = pixelSize(of: url),
              let src = CGImageSourceCreateWithURL(url as CFURL, nil)
        else { return nil }
        let target = max(1, min(maxPixel, max(size.width, size.height)))
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: target
        ]
        return CGImageSourceCreateThumbnailAtIndex(src, 0, options as CFDictionary)
    }

    /// Dessine l'image puis la grille blanche par-dessus. L'image produite a la taille de `source`.
    /// - referenceWidth : largeur de l'image d'origine, pour que l'épaisseur (en pixels
    ///   d'origine) reste proportionnelle quand on travaille sur un aperçu réduit.
    static func render(source: CGImage,
                       referenceWidth: Int,
                       settings: GridSettings,
                       forJPEG: Bool,
                       pixelAligned: Bool) -> CGImage? {
        let w = source.width
        let h = source.height
        let W = CGFloat(w)
        let H = CGFloat(h)

        let scale = W / CGFloat(max(referenceWidth, 1))
        var t = settings.thickness * scale
        t = pixelAligned ? max(1, t.rounded()) : max(0.5, t)

        // Espace colorimétrique : celui de l'image si c'est du RGB, sinon sRGB.
        var spaces: [CGColorSpace] = []
        if let cs = source.colorSpace, cs.model == .rgb { spaces.append(cs) }
        if let srgb = CGColorSpace(name: CGColorSpace.sRGB) { spaces.append(srgb) }

        let info: UInt32 = forJPEG
            ? CGImageAlphaInfo.noneSkipLast.rawValue
            : CGImageAlphaInfo.premultipliedLast.rawValue

        var context: CGContext?
        for cs in spaces {
            context = CGContext(data: nil, width: w, height: h,
                                bitsPerComponent: 8, bytesPerRow: 0,
                                space: cs, bitmapInfo: info)
            if context != nil { break }
        }
        guard let ctx = context else { return nil }

        ctx.interpolationQuality = .high
        let full = CGRect(x: 0, y: 0, width: W, height: H)

        if forJPEG {
            // Le JPEG n'a pas de transparence : fond blanc sous l'image.
            ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
            ctx.fill(full)
        }
        ctx.draw(source, in: full)

        // Toutes les lignes forment un seul tracé : les croisements ne sont pas
        // dessinés deux fois, même avec une opacité inférieure à 100 %.
        let path = CGMutablePath()
        let cols = max(1, settings.columns)
        let rows = max(1, settings.rows)
        let firstC = settings.outerBorder ? 0 : 1
        let lastC = settings.outerBorder ? cols : cols - 1
        let firstR = settings.outerBorder ? 0 : 1
        let lastR = settings.outerBorder ? rows : rows - 1

        for i in stride(from: firstC, through: lastC, by: 1) {
            var left = W * CGFloat(i) / CGFloat(cols) - t / 2
            if i == 0 { left = 0 }
            if i == cols { left = W - t }
            if pixelAligned { left = left.rounded() }
            path.addRect(CGRect(x: left, y: 0, width: t, height: H))
        }
        for j in stride(from: firstR, through: lastR, by: 1) {
            var bottom = H * CGFloat(j) / CGFloat(rows) - t / 2
            if j == 0 { bottom = 0 }
            if j == rows { bottom = H - t }
            if pixelAligned { bottom = bottom.rounded() }
            path.addRect(CGRect(x: 0, y: bottom, width: W, height: t))
        }

        // Seconde grille (option « Doubler la grille ») : même tracé, donc pas de double
        // mélange aux croisements. Jamais de ligne sur le bord de l'image.
        if settings.doubled {
            let dx = min(1, max(0, settings.offsetX))
            let dy = min(1, max(0, settings.offsetY))
            for i in 0...cols {
                let cx = W * (CGFloat(i) + dx) / CGFloat(cols)
                if cx <= 0 || cx >= W { continue }
                var left = cx - t / 2
                if pixelAligned { left = left.rounded() }
                path.addRect(CGRect(x: left, y: 0, width: t, height: H))
            }
            for j in 0...rows {
                // Le décalage vertical se mesure depuis le haut de l'image ;
                // Core Graphics compte depuis le bas.
                let cyTop = H * (CGFloat(j) + dy) / CGFloat(rows)
                if cyTop <= 0 || cyTop >= H { continue }
                var bottom = (H - cyTop) - t / 2
                if pixelAligned { bottom = bottom.rounded() }
                path.addRect(CGRect(x: 0, y: bottom, width: W, height: t))
            }
        }

        ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: settings.opacity))
        ctx.addPath(path)
        ctx.fillPath()
        return ctx.makeImage()
    }

    /// Relit l'image d'origine en pleine résolution, applique la grille et écrit le fichier.
    /// referenceWidth : largeur de l'image qui a servi à régler l'épaisseur. L'épaisseur est
    /// adaptée proportionnellement à la largeur de chaque image (utile pour un lot).
    static func exportFull(url: URL,
                           destination: URL,
                           referenceWidth: Int,
                           settings: GridSettings,
                           format: ExportFormat) throws {
        guard let size = pixelSize(of: url),
              let full = decode(url: url, maxPixel: max(size.width, size.height)) else {
            throw GridError.decode
        }
        guard let result = render(source: full,
                                  referenceWidth: referenceWidth,
                                  settings: settings,
                                  forJPEG: format == .jpeg,
                                  pixelAligned: true) else {
            throw GridError.render
        }
        try write(result, to: destination, format: format)
    }

    /// Images d'une sélection : les fichiers eux-mêmes et le contenu (sans sous-dossiers)
    /// des dossiers. Les fichiers illisibles sont ignorés ; résultat trié par nom.
    static func imageFiles(in urls: [URL]) -> [URL] {
        let fm = FileManager.default
        var candidates: [URL] = []
        for url in urls {
            var isDirectory: ObjCBool = false
            if fm.fileExists(atPath: url.path, isDirectory: &isDirectory), isDirectory.boolValue {
                let items = (try? fm.contentsOfDirectory(at: url,
                                                         includingPropertiesForKeys: nil,
                                                         options: [.skipsHiddenFiles])) ?? []
                for item in items where hasImageExtension(item) {
                    candidates.append(item)
                }
            } else {
                candidates.append(url)
            }
        }

        var seen = Set<String>()
        var unique: [URL] = []
        for url in candidates {
            if seen.insert(url.standardizedFileURL.path).inserted {
                unique.append(url)
            }
        }

        let readable = unique.filter { pixelSize(of: $0) != nil }
        return readable.sorted {
            $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending
        }
    }

    private static func hasImageExtension(_ url: URL) -> Bool {
        guard let type = UTType(filenameExtension: url.pathExtension.lowercased()) else { return false }
        return type.conforms(to: .image)
    }

    /// Nom de fichier libre dans `folder` : « nom_grille.png », puis « nom_grille 2.png »…
    /// (un export en lot n'écrase jamais un fichier existant).
    static func uniqueDestination(folder: URL, baseName: String, ext: String) -> URL {
        let fm = FileManager.default
        var candidate = folder.appendingPathComponent("\(baseName)_grille.\(ext)")
        var n = 2
        while fm.fileExists(atPath: candidate.path) {
            candidate = folder.appendingPathComponent("\(baseName)_grille \(n).\(ext)")
            n += 1
        }
        return candidate
    }

    static func write(_ image: CGImage, to url: URL, format: ExportFormat) throws {
        guard let dest = CGImageDestinationCreateWithURL(url as CFURL,
                                                         format.utType.identifier as CFString,
                                                         1, nil) else {
            throw GridError.write
        }
        var props: [CFString: Any] = [:]
        if format == .jpeg { props[kCGImageDestinationLossyCompressionQuality] = 0.95 }
        CGImageDestinationAddImage(dest, image, props as CFDictionary)
        guard CGImageDestinationFinalize(dest) else { throw GridError.write }
    }
}

// MARK: - Modèle

final class GridModel: ObservableObject {

    // Réglages de la grille (valeurs par défaut = la référence : 18 × 9, lignes de 4 px pour 1920 px de large)
    @Published var columns: Double = 18 { didSet { refreshPreview() } }
    @Published var rows: Double = 9 { didSet { refreshPreview() } }
    @Published var thickness: Double = 4 { didSet { refreshPreview() } }
    @Published var thicknessMax: Double = 40
    @Published var opacityPercent: Double = 100 { didSet { refreshPreview() } }
    @Published var outerBorder: Bool = false { didSet { refreshPreview() } }
    @Published var doubled: Bool = false { didSet { refreshPreview() } }
    @Published var offsetXPercent: Double = 50 { didSet { refreshPreview() } }
    @Published var offsetYPercent: Double = 50 { didSet { refreshPreview() } }
    @Published var format: ExportFormat = .png

    // État
    @Published private(set) var sourceURLs: [URL] = []
    @Published private(set) var currentIndex: Int = 0
    @Published private(set) var fullWidth: Int = 0
    @Published private(set) var fullHeight: Int = 0
    @Published private(set) var preview: NSImage?
    @Published private(set) var isExporting = false
    @Published private(set) var statusMessage: String?
    @Published private(set) var errorMessage: String?
    @Published private(set) var lastExportURL: URL?
    @Published private(set) var progressDone: Int = 0
    @Published private(set) var progressTotal: Int = 0

    private var previewSource: CGImage?
    private var referenceWidth: Int = 0   // largeur de la première image : référence de l'épaisseur

    private let lastDirectoryKey = "dernierDossierExport"

    var settings: GridSettings {
        GridSettings(columns: max(1, Int(columns.rounded())),
                     rows: max(1, Int(rows.rounded())),
                     thickness: CGFloat(thickness),
                     opacity: CGFloat(opacityPercent / 100),
                     outerBorder: outerBorder,
                     doubled: doubled,
                     offsetX: CGFloat(offsetXPercent / 100),
                     offsetY: CGFloat(offsetYPercent / 100))
    }

    /// Image affichée dans l'aperçu.
    var sourceURL: URL? {
        sourceURLs.indices.contains(currentIndex) ? sourceURLs[currentIndex] : nil
    }

    // MARK: Import

    func chooseImages() {
        let panel = NSOpenPanel()
        panel.title = "Choisir des images ou un dossier"
        panel.prompt = "Choisir"
        panel.allowedContentTypes = [.image]
        panel.allowsMultipleSelection = true
        panel.canChooseFiles = true
        panel.canChooseDirectories = true
        if panel.runModal() == .OK {
            loadImages(from: panel.urls)
        }
    }

    /// Charge une ou plusieurs images (ou des dossiers d'images).
    func loadImages(from urls: [URL]) {
        statusMessage = nil
        errorMessage = nil
        lastExportURL = nil

        let files = ImageTools.imageFiles(in: urls)
        guard let first = files.first,
              let size = ImageTools.pixelSize(of: first),
              let small = ImageTools.decode(url: first, maxPixel: 1600) else {
            errorMessage = urls.count > 1
                ? "Aucune image lisible dans cette sélection."
                : "Ce fichier n'a pas pu être ouvert comme image."
            return
        }

        sourceURLs = files
        currentIndex = 0
        fullWidth = size.width
        fullHeight = size.height
        previewSource = small
        referenceWidth = size.width

        // Épaisseur par défaut proportionnelle à la référence (4 px pour 1920 px de large).
        let defaultThickness = max(1, (Double(size.width) * 4.0 / 1920.0).rounded())
        thicknessMax = max(40, defaultThickness * 3)
        thickness = defaultThickness
        refreshPreview()
    }

    /// Affiche une autre image de la sélection dans l'aperçu.
    func showImage(at index: Int) {
        guard sourceURLs.indices.contains(index) else { return }
        let url = sourceURLs[index]
        guard let size = ImageTools.pixelSize(of: url),
              let small = ImageTools.decode(url: url, maxPixel: 1600) else {
            errorMessage = "« \(url.lastPathComponent) » n'a pas pu être ouverte."
            return
        }
        errorMessage = nil
        currentIndex = index
        fullWidth = size.width
        fullHeight = size.height
        previewSource = small
        refreshPreview()
    }

    func showPrevious() { showImage(at: currentIndex - 1) }
    func showNext() { showImage(at: currentIndex + 1) }

    // MARK: Aperçu

    private func refreshPreview() {
        guard let src = previewSource, referenceWidth > 0 else {
            preview = nil
            return
        }
        if let cg = ImageTools.render(source: src,
                                      referenceWidth: referenceWidth,
                                      settings: settings,
                                      forJPEG: false,
                                      pixelAligned: false) {
            preview = NSImage(cgImage: cg, size: NSSize(width: cg.width, height: cg.height))
        }
    }

    // MARK: Export

    private var lastExportDirectory: URL? {
        guard let path = UserDefaults.standard.string(forKey: lastDirectoryKey),
              FileManager.default.fileExists(atPath: path) else { return nil }
        return URL(fileURLWithPath: path, isDirectory: true)
    }

    func export() {
        guard !sourceURLs.isEmpty, !isExporting else { return }
        if sourceURLs.count == 1 {
            exportSingle()
        } else {
            exportBatch()
        }
    }

    /// Une seule image : fenêtre « Enregistrer sous » (nom et dossier au choix).
    private func exportSingle() {
        guard let sourceURL = sourceURLs.first else { return }

        let panel = NSSavePanel()
        panel.title = "Exporter l'image avec la grille"
        panel.prompt = "Exporter"
        panel.canCreateDirectories = true
        panel.allowedContentTypes = [format.utType]
        panel.nameFieldStringValue = sourceURL.deletingPathExtension().lastPathComponent
            + "_grille." + format.fileExtension
        panel.directoryURL = lastExportDirectory ?? sourceURL.deletingLastPathComponent()

        guard panel.runModal() == .OK, let destination = panel.url else { return }

        UserDefaults.standard.set(destination.deletingLastPathComponent().path, forKey: lastDirectoryKey)

        statusMessage = nil
        errorMessage = nil
        progressDone = 0
        progressTotal = 0
        isExporting = true

        let currentSettings = settings
        let currentFormat = format
        let refWidth = referenceWidth

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try ImageTools.exportFull(url: sourceURL,
                                          destination: destination,
                                          referenceWidth: refWidth,
                                          settings: currentSettings,
                                          format: currentFormat)
                DispatchQueue.main.async {
                    self?.isExporting = false
                    self?.lastExportURL = destination
                    self?.statusMessage = "Image exportée : \(destination.lastPathComponent)"
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isExporting = false
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }

    /// Plusieurs images : on choisit un dossier, toutes les images y sont exportées
    /// (« nom_grille.png »), sans jamais écraser un fichier existant.
    private func exportBatch() {
        let urls = sourceURLs

        let panel = NSOpenPanel()
        panel.title = "Choisir le dossier d'export"
        panel.message = "Les \(urls.count) images seront enregistrées avec la grille dans ce dossier."
        panel.prompt = "Exporter ici"
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = lastExportDirectory ?? urls[0].deletingLastPathComponent()

        guard panel.runModal() == .OK, let folder = panel.url else { return }

        UserDefaults.standard.set(folder.path, forKey: lastDirectoryKey)

        statusMessage = nil
        errorMessage = nil
        lastExportURL = nil
        progressDone = 0
        progressTotal = urls.count
        isExporting = true

        let currentSettings = settings
        let currentFormat = format
        let refWidth = referenceWidth

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var failedNames: [String] = []
            var lastDestination: URL?

            for (index, url) in urls.enumerated() {
                autoreleasepool {
                    let destination = ImageTools.uniqueDestination(
                        folder: folder,
                        baseName: url.deletingPathExtension().lastPathComponent,
                        ext: currentFormat.fileExtension)
                    do {
                        try ImageTools.exportFull(url: url,
                                                  destination: destination,
                                                  referenceWidth: refWidth,
                                                  settings: currentSettings,
                                                  format: currentFormat)
                        lastDestination = destination
                    } catch {
                        failedNames.append(url.lastPathComponent)
                    }
                }
                let done = index + 1
                DispatchQueue.main.async {
                    self?.progressDone = done
                }
            }

            let failed = failedNames
            let last = lastDestination
            let exportedCount = urls.count - failed.count

            DispatchQueue.main.async {
                guard let model = self else { return }
                model.isExporting = false
                model.lastExportURL = last
                if exportedCount > 0 {
                    let countText = exportedCount == 1
                        ? "1 image exportée"
                        : "\(exportedCount) images exportées"
                    model.statusMessage = countText + " dans « \(folder.lastPathComponent) »"
                }
                if !failed.isEmpty {
                    let shown = failed.prefix(3).joined(separator: ", ")
                    let more = failed.count > 3 ? "…" : ""
                    model.errorMessage = "Échec pour \(failed.count) image(s) : \(shown)\(more)"
                }
            }
        }
    }
}

// MARK: - Interface

/// Rassemble, de façon sûre entre plusieurs threads, les fichiers déposés dans la fenêtre.
final class URLCollector {
    private let lock = NSLock()
    private var urls: [URL] = []

    func add(_ url: URL) {
        lock.lock()
        urls.append(url)
        lock.unlock()
    }

    var all: [URL] {
        lock.lock()
        defer { lock.unlock() }
        return urls
    }
}

struct ContentView: View {
    @StateObject private var model = GridModel()
    @State private var isDropTargeted = false

    var body: some View {
        HStack(spacing: 0) {
            previewPane
            Divider()
            controlsPane
        }
        .frame(minWidth: 880, idealWidth: 1020, minHeight: 600, idealHeight: 700)
    }

    // Zone d'aperçu + glisser-déposer
    private var previewPane: some View {
        ZStack {
            Color(nsColor: .underPageBackgroundColor)

            if let image = model.preview {
                Image(nsImage: image)
                    .resizable()
                    .interpolation(.high)
                    .aspectRatio(contentMode: .fit)
                    .padding(16)
            } else {
                VStack(spacing: 10) {
                    Image(systemName: "photo")
                        .font(.system(size: 46))
                        .foregroundColor(.secondary)
                    Text("Glissez des images ou un dossier ici")
                        .font(.title3)
                    Text("ou cliquez sur « Choisir des images… »")
                        .foregroundColor(.secondary)
                }
            }

            if isDropTargeted {
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(Color.accentColor, style: StrokeStyle(lineWidth: 3, dash: [8]))
                    .padding(8)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onDrop(of: [UTType.fileURL], isTargeted: $isDropTargeted) { providers in
            handleDrop(providers)
        }
    }

    // Panneau de réglages
    private var controlsPane: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 12) {
                Button {
                    model.chooseImages()
                } label: {
                    Label("Choisir des images…", systemImage: "photo")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.large)
                .keyboardShortcut("o")

                if let url = model.sourceURL {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(url.lastPathComponent)
                            .font(.caption)
                            .lineLimit(1)
                            .truncationMode(.middle)
                        Text("\(model.fullWidth) × \(model.fullHeight) px")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }

                if model.sourceURLs.count > 1 {
                    HStack(spacing: 8) {
                        Button {
                            model.showPrevious()
                        } label: {
                            Image(systemName: "chevron.left")
                        }
                        .disabled(model.currentIndex <= 0)

                        Text("Aperçu \(model.currentIndex + 1) / \(model.sourceURLs.count)")
                            .font(.callout)
                            .frame(maxWidth: .infinity)

                        Button {
                            model.showNext()
                        } label: {
                            Image(systemName: "chevron.right")
                        }
                        .disabled(model.currentIndex >= model.sourceURLs.count - 1)
                    }
                    Text("Les réglages s'appliquent à toutes les images ; l'épaisseur s'adapte à la taille de chacune.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Divider()

                sliderRow("Colonnes", value: $model.columns, range: 1...60,
                          display: "\(Int(model.columns.rounded()))")
                sliderRow("Rangées", value: $model.rows, range: 1...60,
                          display: "\(Int(model.rows.rounded()))")
                sliderRow("Épaisseur", value: $model.thickness, range: 1...model.thicknessMax,
                          display: "\(Int(model.thickness.rounded())) px")
                sliderRow("Opacité", value: $model.opacityPercent, range: 0...100,
                          display: "\(Int(model.opacityPercent.rounded())) %")

                Toggle("Bordure extérieure", isOn: $model.outerBorder)
                Toggle("Doubler la grille (2 grilles décalées)", isOn: $model.doubled)

                if model.doubled {
                    sliderRow("Décalage horizontal", value: $model.offsetXPercent, range: 0...100,
                              display: "\(Int(model.offsetXPercent.rounded())) %")
                    sliderRow("Décalage vertical", value: $model.offsetYPercent, range: 0...100,
                              display: "\(Int(model.offsetYPercent.rounded())) %")
                }

                Divider()

                Text("Format d'export")
                Picker("Format d'export", selection: $model.format) {
                    ForEach(ExportFormat.allCases) { fmt in
                        Text(fmt.rawValue).tag(fmt)
                    }
                }
                .pickerStyle(.segmented)
                .labelsHidden()

                Button {
                    model.export()
                } label: {
                    Text(model.sourceURLs.count > 1
                         ? "Exporter les \(model.sourceURLs.count) images…"
                         : "Exporter…")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .keyboardShortcut("e")
                .disabled(model.sourceURL == nil || model.isExporting)

                if model.isExporting {
                    if model.progressTotal > 1 {
                        VStack(alignment: .leading, spacing: 4) {
                            ProgressView(value: Double(model.progressDone),
                                         total: Double(model.progressTotal))
                            Text("Export en cours… \(model.progressDone) / \(model.progressTotal)")
                                .foregroundColor(.secondary)
                        }
                    } else {
                        HStack(spacing: 8) {
                            ProgressView().controlSize(.small)
                            Text("Export en cours…").foregroundColor(.secondary)
                        }
                    }
                }
                if let message = model.statusMessage {
                    Text(message)
                        .font(.callout)
                        .foregroundColor(.secondary)
                    if let url = model.lastExportURL {
                        Button("Afficher dans le Finder") {
                            NSWorkspace.shared.activateFileViewerSelecting([url])
                        }
                    }
                }
                if let error = model.errorMessage {
                    Text(error)
                        .font(.callout)
                        .foregroundColor(.red)
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(width: 310)
    }

    private func sliderRow(_ title: String,
                           value: Binding<Double>,
                           range: ClosedRange<Double>,
                           display: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(title)
                Spacer()
                Text(display).foregroundColor(.secondary)
            }
            Slider(value: value, in: range, step: 1)
        }
    }

    private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
        let fileProviders = providers.filter {
            $0.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier)
        }
        guard !fileProviders.isEmpty else { return false }

        let collector = URLCollector()
        let group = DispatchGroup()

        for provider in fileProviders {
            group.enter()
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                var url: URL?
                if let data = item as? Data {
                    url = URL(dataRepresentation: data, relativeTo: nil)
                } else if let direct = item as? URL {
                    url = direct
                }
                if let fileURL = url {
                    collector.add(fileURL)
                }
                group.leave()
            }
        }

        group.notify(queue: .main) {
            model.loadImages(from: collector.all)
        }
        return true
    }
}

// MARK: - Application

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        true
    }
}

@main
struct GrilleApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup("Grille") {
            ContentView()
        }
    }
}
