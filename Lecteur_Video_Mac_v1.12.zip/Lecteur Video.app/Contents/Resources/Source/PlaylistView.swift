import SwiftUI

struct PlaylistView: View {
    @EnvironmentObject private var model: PlayerModel
    @State private var dropTargeted = false

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            if model.playlist.isEmpty {
                emptyState
            } else {
                List {
                    ForEach(Array(model.playlist.enumerated()), id: \.offset) { index, url in
                        row(index: index, url: url)
                    }
                    .onMove { source, destination in
                        model.movePlaylist(from: source, to: destination)
                    }
                }
                .listStyle(.sidebar)
            }
        }
        .background(.regularMaterial)
        .clipped()
        .overlay {
            if dropTargeted {
                RoundedRectangle(cornerRadius: 10)
                    .strokeBorder(Color.accentColor, style: StrokeStyle(lineWidth: 2.5, dash: [8, 5]))
                    .background(Color.accentColor.opacity(0.08))
                    .padding(6)
                    .allowsHitTesting(false)
            }
        }
        // Déposer fichiers ou dossiers ici : ils sont AJOUTÉS à la playlist.
        .dropDestination(for: URL.self) { urls, _ in
            model.append(urls)
            return true
        } isTargeted: { targeted in
            dropTargeted = targeted
        }
    }

    private var header: some View {
        HStack {
            Text("Playlist")
                .font(.headline)
                .lineLimit(1)
            Spacer()
            Menu {
                Button("Ajouter des fichiers…") { model.presentOpenPanel(append: true) }
                Button("Ajouter un dossier…") { model.presentOpenPanel(append: true, folders: true) }
            } label: {
                Image(systemName: "plus")
            }
            .menuStyle(.borderlessButton)
            .menuIndicator(.hidden)
            .fixedSize()
            .help("Ajouter des fichiers ou un dossier")

            Button {
                model.clearPlaylist()
            } label: {
                Image(systemName: "trash")
            }
            .buttonStyle(.borderless)
            .disabled(model.playlist.isEmpty)
            .help("Vider la playlist")
        }
        .padding(10)
    }

    private var emptyState: some View {
        VStack(spacing: 10) {
            Spacer()
            Image(systemName: "square.and.arrow.down.on.square")
                .font(.system(size: 34))
                .foregroundStyle(.secondary)
            Text("Glissez des vidéos\nou un dossier ici")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
            HStack {
                Button("Fichiers…") { model.presentOpenPanel(append: true) }
                Button("Dossier…") { model.presentOpenPanel(append: true, folders: true) }
            }
            .controlSize(.small)
            Spacer()
        }
        .padding(12)
        .frame(maxWidth: .infinity)
    }

    private func row(index: Int, url: URL) -> some View {
        let isCurrent = (index == model.currentIndex)
        return HStack(spacing: 8) {
            Image(systemName: isCurrent ? "play.fill" : "film")
                .frame(width: 16)
                .foregroundStyle(isCurrent ? Color.accentColor : Color.secondary)
            Text(url.lastPathComponent)
                .lineLimit(1)
                .truncationMode(.middle)
                .fontWeight(isCurrent ? .semibold : .regular)
            Spacer(minLength: 0)
        }
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { model.play(at: index) }
        .contextMenu {
            Button("Lire") { model.play(at: index) }
            Button("Retirer de la playlist", role: .destructive) { model.remove(at: index) }
        }
    }
}
