import Cocoa
import WebKit

// Sert uniquement index.html sous l'adresse iptv://app/index.html
final class AssetHandler: NSObject, WKURLSchemeHandler {
    let index: URL
    init(index: URL) {
        self.index = index
        super.init()
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        let p = url.path
        guard p.isEmpty || p == "/" || p == "/index.html", let data = try? Data(contentsOf: index) else {
            let r = HTTPURLResponse(url: url, statusCode: 404, httpVersion: "HTTP/1.1", headerFields: nil)!
            urlSchemeTask.didReceive(r)
            urlSchemeTask.didFinish()
            return
        }
        let r = URLResponse(url: url, mimeType: "text/html", expectedContentLength: data.count, textEncodingName: "utf-8")
        urlSchemeTask.didReceive(r)
        urlSchemeTask.didReceive(data)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}
}

// Télécharge au plus `limit` octets puis coupe la connexion (utile pour les flux en direct)
final class CappedFetch: NSObject, URLSessionDataDelegate {
    private let limit: Int
    private var buf = Data()
    private var status = 0
    private var finalURL = ""
    private var finished = false
    private var session: URLSession?
    private let done: (Bool, Data, String) -> Void

    init(limit: Int, done: @escaping (Bool, Data, String) -> Void) {
        self.limit = limit
        self.done = done
        super.init()
    }

    func start(_ req: URLRequest) {
        finalURL = req.url?.absoluteString ?? ""
        let s = URLSession(configuration: .ephemeral, delegate: self, delegateQueue: nil)
        session = s
        s.dataTask(with: req).resume()
        s.finishTasksAndInvalidate()
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        if let h = response as? HTTPURLResponse { status = h.statusCode }
        if let u = response.url { finalURL = u.absoluteString }
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        buf.append(data)
        if buf.count >= limit { dataTask.cancel() }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if finished { return }
        finished = true
        let ok = (200..<300).contains(status) && !buf.isEmpty
        done(ok, buf, finalURL)
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate, WKUIDelegate, WKScriptMessageHandler {
    var window: NSWindow!
    var web: WKWebView!
    var handler: AssetHandler!

    // Image dans l'image (fenêtre flottante)
    var pipOn = false
    var savedFrame = NSRect.zero
    var savedMin = NSSize.zero
    var savedBehavior: NSWindow.CollectionBehavior = []
    var dragStartMouse = NSPoint.zero
    var dragStartOrigin = NSPoint.zero

    // Proportions de la vidéo : la fenêtre suit le format de l'image (aucune bande grise ou noire)
    var lockRatio: CGFloat = 0      // 0 = pas de contrainte
    var lockSide: CGFloat = 0       // largeur (en points) de la liste de chaînes visible
    var lastPipChange = Date.distantPast
    let normalMin = NSSize(width: 600, height: 360)   // taille minimale de la fenêtre en mode normal
    var pushedBelow = false                           // l'utilisateur pousse sous ce minimum
    var pipInPlaceRect: NSRect? = nil                 // position de la vidéo, pour passer en image dans l'image sur place

    func applicationDidFinishLaunching(_ notification: Notification) {
        let res = Bundle.main.resourceURL ?? URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        handler = AssetHandler(index: res.appendingPathComponent("index.html"))

        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(handler, forURLScheme: "iptv")
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.userContentController.add(self, name: "nativeFetch")
        cfg.userContentController.add(self, name: "native")
        if #available(macOS 12.3, *) {
            cfg.preferences.isElementFullscreenEnabled = true
        }

        web = WKWebView(frame: .zero, configuration: cfg)
        web.uiDelegate = self

        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 940, height: 580),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "Lecteur IPTV"
        window.minSize = NSSize(width: 320, height: 200)   // le minimum « normal » est géré par windowWillResize
        window.contentView = web
        window.delegate = self
        window.center()
        window.setFrameAutosaveName("LecteurIPTVFenetre2")

        buildMenu()
        web.load(URLRequest(url: URL(string: "iptv://app/index.html")!))
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }

    // Téléchargement d'une playlist par URL, sans restriction CORS
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "native" {
            handleNative(message.body)
            return
        }
        guard message.name == "nativeFetch",
              let d = message.body as? [String: Any],
              let id = d["id"] as? Int,
              let s = d["url"] as? String,
              let url = URL(string: s) else { return }
        if let cap = d["max"] as? Int, cap > 0 {
            cappedFetch(id: id, url: url, cap: cap)
            return
        }
        var req = URLRequest(url: url)
        req.timeoutInterval = 60
        URLSession.shared.dataTask(with: req) { [weak self] data, resp, _ in
            var flag = "false"
            var b64 = ""
            let u64 = Data((resp?.url?.absoluteString ?? s).utf8).base64EncodedString()
            if let data = data, let h = resp as? HTTPURLResponse, (200..<300).contains(h.statusCode) {
                flag = "true"
                b64 = data.base64EncodedString()
            }
            let js = "window.__nf(\(id),\(flag),\"\(b64)\",\"\(u64)\")"
            DispatchQueue.main.async {
                self?.web.evaluateJavaScript(js, completionHandler: nil)
            }
        }.resume()
    }

    // Lecture partielle (début d'une playlist HLS), avec l'identité du lecteur vidéo
    func cappedFetch(id: Int, url: URL, cap: Int) {
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        req.setValue("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)", forHTTPHeaderField: "User-Agent")
        let job = CappedFetch(limit: cap) { [weak self] ok, data, finalURL in
            let flag = ok ? "true" : "false"
            let b64 = ok ? data.base64EncodedString() : ""
            let u64 = Data(finalURL.utf8).base64EncodedString()
            let js = "window.__nf(\(id),\(flag),\"\(b64)\",\"\(u64)\")"
            DispatchQueue.main.async {
                self?.web.evaluateJavaScript(js, completionHandler: nil)
            }
        }
        job.start(req)
    }

    // Commandes envoyées par la page (déplacement de fenêtre, image dans l'image)
    func handleNative(_ body: Any) {
        guard let d = body as? [String: Any], let cmd = d["cmd"] as? String else { return }
        switch cmd {
        case "pip":
            let on = (d["on"] as? Bool) ?? false
            let r = (d["ratio"] as? Double) ?? (16.0 / 9.0)
            setPip(on, ratio: r)
        case "layout":
            let r = (d["ratio"] as? Double) ?? 0
            let sd = (d["side"] as? Double) ?? 0
            lockRatio = (r > 0.3 && r < 4.0) ? CGFloat(r) : 0
            lockSide = CGFloat(max(0.0, sd))
            let wait = 0.55 - Date().timeIntervalSince(lastPipChange)
            if wait > 0 {
                DispatchQueue.main.asyncAfter(deadline: .now() + wait) { [weak self] in self?.conform() }
            } else {
                conform()
            }
        case "ratio":
            if pipOn, let r = d["ratio"] as? Double { applyPipRatio(r) }
        case "drag":
            guard !window.styleMask.contains(.fullScreen), let p = d["p"] as? String else { return }
            if p == "start" {
                dragStartMouse = NSEvent.mouseLocation
                dragStartOrigin = window.frame.origin
            } else if p == "move", NSEvent.pressedMouseButtons & 1 != 0 {
                let m = NSEvent.mouseLocation
                window.setFrameOrigin(NSPoint(x: dragStartOrigin.x + m.x - dragStartMouse.x,
                                              y: dragStartOrigin.y + m.y - dragStartMouse.y))
            }
        default:
            break
        }
    }

    func contentSizeFor(frame: NSSize) -> NSSize {
        return window.contentRect(forFrameRect: NSRect(origin: .zero, size: frame)).size
    }

    func frameSizeFor(content: NSSize) -> NSSize {
        return window.frameRect(forContentRect: NSRect(origin: .zero, size: content)).size
    }

    // Taille de contenu respectant le format de la vidéo (zone vidéo = contenu - liste de chaînes)
    func fitContent(_ w: CGFloat, _ h: CGFloat, widthLeads: Bool) -> NSSize {
        let r = lockRatio
        let side = lockSide
        var cw = w
        var ch = h
        if widthLeads { ch = (cw - side) / r } else { cw = side + ch * r }
        let mn = contentSizeFor(frame: normalMin)
        let cwMin = max(mn.width, side + mn.height * r)
        var cwMax = CGFloat.greatestFiniteMagnitude
        if let vf = (window.screen ?? NSScreen.main)?.visibleFrame {
            let m = contentSizeFor(frame: vf.size)
            cwMax = min(m.width, side + m.height * r)
        }
        cw = max(cw, cwMin)
        if cwMax >= cwMin { cw = min(cw, cwMax) }
        ch = (cw - side) / r
        return NSSize(width: cw, height: ch)
    }

    // Pendant que l'utilisateur tire sur un bord ou un coin
    func windowWillResize(_ sender: NSWindow, to frameSize: NSSize) -> NSSize {
        guard !pipOn, !sender.styleMask.contains(.fullScreen) else { return frameSize }
        pushedBelow = false
        if lockRatio <= 0 {
            return NSSize(width: max(frameSize.width, normalMin.width), height: max(frameSize.height, normalMin.height))
        }
        let p = contentSizeFor(frame: frameSize)
        let c = contentSizeFor(frame: sender.frame.size)
        let dw = abs(p.width - c.width) / max(c.width, 1)
        let dh = abs(p.height - c.height) / max(c.height, 1)
        // Si on tire nettement en dessous du minimum, la fin du geste basculera en image dans l'image
        let mn = contentSizeFor(frame: normalMin)
        let cwMin = max(mn.width, lockSide + mn.height * lockRatio)
        let impliedW = dw >= dh ? p.width : lockSide + p.height * lockRatio
        pushedBelow = impliedW < cwMin - 30
        let n = fitContent(p.width, p.height, widthLeads: dw >= dh)
        return frameSizeFor(content: n)
    }

    // Fin du geste de redimensionnement : passage en image dans l'image si on est allé sous le minimum
    func windowDidEndLiveResize(_ notification: Notification) {
        let go = pushedBelow && !pipOn && lockRatio > 0 && !window.styleMask.contains(.fullScreen)
        pushedBelow = false
        guard go else { return }
        let f = window.frame
        let c = contentSizeFor(frame: f.size)
        let w = max(240, c.width - lockSide)
        pipInPlaceRect = NSRect(x: f.minX + lockSide, y: f.minY, width: w, height: w / lockRatio)
        web.evaluateJavaScript("window.__pip&&window.__pip(true)", completionHandler: nil)
    }

    // Ajuste la fenêtre au format de la vidéo (nouvelle chaîne, liste masquée ou affichée…)
    func conform() {
        guard lockRatio > 0, !pipOn, !window.styleMask.contains(.fullScreen) else { return }
        let f = window.frame
        let c = contentSizeFor(frame: f.size)
        let n = fitContent(c.width, c.height, widthLeads: false)
        let nf = frameSizeFor(content: n)
        if abs(nf.width - f.width) < 1 && abs(nf.height - f.height) < 1 { return }
        var r = NSRect(x: f.minX, y: f.maxY - nf.height, width: nf.width, height: nf.height)
        if let vf = (window.screen ?? NSScreen.main)?.visibleFrame {
            if r.maxX > vf.maxX { r.origin.x = max(vf.minX, vf.maxX - r.width) }
            if r.minY < vf.minY { r.origin.y = vf.minY }
        }
        window.setFrame(r, display: true, animate: true)
    }

    func applyPipRatio(_ ratio: Double) {
        let r = CGFloat(max(0.3, min(ratio, 4.0)))
        window.aspectRatio = NSSize(width: r * 1000, height: 1000)
        var f = window.frame
        let newH = f.width / r
        f.origin.y += f.height - newH
        f.size.height = newH
        window.setFrame(f, display: true, animate: false)
    }

    func setPip(_ on: Bool, ratio: Double) {
        let inPlace = pipInPlaceRect
        pipInPlaceRect = nil
        if on == pipOn {
            if on { applyPipRatio(ratio) }
            return
        }
        guard !window.styleMask.contains(.fullScreen) else { return }
        pipOn = on
        lastPipChange = Date()
        let buttons: [NSWindow.ButtonType] = [.closeButton, .miniaturizeButton, .zoomButton]
        if on {
            savedFrame = window.frame
            savedMin = window.minSize
            savedBehavior = window.collectionBehavior
            window.setFrameAutosaveName("")
            window.styleMask.insert(.fullSizeContentView)
            window.titlebarAppearsTransparent = true
            window.titleVisibility = .hidden
            buttons.forEach { window.standardWindowButton($0)?.isHidden = true }
            window.level = .floating
            window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
            window.minSize = NSSize(width: 240, height: 135)
            let r = CGFloat(max(0.3, min(ratio, 4.0)))
            let w: CGFloat = 420
            let h = w / r
            let vf = (window.screen ?? NSScreen.main)?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
            window.setFrame(inPlace ?? NSRect(x: vf.maxX - w - 24, y: vf.minY + 24, width: w, height: h), display: true, animate: true)
            window.aspectRatio = NSSize(width: r * 1000, height: 1000)
        } else {
            window.resizeIncrements = NSSize(width: 1, height: 1)   // supprime la contrainte de ratio
            window.level = .normal
            window.collectionBehavior = savedBehavior
            window.styleMask.remove(.fullSizeContentView)
            window.titlebarAppearsTransparent = false
            window.titleVisibility = .visible
            buttons.forEach { window.standardWindowButton($0)?.isHidden = false }
            window.minSize = savedMin
            window.setFrame(savedFrame, display: true, animate: true)
            window.setFrameAutosaveName("LecteurIPTVFenetre2")
        }
    }

    @objc func togglePip(_ sender: Any?) {
        web.evaluateJavaScript("window.__pip&&window.__pip()", completionHandler: nil)
    }

    // Sélecteur de fichier pour <input type="file">
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let p = NSOpenPanel()
        p.canChooseFiles = true
        p.canChooseDirectories = false
        p.allowsMultipleSelection = parameters.allowsMultipleSelection
        p.beginSheetModal(for: window) { r in
            completionHandler(r == .OK ? p.urls : nil)
        }
    }

    // Boîtes de confirmation JavaScript
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = NSAlert()
        a.messageText = message
        a.addButton(withTitle: "OK")
        a.addButton(withTitle: "Annuler")
        completionHandler(a.runModal() == .alertFirstButtonReturn)
    }

    // Menu Fichier > Ouvrir une playlist…
    @objc func openFile(_ sender: Any?) {
        let p = NSOpenPanel()
        p.canChooseFiles = true
        p.canChooseDirectories = false
        p.allowsMultipleSelection = true
        p.message = "Choisissez une playlist .m3u ou .m3u8"
        p.beginSheetModal(for: window) { [weak self] r in
            guard r == .OK else { return }
            for u in p.urls { self?.sendFile(u) }
        }
    }

    func sendFile(_ u: URL) {
        guard let d = try? Data(contentsOf: u) else { return }
        let n = Data(u.lastPathComponent.utf8).base64EncodedString()
        let js = "window.__nativeFile(\"\(n)\",\"\(d.base64EncodedString())\")"
        web.evaluateJavaScript(js, completionHandler: nil)
    }

    func buildMenu() {
        let main = NSMenu()
        func add(_ sub: NSMenu) {
            let it = NSMenuItem(title: sub.title, action: nil, keyEquivalent: "")
            it.submenu = sub
            main.addItem(it)
        }

        let app = NSMenu(title: "Lecteur IPTV")
        app.addItem(withTitle: "À propos de Lecteur IPTV", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        app.addItem(NSMenuItem.separator())
        app.addItem(withTitle: "Masquer Lecteur IPTV", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        app.addItem(NSMenuItem.separator())
        app.addItem(withTitle: "Quitter Lecteur IPTV", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        add(app)

        let file = NSMenu(title: "Fichier")
        let o = file.addItem(withTitle: "Ouvrir une playlist…", action: #selector(AppDelegate.openFile(_:)), keyEquivalent: "o")
        o.target = self
        file.addItem(withTitle: "Fermer la fenêtre", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        add(file)

        let edit = NSMenu(title: "Édition")
        edit.addItem(withTitle: "Couper", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        edit.addItem(withTitle: "Copier", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        edit.addItem(withTitle: "Coller", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        edit.addItem(withTitle: "Tout sélectionner", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        add(edit)

        let win = NSMenu(title: "Fenêtre")
        win.addItem(withTitle: "Réduire", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        let fs = win.addItem(withTitle: "Plein écran", action: #selector(NSWindow.toggleFullScreen(_:)), keyEquivalent: "f")
        fs.keyEquivalentModifierMask = [.command, .control]
        win.addItem(NSMenuItem.separator())
        let pp = win.addItem(withTitle: "Image dans l’image (au premier plan)", action: #selector(AppDelegate.togglePip(_:)), keyEquivalent: "p")
        pp.keyEquivalentModifierMask = [.command, .shift]
        pp.target = self
        add(win)

        NSApp.mainMenu = main
        NSApp.windowsMenu = win
    }
}

let application = NSApplication.shared
let appDelegate = AppDelegate()
application.delegate = appDelegate
application.setActivationPolicy(.regular)
application.run()
