import SwiftUI

/// Menus de la barre de menu macOS et raccourcis clavier.
/// (Les raccourcis évitent les touches qui exigent Maj sur un clavier AZERTY.)
struct PlayerCommands: Commands {
    @ObservedObject var model: PlayerModel

    var body: some Commands {
        CommandGroup(replacing: .newItem) {
            Button("Ouvrir…") { model.presentOpenPanel() }
                .keyboardShortcut("o")
            Button("Ouvrir un dossier…") { model.presentOpenPanel(folders: true) }
            Button("Ajouter à la playlist…") { model.presentOpenPanel(append: true) }
                .keyboardShortcut("o", modifiers: [.command, .shift])
            Button("Ajouter un dossier à la playlist…") { model.presentOpenPanel(append: true, folders: true) }
            Divider()
            Button("Ajouter des sous-titres…") { model.presentSubtitlePanel() }
                .keyboardShortcut("s", modifiers: [.command, .shift])
                .disabled(model.currentIndex == nil)
        }

        CommandMenu("Lecture") {
            Button(model.isPlaying ? "Pause" : "Lecture") { model.togglePlayPause() }
                .keyboardShortcut(.space, modifiers: [])
            Button("Arrêter") { model.stop() }
                .disabled(model.currentIndex == nil)

            Divider()

            Button("Avancer de 10 s") { model.skip(seconds: 10) }
                .keyboardShortcut(.rightArrow, modifiers: [])
            Button("Reculer de 10 s") { model.skip(seconds: -10) }
                .keyboardShortcut(.leftArrow, modifiers: [])
            Button("Avancer de 1 min") { model.skip(seconds: 60) }
                .keyboardShortcut(.rightArrow, modifiers: .option)
            Button("Reculer de 1 min") { model.skip(seconds: -60) }
                .keyboardShortcut(.leftArrow, modifiers: .option)

            Divider()

            Button("Fichier suivant") { model.next() }
                .keyboardShortcut(.rightArrow, modifiers: .command)
            Button("Fichier précédent") { model.previous() }
                .keyboardShortcut(.leftArrow, modifiers: .command)

            Divider()

            Button("Plus lent") { model.adjustRate(by: -0.25) }
                .keyboardShortcut("-", modifiers: .command)
            Button("Plus rapide") { model.adjustRate(by: 0.25) }
                .keyboardShortcut("=", modifiers: .command)
            Button("Vitesse normale") { model.setRate(1.0) }
        }

        CommandMenu("Audio") {
            Menu("Piste audio (langue)") {
                Picker("Piste audio", selection: Binding(
                    get: { model.selectedAudioTrack },
                    set: { model.selectAudioTrack($0) }
                )) {
                    ForEach(model.audioTracks) { track in
                        Text(track.name).tag(track.id)
                    }
                }
            }
            .disabled(model.audioTracks.isEmpty)
            Button("Piste audio suivante") { model.cycleAudioTrack() }
                .keyboardShortcut("b", modifiers: [])
                .disabled(model.audioTracks.count < 3)
            Menu("Sous-titres") {
                Picker("Sous-titres", selection: Binding(
                    get: { model.selectedSubtitleTrack },
                    set: { model.selectSubtitleTrack($0) }
                )) {
                    ForEach(model.subtitleTracks) { track in
                        Text(track.name).tag(track.id)
                    }
                }
            }
            .disabled(model.subtitleTracks.isEmpty)
            Button("Sous-titres suivants") { model.cycleSubtitleTrack() }
                .keyboardShortcut("v", modifiers: [])
                .disabled(model.subtitleTracks.count < 2)

            Divider()

            Button("Volume +") { model.changeVolume(by: 5) }
                .keyboardShortcut(.upArrow, modifiers: [])
            Button("Volume −") { model.changeVolume(by: -5) }
                .keyboardShortcut(.downArrow, modifiers: [])
            Button(model.isMuted ? "Réactiver le son" : "Couper le son") { model.toggleMute() }
                .keyboardShortcut("m", modifiers: [])
        }

        CommandMenu("Vidéo") {
            Button("Plein écran") { model.toggleFullScreen() }
                .keyboardShortcut("f", modifiers: [])
            Button(model.pipMode ? "Quitter le Picture in Picture" : "Picture in Picture (au-dessus des apps)") {
                model.togglePiP()
            }
            .keyboardShortcut("p", modifiers: [])

            Divider()

            Menu("Format de l’image") {
                Picker("Format", selection: Binding(
                    get: { model.aspectID },
                    set: { model.setAspect($0) }
                )) {
                    ForEach(PlayerModel.aspectOptions) { option in
                        Text(option.label).tag(option.id)
                    }
                }
            }
            Button("Format suivant") { model.cycleAspect() }
                .keyboardShortcut("a", modifiers: [])
            Toggle("Remplir la fenêtre (rogne l’image)", isOn: Binding(
                get: { model.fillWindow },
                set: { model.setFill($0) }
            ))
            Toggle("Taille d’origine (100 %)", isOn: Binding(
                get: { model.originalSize },
                set: { model.setOriginalSize($0) }
            ))
            Button("Ajuster la fenêtre à la vidéo") { model.fitWindowToVideo() }
                .keyboardShortcut("0")
            Button("Format avancé (déformation libre)…") { model.advancedFormatOpen = true }
            Button("Réinitialiser la déformation") { model.resetStretch() }
                .disabled(!model.isStretched)

            Divider()

            Button(model.showPlaylist ? "Masquer la playlist" : "Afficher la playlist") {
                model.togglePlaylist()
            }
            .keyboardShortcut("l", modifiers: .command)
        }
    }
}
