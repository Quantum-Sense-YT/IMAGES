import SwiftUI

@main
struct LecteurVideoApp: App {
    @StateObject private var model = PlayerModel()

    init() {
        // Toujours démarrer en fenêtre compacte : on oublie la taille mémorisée par macOS.
        let defaults = UserDefaults.standard
        for key in defaults.dictionaryRepresentation().keys where key.hasPrefix("NSWindow Frame") {
            defaults.removeObject(forKey: key)
        }
        defaults.set(false, forKey: "NSQuitAlwaysKeepsWindows")
    }

    var body: some Scene {
        // Une seule fenêtre : ouvrir un fichier depuis le Finder la réutilise.
        Window("Lecteur Vidéo", id: "main") {
            ContentView()
                .environmentObject(model)
        }
        .defaultSize(width: 668, height: 314)
        .commands {
            PlayerCommands(model: model)
        }
    }
}
